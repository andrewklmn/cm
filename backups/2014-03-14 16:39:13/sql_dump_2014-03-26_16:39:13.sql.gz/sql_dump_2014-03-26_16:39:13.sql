-- MySQL dump 10.13  Distrib 5.5.34, for Linux (i686)
--
-- Host: localhost    Database: cashmaster
-- ------------------------------------------------------
-- Server version	5.5.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Acts`
--

DROP TABLE IF EXISTS `Acts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Acts` (
  `ActId` bigint(20) NOT NULL AUTO_INCREMENT,
  `DepositId` bigint(20) NOT NULL,
  `DiscrepancyKindId` bigint(20) NOT NULL,
  `DiscrepancyDescr` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`ActId`),
  KEY `Acts_DepositId_DepositRecs_idx` (`DepositId`),
  KEY `Acts_DiscrepancyKindId_DiscrepancyKind_idx` (`DiscrepancyKindId`),
  CONSTRAINT `Acts_DepositId_DepositRecs` FOREIGN KEY (`DepositId`) REFERENCES `DepositRecs` (`DepositRecId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Acts_DiscrepancyKindId_DiscrepancyKind` FOREIGN KEY (`DiscrepancyKindId`) REFERENCES `DiscrepancyKind` (`DiscrepancyKindId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Acts`
--

LOCK TABLES `Acts` WRITE;
/*!40000 ALTER TABLE `Acts` DISABLE KEYS */;
/*!40000 ALTER TABLE `Acts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CashRooms`
--

DROP TABLE IF EXISTS `CashRooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CashRooms` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `CashRoomName` varchar(45) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CashRooms`
--

LOCK TABLES `CashRooms` WRITE;
/*!40000 ALTER TABLE `CashRooms` DISABLE KEYS */;
INSERT INTO `CashRooms` VALUES (1,'№ 1'),(2,'№ 2');
/*!40000 ALTER TABLE `CashRooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Currency`
--

DROP TABLE IF EXISTS `Currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Currency` (
  `CurrencyId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CurrSymbol` varchar(4) NOT NULL,
  `CurrCode` varchar(4) NOT NULL,
  `CurrYear` varchar(8) DEFAULT NULL,
  `CurrName` varchar(30) NOT NULL,
  `CurrSign` varchar(1) DEFAULT NULL,
  `SeriaLength` int(11) NOT NULL DEFAULT '2',
  `NumberLength` int(11) NOT NULL DEFAULT '7',
  PRIMARY KEY (`CurrencyId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Currency`
--

LOCK TABLES `Currency` WRITE;
/*!40000 ALTER TABLE `Currency` DISABLE KEYS */;
INSERT INTO `Currency` VALUES (1,'RUB','643','1997','Российский рубль','',2,7),(2,'USD','840',NULL,'доллар США','$',2,9);
/*!40000 ALTER TABLE `Currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Customers`
--

DROP TABLE IF EXISTS `Customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Customers` (
  `CustomerId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CustomerName` varchar(80) NOT NULL,
  `CustomerCode` varchar(30) NOT NULL,
  `CustomerKPCode` varchar(50) DEFAULT NULL,
  `CustomerOKATOCode` varchar(50) DEFAULT NULL,
  `CustomerAddress` varchar(120) DEFAULT NULL,
  `Customer_Email1` varchar(80) DEFAULT NULL,
  `Customer_Email2` varchar(80) DEFAULT NULL,
  `CustomerPhone1` varchar(20) DEFAULT NULL,
  `CustomerPhone2` varchar(20) DEFAULT NULL,
  `CustomerContactName` varchar(45) DEFAULT NULL,
  `CustomerContactPost` varchar(80) DEFAULT NULL,
  `LogicallyDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `CustomerCodeLength` int(11) NOT NULL DEFAULT '9',
  PRIMARY KEY (`CustomerId`),
  UNIQUE KEY `CustomerCode_UNIQUE` (`CustomerCode`),
  UNIQUE KEY `CustomerName_UNIQUE` (`CustomerName`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customers`
--

LOCK TABLES `Customers` WRITE;
/*!40000 ALTER TABLE `Customers` DISABLE KEYS */;
INSERT INTO `Customers` VALUES (1,'Королевский Банк Шотландии','853946577','79','12','Англия, Лондон','bank@email.com',NULL,'12345678',NULL,'Nick Simper','директор',0,9),(2,'Банк Возрождение','777809145','78','79','Город Сергиев ПОсад','bank2@email.com',NULL,'12345678',NULL,'Ирина Петровна','Директор',0,9),(3,'Сбербанк РОссии, мОСКВОРЕЦКОЕ ОТД. №66','846547665','15','66','г. Москва, ул. Панфилова, 57','sberbank2@email.com',NULL,'495 666-44-66',NULL,'Пухов. А.А.','начальник',0,9),(4,'Сбербанк России, Сокольническое отд. №88','846547543','15','22','г. Москва, пр. Труда, 181','sberbank5@email.com',NULL,'495 567-54-11',NULL,'Бухарин П.П.','Зам. начальника',0,9),(5,'Сбербанк России, Семёновское отд. № 33','846547765','10','60','пгт. Семёновка, ул. Ленина, 1','sberbank8@email.com',NULL,'4323-78-45-36',NULL,'Дыбенко У.Е.','Начальник',0,9),(6,'Сбербанк России, Кировское отд. № 5, г. Санкт-Петербург','937594267','40','32','Санкт-Петербург. пр. Стачек, д.7, литера Б','sberbank8@email.com',NULL,'812-635-45-45',NULL,'Грек. Р.С.','начальник',0,9);
/*!40000 ALTER TABLE `Customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Denoms`
--

DROP TABLE IF EXISTS `Denoms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Denoms` (
  `DenomId` bigint(20) NOT NULL AUTO_INCREMENT,
  `Value` decimal(10,2) NOT NULL,
  `CurrencyId` bigint(20) NOT NULL,
  `DenomLabel` varchar(45) NOT NULL,
  PRIMARY KEY (`DenomId`),
  KEY `Currency_CurrencyId_Denoms_idx` (`CurrencyId`),
  CONSTRAINT `Currency_CurrencyId_Denoms` FOREIGN KEY (`CurrencyId`) REFERENCES `Currency` (`CurrencyId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Denoms`
--

LOCK TABLES `Denoms` WRITE;
/*!40000 ALTER TABLE `Denoms` DISABLE KEYS */;
INSERT INTO `Denoms` VALUES (1,0.01,1,'1 копейка'),(2,0.05,1,'5 копеек'),(3,0.10,1,'10 копеек'),(4,0.50,1,'50 копеек'),(5,1.00,1,'1 рубль'),(6,2.00,1,'2 рубля'),(7,5.00,1,'5 рублей'),(8,10.00,1,'10 рублей'),(9,50.00,1,'50 рублей'),(10,100.00,1,'100 рублей'),(11,500.00,1,'500 рублей'),(12,1000.00,1,'1000 рублей'),(13,5000.00,1,'5000 рублей'),(14,1.00,2,'1 доллар'),(15,2.00,2,'2 доллара'),(16,5.00,2,'5 долларов'),(17,10.00,2,'10 долларов'),(18,20.00,2,'20 долларов'),(19,50.00,2,'50 долларов'),(20,100.00,2,'100 долларов');
/*!40000 ALTER TABLE `Denoms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DepositCurrencyTotal`
--

DROP TABLE IF EXISTS `DepositCurrencyTotal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DepositCurrencyTotal` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `DepositRecId` bigint(20) NOT NULL,
  `CurrencyId` bigint(20) NOT NULL,
  `ExpectedDepositValue` decimal(12,2) NOT NULL DEFAULT '0.00',
  `ValuableTypeId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `DepositCurrencyTotal_DepositRecId_DepositRecs_idx` (`DepositRecId`),
  KEY `DepositCurrencyTotal_CurrencyId_Currency_idx` (`CurrencyId`),
  KEY `DepositCurrencyTotal_ValuableTypeId_ValuableTypes_idx` (`ValuableTypeId`),
  CONSTRAINT `DepositCurrencyTotal_DepositRecId_DepositRecs` FOREIGN KEY (`DepositRecId`) REFERENCES `DepositRecs` (`DepositRecId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DepositCurrencyTotal_CurrencyId_Currency` FOREIGN KEY (`CurrencyId`) REFERENCES `Currency` (`CurrencyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DepositCurrencyTotal_ValuableTypeId_ValuableTypes` FOREIGN KEY (`ValuableTypeId`) REFERENCES `ValuableTypes` (`ValuableTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DepositCurrencyTotal`
--

LOCK TABLES `DepositCurrencyTotal` WRITE;
/*!40000 ALTER TABLE `DepositCurrencyTotal` DISABLE KEYS */;
/*!40000 ALTER TABLE `DepositCurrencyTotal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DepositDenomTotal`
--

DROP TABLE IF EXISTS `DepositDenomTotal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DepositDenomTotal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `DepositReclId` bigint(20) NOT NULL,
  `DenomId` bigint(20) NOT NULL,
  `ExpectedCount` int(11) NOT NULL DEFAULT '0',
  `ValuableTypeId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `DepositDenomTotal_DepositRecId_DepositRecs_idx` (`DepositReclId`),
  KEY `DepositDenomTotal_DenomId_Denoms_idx` (`DenomId`),
  KEY `DepositDenomTotal_ValuableTypeId_ValuableTypes_idx` (`ValuableTypeId`),
  CONSTRAINT `DepositDenomTotal_DepositRecId_DepositRecs` FOREIGN KEY (`DepositReclId`) REFERENCES `DepositRecs` (`DepositRecId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DepositDenomTotal_DenomId_Denoms` FOREIGN KEY (`DenomId`) REFERENCES `Denoms` (`DenomId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DepositDenomTotal_ValuableTypeId_ValuableTypes` FOREIGN KEY (`ValuableTypeId`) REFERENCES `ValuableTypes` (`ValuableTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DepositDenomTotal`
--

LOCK TABLES `DepositDenomTotal` WRITE;
/*!40000 ALTER TABLE `DepositDenomTotal` DISABLE KEYS */;
/*!40000 ALTER TABLE `DepositDenomTotal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DepositIndex`
--

DROP TABLE IF EXISTS `DepositIndex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DepositIndex` (
  `DepositIndexId` bigint(20) NOT NULL AUTO_INCREMENT,
  `IndexValue` varchar(16) NOT NULL,
  `IndexLabel` varchar(45) NOT NULL,
  PRIMARY KEY (`DepositIndexId`),
  UNIQUE KEY `IndexValue_UNIQUE` (`IndexValue`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DepositIndex`
--

LOCK TABLES `DepositIndex` WRITE;
/*!40000 ALTER TABLE `DepositIndex` DISABLE KEYS */;
INSERT INTO `DepositIndex` VALUES (1,'3','годные'),(2,'4','ветхие'),(3,'5','в упаковке кредитных организаций');
/*!40000 ALTER TABLE `DepositIndex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DepositRecs`
--

DROP TABLE IF EXISTS `DepositRecs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DepositRecs` (
  `DepositRecId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ScenarioId` bigint(20) NOT NULL,
  `CustomerId` bigint(20) DEFAULT NULL,
  `DepositPackingDate` date DEFAULT NULL,
  `PackingOperatorName` varchar(30) DEFAULT NULL,
  `PackIntegrity` tinyint(4) NOT NULL DEFAULT '1',
  `StrapsIntegrity` tinyint(4) NOT NULL DEFAULT '1',
  `SealNumber` varchar(30) DEFAULT NULL,
  `SealType` tinyint(4) NOT NULL DEFAULT '1',
  `PackId` varchar(30) DEFAULT NULL,
  `RecOperatorId` bigint(20) NOT NULL,
  `RecCreateDatetime` datetime NOT NULL,
  `RecLastChangeDatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IsBalanced` tinyint(4) NOT NULL DEFAULT '0',
  `RecSupervisorId` bigint(20) DEFAULT NULL,
  `ReconcileStatus` tinyint(4) NOT NULL DEFAULT '0',
  `FwdToSupervisor` tinyint(4) NOT NULL DEFAULT '0',
  `StrapType` tinyint(4) NOT NULL DEFAULT '1',
  `SealIntegrity` tinyint(4) NOT NULL DEFAULT '1',
  `PackType` tinyint(4) NOT NULL DEFAULT '1',
  `DepositIndexId` bigint(20) NOT NULL DEFAULT '0',
  `Reported` tinyint(4) NOT NULL DEFAULT '0',
  `ServiceRec` tinyint(4) NOT NULL DEFAULT '0',
  `CardNumber` varchar(22) DEFAULT NULL,
  `PrepOperatorId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`DepositRecId`),
  KEY `DepositRecs_CustomerId_Customers_idx` (`CustomerId`),
  KEY `DepositRecs_UserId_Users_idx` (`RecOperatorId`),
  KEY `DepositRecs_ScenarioId_Scenario_idx` (`ScenarioId`),
  KEY `DepositRecs_UserId_UserConfiguration_idx` (`RecSupervisorId`),
  KEY `DepositRecs_DepositIndexId_DepositIndex_idx` (`DepositIndexId`),
  KEY `DepositRecs_PrepOperatorId_UserConfig_idx` (`PrepOperatorId`),
  CONSTRAINT `DepositRecs_CustomerId_Customers` FOREIGN KEY (`CustomerId`) REFERENCES `Customers` (`CustomerId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DepositRecs_UserId_Users` FOREIGN KEY (`RecOperatorId`) REFERENCES `UserConfiguration` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DepositRecs_ScenarioId_Scenario` FOREIGN KEY (`ScenarioId`) REFERENCES `Scenario` (`ScenarioId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DepositRecs_UserId_UserConfiguration` FOREIGN KEY (`RecSupervisorId`) REFERENCES `UserConfiguration` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DepositRecs_DepositIndexId_DepositIndex` FOREIGN KEY (`DepositIndexId`) REFERENCES `DepositIndex` (`DepositIndexId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DepositRecs_PrepOperatorId_UserConfig` FOREIGN KEY (`PrepOperatorId`) REFERENCES `UserConfiguration` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DepositRecs`
--

LOCK TABLES `DepositRecs` WRITE;
/*!40000 ALTER TABLE `DepositRecs` DISABLE KEYS */;
/*!40000 ALTER TABLE `DepositRecs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DepositRuns`
--

DROP TABLE IF EXISTS `DepositRuns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DepositRuns` (
  `DepositRunId` bigint(20) NOT NULL AUTO_INCREMENT,
  `DataSortCardNumber` varchar(22) NOT NULL,
  `MachineDBId` bigint(20) NOT NULL,
  `ShiftId` int(11) NOT NULL DEFAULT '1',
  `BatchId` int(11) NOT NULL DEFAULT '1',
  `DepositInBatchId` int(11) DEFAULT '1',
  `DepositStartTimeStamp` datetime NOT NULL,
  `DepositEndTimeStamp` datetime NOT NULL,
  `OperatorName` varchar(22) NOT NULL,
  `SupervisorName` varchar(22) DEFAULT NULL,
  `IndexName` varchar(22) NOT NULL,
  `SortModeName` varchar(50) DEFAULT NULL,
  `DepositRecId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`DepositRunId`),
  KEY `DepositRuns_DepositRecId_DepositRecs_idx` (`DepositRecId`),
  KEY `Machines_DB_idx` (`MachineDBId`),
  CONSTRAINT `DepositRuns_DepositRecId_DepositRecs` FOREIGN KEY (`DepositRecId`) REFERENCES `DepositRecs` (`DepositRecId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Machines_DB` FOREIGN KEY (`MachineDBId`) REFERENCES `Machines` (`MachineDBId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DepositRuns`
--

LOCK TABLES `DepositRuns` WRITE;
/*!40000 ALTER TABLE `DepositRuns` DISABLE KEYS */;
INSERT INTO `DepositRuns` VALUES (1,'500041',2,1,1,73,'2014-01-15 17:00:00','2014-01-15 17:03:45','Павлова О.П.','Tanya','Index_5','Сортировка на Годные и Ветхие',NULL),(2,'500042',2,1,1,74,'2014-01-15 17:03:45','2014-01-15 17:05:59','Павлова О.П.','Tanya','Index_5','Сортировка на Годные и Ветхие',NULL),(3,'500041',2,1,1,75,'2014-01-15 17:05:59','2014-01-15 17:06:00','Павлова О.П.','Tanya','Index_5','Сортировка на Годные и Ветхие',NULL),(4,'500042',2,1,1,76,'2014-01-15 17:06:00','2014-01-15 17:06:01','Павлова О.П.','Tanya','Index_5','Сортировка на Годные и Ветхие',NULL),(5,'500043',2,1,1,77,'2014-01-15 17:07:06','2014-01-15 17:09:20','Павлова О.П.','Tanya','Index_5','Сортировка на Годные и Ветхие',NULL),(6,'500044',2,1,1,78,'2014-01-15 17:09:58','2014-01-15 17:11:27','Павлова О.П.','Tanya','Index_5','Сортировка без уничтожения',NULL),(7,'550028',2,1,1,79,'2014-01-15 17:21:01','2014-01-15 17:23:45','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих банкнот',NULL),(8,'550029',2,1,1,80,'2014-01-15 17:24:01','2014-01-15 17:25:45','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих банкнот',NULL),(9,'550030',2,1,1,81,'2014-01-15 17:26:01','2014-01-15 17:27:45','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих банкнот',NULL),(10,'550031',2,1,1,82,'2014-01-15 17:28:01','2014-01-15 17:29:45','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих банкнот',NULL),(11,'550028',2,1,1,83,'2014-01-15 17:30:01','2014-01-15 17:31:45','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих банкнот',NULL),(12,'550029',2,1,1,84,'2014-01-15 17:32:01','2014-01-15 17:33:45','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих банкнот',NULL),(13,'777801',2,1,1,85,'2014-01-15 18:12:01','2014-01-15 18:13:45','Онищенко В.Ы.','Tanya','Index_8','Мультивалютный мультиноминальный пересчёт',NULL),(14,'300001',2,3,3,1,'2014-01-15 08:30:01','2014-01-15 08:33:45','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(15,'300002',2,3,3,2,'2014-01-15 08:33:46','2014-01-15 08:35:18','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(16,'300003',2,3,3,3,'2014-01-15 08:35:21','2014-01-15 08:37:59','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(17,'300004',2,3,3,4,'2014-01-15 08:38:07','2014-01-15 08:41:01','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(18,'300005',2,3,3,5,'2014-01-15 08:41:02','2014-01-15 08:43:30','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(19,'300006',2,3,3,6,'2014-01-15 08:43:32','2014-01-15 08:46:19','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(20,'300007',2,3,3,7,'2014-01-15 08:46:21','2014-01-15 08:49:30','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(21,'300008',2,3,3,8,'2014-01-15 08:49:31','2014-01-15 08:52:26','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(22,'300009',2,3,3,9,'2014-01-15 08:52:29','2014-01-15 08:55:09','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(23,'300010',2,3,3,10,'2014-01-15 08:55:11','2014-01-15 08:57:49','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(24,'300011',2,3,3,11,'2014-01-15 08:57:51','2014-01-15 09:01:02','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(25,'300012',2,3,3,12,'2014-01-15 09:01:05','2014-01-15 09:02:48','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(26,'300013',2,3,3,13,'2014-01-15 09:02:50','2014-01-15 09:04:19','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(27,'300014',2,3,3,14,'2014-01-15 09:04:20','2014-01-15 09:06:31','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(28,'300015',2,3,3,15,'2014-01-15 09:06:34','2014-01-15 09:08:58','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(29,'300016',2,3,3,16,'2014-01-15 09:08:59','2014-01-15 09:10:11','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(30,'300017',2,3,3,17,'2014-01-15 09:10:13','2014-01-15 09:13:10','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(31,'300018',2,3,3,18,'2014-01-15 09:13:13','2014-01-15 09:15:24','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(32,'300019',2,3,3,19,'2014-01-15 09:15:27','2014-01-15 09:17:08','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(33,'300020',2,3,3,20,'2014-01-15 09:17:11','2014-01-15 09:19:13','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(34,'300021',2,3,3,20,'2014-01-15 09:19:15','2014-01-15 09:21:43','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(35,'300022',2,3,3,20,'2014-01-15 09:19:15','2014-01-15 09:21:43','Павлова О.П.','Tanya','Index_3','Счёт Годных',NULL),(36,'300023',3,1,1,1,'2014-01-15 08:30:15','2014-01-15 08:33:10','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(37,'300024',3,1,1,2,'2014-01-15 08:33:12','2014-01-15 08:35:39','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(38,'300025',3,1,1,3,'2014-01-15 08:35:42','2014-01-15 08:38:07','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(39,'300026',3,1,1,4,'2014-01-15 08:38:09','2014-01-15 08:40:11','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(40,'300027',3,1,1,5,'2014-01-15 08:40:13','2014-01-15 08:42:28','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(41,'300028',3,1,1,6,'2014-01-15 08:42:31','2014-01-15 08:45:19','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(42,'300029',3,1,1,7,'2014-01-15 08:45:21','2014-01-15 08:47:03','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(43,'300030',3,1,1,8,'2014-01-15 08:47:04','2014-01-15 08:49:15','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(44,'300031',3,1,1,9,'2014-01-15 08:49:16','2014-01-15 08:53:45','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(45,'300032',3,1,1,10,'2014-01-15 08:53:59','2014-01-15 08:55:50','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(46,'300033',3,1,1,11,'2014-01-15 08:56:27','2014-01-15 08:59:19','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(47,'300034',3,1,1,12,'2014-01-15 08:59:22','2014-01-15 09:02:24','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(48,'300035',3,1,1,13,'2014-01-15 09:02:40','2014-01-15 09:05:33','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(49,'300036',3,1,1,14,'2014-01-15 09:10:15','2014-01-15 09:12:52','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(50,'300037',3,1,1,15,'2014-01-15 09:12:55','2014-01-15 09:14:32','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(51,'300039',3,1,1,16,'2014-01-15 09:14:34','2014-01-15 09:16:58','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(52,'300040',3,1,1,17,'2014-01-15 09:17:00','2014-01-15 09:19:03','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(53,'300041',3,1,1,18,'2014-01-15 09:25:00','2014-01-15 09:27:03','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(54,'300042',3,1,1,19,'2014-01-15 09:27:05','2014-01-15 09:29:43','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(55,'300043',3,1,1,20,'2014-01-15 09:29:45','2014-01-15 09:31:55','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(56,'300044',3,1,1,21,'2014-01-15 09:32:02','2014-01-15 09:34:22','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(57,'300045',3,1,1,22,'2014-01-15 09:34:24','2014-01-15 09:36:32','Гельмер Ю.А.','Tanya','Index_3','Счёт Годных',NULL),(58,'500001',2,3,3,21,'2014-01-15 09:25:16','2014-01-15 09:27:50','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(59,'500002',2,3,3,22,'2014-01-15 09:27:51','2014-01-15 09:29:30','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(60,'500003',2,3,3,23,'2014-01-15 09:29:31','2014-01-15 09:33:03','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(61,'500004',2,3,3,24,'2014-01-15 09:33:05','2014-01-15 09:36:22','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(62,'500005',2,3,3,25,'2014-01-15 09:36:25','2014-01-15 09:38:44','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(63,'500006',2,3,3,26,'2014-01-15 09:38:45','2014-01-15 09:40:11','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(64,'500007',2,3,3,27,'2014-01-15 09:40:13','2014-01-15 09:43:31','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(65,'500008',2,3,3,28,'2014-01-15 09:43:33','2014-01-15 09:45:18','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(66,'500009',2,3,3,29,'2014-01-15 09:45:20','2014-01-15 09:47:48','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(67,'500010',2,3,3,30,'2014-01-15 09:47:51','2014-01-15 09:49:59','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(68,'500011',2,3,3,31,'2014-01-15 09:50:03','2014-01-15 09:53:17','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(69,'500012',2,3,3,32,'2014-01-15 09:54:23','2014-01-15 09:57:20','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(70,'500013',2,3,3,33,'2014-01-15 09:57:58','2014-01-15 10:00:32','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(71,'500014',2,3,3,34,'2014-01-15 10:00:45','2014-01-15 10:03:12','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(72,'500015',2,3,3,35,'2014-01-15 10:03:48','2014-01-15 10:05:44','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(73,'500016',2,3,3,36,'2014-01-15 10:06:00','2014-01-15 10:08:22','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(74,'500017',2,3,3,37,'2014-01-15 10:02:27','2014-01-15 10:10:11','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(75,'500018',2,3,3,38,'2014-01-15 10:12:27','2014-01-15 10:15:18','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(76,'500019',2,3,3,39,'2014-01-15 10:15:44','2014-01-15 10:17:50','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(77,'500020',2,3,3,40,'2014-01-15 10:18:04','2014-01-15 10:20:13','Павлова О.П.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(78,'500021',3,1,1,23,'2014-01-15 09:38:54','2014-01-15 09:41:16','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(79,'500022',3,1,1,24,'2014-01-15 09:41:17','2014-01-15 09:43:44','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(80,'500023',3,1,1,25,'2014-01-15 09:43:47','2014-01-15 09:45:28','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(81,'500024',3,1,1,26,'2014-01-15 09:45:30','2014-01-15 09:47:36','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(82,'500025',3,1,1,27,'2014-01-15 09:47:40','2014-01-15 09:50:01','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(83,'500026',3,1,1,28,'2014-01-15 09:50:50','2014-01-15 09:53:11','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(84,'500027',3,1,1,29,'2014-01-15 09:53:17','2014-01-15 09:55:51','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(85,'500028',3,1,1,30,'2014-01-15 09:56:03','2014-01-15 09:58:33','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(86,'500029',3,1,1,31,'2014-01-15 09:58:04','2014-01-15 10:02:12','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(87,'500030',3,1,1,32,'2014-01-15 10:02:14','2014-01-15 10:04:45','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(88,'500031',3,1,1,33,'2014-01-15 10:04:50','2014-01-15 10:06:58','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(89,'500032',3,1,1,34,'2014-01-15 10:08:14','2014-01-15 10:10:28','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(90,'500033',3,1,1,35,'2014-01-15 10:10:54','2014-01-15 10:13:17','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(91,'500034',3,1,1,36,'2014-01-15 10:13:27','2014-01-15 10:16:07','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(92,'500035',3,1,1,37,'2014-01-15 10:18:40','2014-01-15 10:20:01','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(93,'500036',3,1,1,38,'2014-01-15 10:20:48','2014-01-15 10:23:11','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(94,'500037',3,1,1,39,'2014-01-15 10:24:17','2014-01-15 10:26:41','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(95,'500038',3,1,1,40,'2014-01-15 10:27:00','2014-01-15 10:29:00','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(96,'500039',3,1,1,41,'2014-01-15 10:29:50','2014-01-15 10:32:16','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(97,'500040',3,1,1,42,'2014-01-15 10:32:43','2014-01-15 10:35:50','Гельмер Ю.А.','Tanya','Index_5','Сортировка банкнот на Годные и Ветхие',NULL),(98,'550001',2,3,3,41,'2014-01-15 11:00:00','2014-01-15 11:02:23','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(99,'550002',2,3,3,42,'2014-01-15 11:02:25','2014-01-15 11:04:58','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(100,'550003',2,3,3,43,'2014-01-15 11:05:02','2014-01-15 11:08:17','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(101,'550004',2,3,3,44,'2014-01-15 11:08:20','2014-01-15 11:10:24','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(102,'550005',2,3,3,45,'2014-01-15 11:10:31','2014-01-15 11:12:49','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(103,'550006',2,3,3,46,'2014-01-15 11:13:10','2014-01-15 11:15:22','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(104,'550007',2,3,3,47,'2014-01-15 11:15:40','2014-01-15 11:18:12','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(105,'550008',2,3,3,48,'2014-01-15 11:18:19','2014-01-15 11:20:36','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(106,'550009',2,3,3,49,'2014-01-15 11:20:39','2014-01-15 11:23:41','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(107,'550010',2,3,3,50,'2014-01-15 11:23:49','2014-01-15 11:26:13','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(108,'550011',2,3,3,51,'2014-01-15 11:26:20','2014-01-15 11:29:03','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(109,'550012',2,3,3,52,'2014-01-15 11:29:17','2014-01-15 11:32:44','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(110,'550013',2,3,3,53,'2014-01-15 11:33:29','2014-01-15 11:36:19','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(111,'550014',2,3,3,54,'2014-01-15 11:36:23','2014-01-15 11:39:59','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(112,'550015',3,1,1,43,'2014-01-15 10:50:00','2014-01-15 10:52:30','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(113,'550016',3,1,1,44,'2014-01-15 10:52:32','2014-01-15 10:56:11','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(114,'550017',3,1,1,45,'2014-01-15 10:56:19','2014-01-15 10:59:01','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(115,'550018',3,1,1,46,'2014-01-15 10:59:09','2014-01-15 11:05:13','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(116,'550019',3,1,1,47,'2014-01-15 11:05:15','2014-01-15 11:07:49','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(117,'550020',3,1,1,47,'2014-01-15 11:07:57','2014-01-15 11:10:11','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(118,'550021',3,1,1,48,'2014-01-15 11:13:04','2014-01-15 11:15:12','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(119,'550022',3,1,1,49,'2014-01-15 11:15:14','2014-01-15 11:18:09','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(120,'550023',3,1,1,50,'2014-01-15 11:18:12','2014-01-15 11:20:21','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(121,'550024',3,1,1,51,'2014-01-15 11:20:40','2014-01-15 11:23:33','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(122,'550025',3,1,1,52,'2014-01-15 11:23:38','2014-01-15 11:27:15','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(123,'550026',3,1,1,53,'2014-01-15 11:27:20','2014-01-15 11:30:09','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(124,'550027',3,1,1,54,'2014-01-15 11:30:12','2014-01-15 11:38:29','Гельмер Ю.А.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(125,'400001',2,3,3,55,'2014-01-15 12:01:15','2014-01-15 12:03:48','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(126,'400002',2,3,3,56,'2014-01-15 12:03:51','2014-01-15 12:06:12','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(127,'400003',2,3,3,57,'2014-01-15 12:06:17','2014-01-15 12:08:50','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(128,'400004',2,3,3,58,'2014-01-15 12:09:03','2014-01-15 12:11:38','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(129,'400005',2,3,3,59,'2014-01-15 12:11:41','2014-01-15 12:14:11','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(130,'400006',2,3,3,60,'2014-01-15 12:14:18','2014-01-15 12:18:09','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(131,'400007',2,3,3,61,'2014-01-15 12:19:13','2014-01-15 12:24:38','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(132,'400008',2,3,3,62,'2014-01-15 12:24:52','2014-01-15 12:27:19','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(133,'400009',2,3,3,63,'2014-01-15 12:27:40','2014-01-15 12:29:59','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(134,'400010',2,3,3,64,'2014-01-15 12:30:19','2014-01-15 12:32:51','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(135,'400011',2,3,3,65,'2014-01-15 12:33:10','2014-01-15 12:35:24','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(136,'400012',2,3,3,66,'2014-01-15 12:35:41','2014-01-15 12:38:19','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(137,'400013',2,3,3,67,'2014-01-15 12:38:39','2014-01-15 12:41:13','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(138,'400014',2,3,3,68,'2014-01-15 12:42:27','2014-01-15 12:45:04','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(139,'400015',2,3,3,69,'2014-01-15 12:45:26','2014-01-15 12:48:15','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(140,'40016',2,3,3,70,'2014-01-15 12:49:07','2014-01-15 12:51:18','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(141,'400017',2,3,3,71,'2014-01-15 12:52:14','2014-01-15 12:54:41','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(142,'400018',2,3,3,72,'2014-01-15 12:54:43','2014-01-15 12:57:18','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(143,'400901',2,3,3,73,'2014-01-15 13:00:00','2014-01-15 13:02:55','Павлова О.П.','Tanya','Index_4','Уничтожить все банкноты',NULL),(144,'400019',3,1,1,55,'2014-01-15 11:50:09','2014-01-15 11:52:34','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(145,'400020',3,1,1,56,'2014-01-15 11:52:36','2014-01-15 11:54:54','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(146,'400021',3,1,1,57,'2014-01-15 11:54:59','2014-01-15 11:57:19','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(147,'400022',3,1,1,58,'2014-01-15 11:57:21','2014-01-15 11:59:58','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(148,'400023',3,1,1,59,'2014-01-15 12:00:05','2014-01-15 12:03:11','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(149,'400024',3,1,1,60,'2014-01-15 12:03:13','2014-01-15 12:05:41','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(150,'400025',3,1,1,61,'2014-01-15 12:05:44','2014-01-15 12:08:19','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(151,'400026',3,1,1,62,'2014-01-15 12:08:21','2014-01-15 12:10:25','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(152,'400027',3,1,1,63,'2014-01-15 12:10:26','2014-01-15 12:12:47','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(153,'400028',3,1,1,64,'2014-01-15 12:12:49','2014-01-15 12:14:39','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(154,'400029',3,1,1,65,'2014-01-15 12:14:41','2014-01-15 12:17:00','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(155,'400030',3,1,1,66,'2014-01-15 12:17:02','2014-01-15 12:18:52','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(156,'400031',3,1,1,67,'2014-01-15 12:18:53','2014-01-15 12:21:16','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(157,'400032',3,1,1,68,'2014-01-15 12:21:18','2014-01-15 12:23:40','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(158,'400033',3,1,1,69,'2014-01-15 12:23:44','2014-01-15 12:27:08','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(159,'400034',3,1,1,70,'2014-01-15 12:27:09','2014-01-15 12:29:29','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(160,'400035',3,1,1,71,'2014-01-15 12:29:30','2014-01-15 12:32:22','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(161,'400036',3,1,1,72,'2014-01-15 12:32:24','2014-01-15 12:35:00','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(162,'400901',3,1,1,73,'2014-01-15 13:17:10','2014-01-15 13:25:59','Гельмер Ю.А.','Tanya','Index_4','Уничтожить все банкноты',NULL),(163,'550991',2,3,3,74,'2014-01-15 14:17:08','2014-01-15 14:20:19','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(164,'55099',2,3,3,75,'2014-01-15 14:21:44','2014-01-15 14:21:50','Павлова О.П.','Tanya','Index_5','Сортировка с уничтожением ветхих',NULL),(165,'110006',4,1,1,1,'2014-01-15 08:30:00','2014-01-15 08:35:05','Павлова О.П.','Carina','Index_5','Сортировка с уничтожением ветхих',NULL),(166,'110007',4,1,1,2,'2014-01-15 08:36:00','2014-01-15 08:38:55','Павлова О.П.','Carina','Index_5','Сортировка с уничтожением ветхих',NULL),(167,'110008',4,1,1,3,'2014-01-15 08:39:00','2014-01-15 08:40:55','Павлова О.П.','Carina','Индэкс_5','Сортировка с уничтожением ветхих',NULL),(168,'110008',4,1,1,5,'2014-01-15 08:40:59','2014-01-15 08:41:31','Павлова О.П.','Carina','Индэкс_5','Сортировка с уничтожением ветхих',NULL),(169,'110009',4,1,1,6,'2014-01-15 08:42:00','2014-01-15 08:45:01','Павлова О.П.','Carina','Index_3','Сортировка с уничтожением ветхих',NULL),(170,'110009',4,1,1,7,'2014-01-15 08:46:17','2014-01-15 08:46:31','Павлова О.П.','Carina','Index_4','Сортировка с уничтожением ветхих',NULL),(171,'110010',4,1,1,8,'2014-01-15 08:48:00','2014-01-15 08:50:01','Павлова О.П.','Carina','Индюкс_12','Сортировка с уничтожением ветхих',NULL),(172,'110010',4,1,1,9,'2014-01-15 08:50:23','2014-01-15 08:50:32','Павлова О.П.','Carina','Индюкс_11','Сортировка с уничтожением ветхих',NULL);
/*!40000 ALTER TABLE `DepositRuns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DiscrepancyKind`
--

DROP TABLE IF EXISTS `DiscrepancyKind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DiscrepancyKind` (
  `DiscrepancyKindId` bigint(20) NOT NULL AUTO_INCREMENT,
  `DiscrepancyKindName` varchar(25) NOT NULL,
  PRIMARY KEY (`DiscrepancyKindId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DiscrepancyKind`
--

LOCK TABLES `DiscrepancyKind` WRITE;
/*!40000 ALTER TABLE `DiscrepancyKind` DISABLE KEYS */;
INSERT INTO `DiscrepancyKind` VALUES (1,'сомнительная банкнота'),(2,'недостача'),(3,'излишек');
/*!40000 ALTER TABLE `DiscrepancyKind` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExternalUsers`
--

DROP TABLE IF EXISTS `ExternalUsers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExternalUsers` (
  `ExternalUserId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ExternalUserPost` varchar(80) NOT NULL,
  `ExternalUserName` varchar(45) NOT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ExternalUserId`),
  UNIQUE KEY `unique_name_post` (`ExternalUserPost`,`ExternalUserName`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExternalUsers`
--

LOCK TABLES `ExternalUsers` WRITE;
/*!40000 ALTER TABLE `ExternalUsers` DISABLE KEYS */;
INSERT INTO `ExternalUsers` VALUES (1,'Старший контролёр-кассир','С.И.Павлова',NULL),(2,'Заведующий кладовой','С.Н. Сафарова',NULL),(3,'Контролёр кладовой','П.С. Щербакова',NULL);
/*!40000 ALTER TABLE `ExternalUsers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Grades`
--

DROP TABLE IF EXISTS `Grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Grades` (
  `GradeId` bigint(20) NOT NULL AUTO_INCREMENT,
  `GradeName` varchar(7) NOT NULL,
  `GradeLabel` varchar(30) NOT NULL,
  PRIMARY KEY (`GradeId`),
  UNIQUE KEY `GradeName_UNIQUE` (`GradeName`),
  UNIQUE KEY `GradeLabel_UNIQUE` (`GradeLabel`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Grades`
--

LOCK TABLES `Grades` WRITE;
/*!40000 ALTER TABLE `Grades` DISABLE KEYS */;
INSERT INTO `Grades` VALUES (1,'SUSPECT','Сомнит.'),(2,'FIT','Годные'),(3,'UNFIT','Ветхие'),(4,'COUNT','Счёт'),(5,'SHRED','Уничтож.'),(6,'MOD1997','1997'),(7,'MOD2004','Мод.2004'),(8,'MOD2010','Мод.2010');
/*!40000 ALTER TABLE `Grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IntegrityCheck`
--

DROP TABLE IF EXISTS `IntegrityCheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IntegrityCheck` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FileName` varchar(255) NOT NULL,
  `Hash` varchar(32) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=453 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IntegrityCheck`
--

LOCK TABLES `IntegrityCheck` WRITE;
/*!40000 ALTER TABLE `IntegrityCheck` DISABLE KEYS */;
INSERT INTO `IntegrityCheck` VALUES (1,'./app/controller/common/refill_integrity_check.php','e80ad77a3d97d2bd5752d40e18ce8d47'),(2,'./app/controller/common/check_finished_recon_by_scenario.php','71b4f5172e7cc301ead3804ebcf8b85e'),(3,'./app/controller/common/envelope.php','433ed4988623a8d2591789783f4ecdef'),(4,'./app/controller/common/profile_old.php','0395cb28202ffd7964bafab973e3377c'),(5,'./app/controller/common/profile.php','24e5173a780b01dd2a5eb3c7ffefaaf6'),(6,'./app/controller/common/check_scenario_valuable_grades.php','4da4ada123c4f1ca577dad2e9ab24ef1'),(7,'./app/controller/common/set_systemconfiguration.php','cfaa59aaa7fe9ceb85975362c226cce6'),(8,'./app/controller/common/report/add_reports_seq.php','2d462ab2d7a38b1cff379ae638dca075'),(9,'./app/controller/common/report/fill_report_signers.php','59cce353aa24da193e113d5a0aafb905'),(10,'./app/controller/common/report/fill_report_saves.php','269e57720a60672ccc888819414959ec'),(11,'./app/controller/common/report/set_active_record_set_id.php','b46c6b43c737b13fec2f4e1b15dd9b9a'),(12,'./app/controller/common/report/check_operation_day_status.php','51d4bc519ff64cf1683e27678f225fc2'),(13,'./app/controller/common/report/get_scens_by_reportset_period.php','3e9a276e2a0810a019445b113170b433'),(14,'./app/controller/common/report/preview_report.php','b25ae63e2a7656cc1f32149bd9e1b2e2'),(15,'./app/controller/common/report/generate_report.php','cc6f5f37f6a4cfafc93d84fa7f8fd373'),(16,'./app/controller/common/report/select_signers.php','8b2ae39690f4438b463e8d36c3c3d1b0'),(17,'./app/controller/common/report/get_reports_by_used_scen_ids.php','39616a68768ddc437c9bb83083073b3a'),(18,'./app/controller/common/report/check_needed_reports_files.php','2c60577e6ec898e484f78fb3bc115bfb'),(19,'./app/controller/common/restore_application.php','5bbbd0006249154edef3b42325ad3480'),(20,'./app/controller/common/scen_wizard/sorter_grades.php','30241f93032f18cef582bc3a0941b902'),(21,'./app/controller/common/scen_wizard/denoms.php','0bb0b33fa13f93a9e0d666238a091898'),(22,'./app/controller/common/scen_wizard/valuable_types.php','9d3a0c445d4d1c68fb77c1051565f4ef'),(23,'./app/controller/common/scen_wizard/valuable_grades.php','bb541ebf69386723f53bb845484fae82'),(24,'./app/controller/common/scen_wizard/recon_grades.php','f4e45331cff79fa62d6a614ec2f23547'),(25,'./app/controller/common/scen_wizard/finish.php','ddfa9403fe57d162b3eedc6e7d87ad4b'),(26,'./app/controller/common/users.php','15913d32e6b20e6f876a6adc8d38af2f'),(27,'./app/controller/common/refill_integrity_check_restore.php','3ed71f465395ad04d4cea282086ae40c'),(28,'./app/controller/common/reconciliation/check_recon_indexes.php','5121e1ce0d9733b49a1578991b2fb0af'),(29,'./app/controller/common/reconciliation/auto_change_scenario.php','f00fd3cb8f1c9e1df1a8a52101318a15'),(30,'./app/controller/common/reconciliation/check_grades.php','71b2ccba82107e63cc8e7f047cb00db2'),(31,'./app/controller/common/reconciliation/check_currencies.php','4e027bbf54c7add98e1338c82874ca6f'),(32,'./app/controller/common/reconciliation/check_single_denom.php','be4e01ad59c3e4f1fad6dd5f7b1ba4db'),(33,'./app/controller/common/reconciliation/check_suspect.php','29a07601dbfca699959e62ab8629efe9'),(34,'./app/controller/common/reconciliation/check_recon_accounting_data_finish.php','42b5316b6b3148b3e5888f1e05a81a4d'),(35,'./app/controller/common/reconciliation/check_indexes.php','8542cf1101cb9169bbd831f3d5c4234b'),(36,'./app/controller/common/reconciliation/check_sorter_accounting_data.php','5d1bb51f1d2eb7166cc8c3ceef4a97c4'),(37,'./app/controller/common/reconciliation/check_recon_status.php','339cbe828b5b0708d5e82f50c228ad03'),(38,'./app/controller/common/reconciliation/check_recon_accounting_data.php','32d7f46fd4627bdb36e1581d2ca4579c'),(39,'./app/controller/common/reconciliation/check_discr_form_fill.php','2db47382c05d5137693df266c280b05c'),(40,'./app/controller/common/reconciliation/check_denoms.php','ca9c8e5ae9b702ffcc6d221a5fc6b5d6'),(41,'./app/controller/common/reconciliation/check_new_valuables.php','c0daf13aad14ced3b8593685841e7a1e'),(42,'./app/controller/common/reconciliation/set_count_if_no_scenario.php','98f818901e1eda5ac1387f03fe05f2b3'),(43,'./app/controller/common/reconciliation/new_recon_checker.php','2b4bcb0991131d9af99763b7c9c5c0d4'),(44,'./app/controller/common/integrity_check.php','2ffaf4e3b0b575743f17226af4e30824'),(45,'./app/controller/common/restore_scripts.php','452d38c17a84bf480ef1ff24645ffa3c'),(46,'./app/controller/common/change_password.php','74aeacaadf0a61582c88db2e8ed0ce4a'),(47,'./app/controller/auth.php','5fb5c5457fe6d181bf8eae6af357ae28'),(48,'./app/controller/logout.php','07b143398e3549da278e4feddf7fce9c'),(49,'./app/controller/supervisor/user_edit.php','98a815353ef29fa73b61193239d2ed8a'),(50,'./app/controller/supervisor/deposit_manager_actions.php','34adac40025140b3f9822ac1834f2c8e'),(51,'./app/controller/supervisor/signer_add.php','6846641c4df4d4e56f5db6d18ba07d77'),(52,'./app/controller/supervisor/recon_reconcile_with_discrep.php','9a99d2aeb4886b2147a7e4a39888590c'),(53,'./app/controller/supervisor/recon_total_update.php','12d5a82267a0b6f644b9a73c7c9e6ea0'),(54,'./app/controller/supervisor/recon_view.php','cab3bb5ff622a0605b9559af0eaa004f'),(55,'./app/controller/supervisor/sorter_data.php','f722e124994eb9492ee80d729a6d4a55'),(56,'./app/controller/supervisor/act_by_recon.php','f166d072b91055382695d1c8da0fd6d2'),(57,'./app/controller/supervisor/profile.php','a8f68eef386621c186d2228846927a0a'),(58,'./app/controller/supervisor/preview_reports.php','a7d6533f8daf9f0a0160c5a35e4c7801'),(59,'./app/controller/supervisor/reportset_view.php','48b072e548772fc716064f1a37d71db9'),(60,'./app/controller/supervisor/index_conflict.php','1391408e0f4626e8c7fae1508f77a006'),(61,'./app/controller/supervisor/reconciliation.php','b478e8b0a8a7fcf007693c25607550ff'),(62,'./app/controller/supervisor/index.php','dca1b950ee51d3e35a83733ef223e841'),(63,'./app/controller/supervisor/recon_reconcile.php','549856161276648c31c5287efbaf4f30'),(64,'./app/controller/supervisor/recon_discr_update.php','fe18e511e2890110011d120caaa888b0'),(65,'./app/controller/supervisor/reports_archive.php','3b171d3c406816c7c501c66ca84b9695'),(66,'./app/controller/supervisor/recon_act_update.php','6b73c4fb914aabd3c6fb4c7fe8492c3e'),(67,'./app/controller/supervisor/recon_expected_update.php','ee44a7a2d7e22eb1a1c0cb1800fa3eef'),(68,'./app/controller/supervisor/users.php','af95ad9234b2d1234f59a3eb24618e89'),(69,'./app/controller/supervisor/recon_to_control.php','70669faf73b473ec781173203595ca38'),(70,'./app/controller/supervisor/client_edit.php','06fc00d7f94f39abf882fb08f1c3b26f'),(71,'./app/controller/supervisor/recon_update.php','40bb6f34036b6c0adc206ba75eac3969'),(72,'./app/controller/supervisor/reports.php','c5eeb81d633a0d38e85bbefc7b05268f'),(73,'./app/controller/supervisor/create_reports.php','051713d5c644cb4ab2ca83d7a36f34c1'),(74,'./app/controller/supervisor/client_add.php','2059b2f1ac391413649fd64a521a8334'),(75,'./app/controller/supervisor/customers.php','7cbb0ed9e5421d062bb53463778b71b8'),(76,'./app/controller/supervisor/signers.php','cc2fa1e3d07ae31d6735ff1483caa893'),(77,'./app/controller/supervisor/restore_scripts.php','33e64e1cec9cb511791cd10117a54251'),(78,'./app/controller/supervisor/recon_stat_update.php','b2253678c5c6c350b83742cdfcba086e'),(79,'./app/controller/supervisor/reconciliation_report.php','ce50d397142ed80ebcfcb33fc0d76ae4'),(80,'./app/controller/supervisor/deposit_manager.php','3e98f2a869dad7442b8d0e79f63dc535'),(81,'./app/controller/supervisor/reconciled.php','a042f1f5dba250d232a4a875b05b1bad'),(82,'./app/controller/supervisor/change_password.php','95cc947087d36f3031142367c0e27e13'),(83,'./app/controller/supervisor/suspect_enter.php','1ec63a67753ba3cc33556b60c443492d'),(84,'./app/controller/supervisor/deposit_manager_actions/rec_to_service.php','bfe387fe703ea1f60b82cb362bb87aee'),(85,'./app/controller/supervisor/deposit_manager_actions/runs_to_service.php','80e9ee7a21930686d03641b74003c57b'),(86,'./app/controller/supervisor/deposit_manager_actions/release_runs.php','e91b97a48a7a45da6ec12487d4e7b736'),(87,'./app/controller/supervisor/deposit_manager_actions/change_card_number_in_runs.php','55166b096340141789c813703ba5b13c'),(88,'./app/controller/supervisor/deposit_manager_actions/change_card_number_in_rec.php','a1f55c2dc1c82ce664a639f769ff0027'),(89,'./app/controller/supervisor/deposit_manager_actions/join_recs.php','0ab1b91b30868679701510c9c26957a6'),(90,'./app/controller/supervisor/signer_edit.php','f761c2bf356fd2f73dd17e4c139b9039'),(91,'./app/controller/select_scenario.php','f6fa92434d41b005985476e93d36457a'),(92,'./app/controller/echo_current_scenario.php','9e8de0952b98d72d4f4d59bfe63b7f14'),(93,'./app/controller/bootstrap.php','0467186b0223de1fea28e6630d071e7c'),(94,'./app/controller/admin/user_edit.php','4651943929981bf3506d652b1a1dd06b'),(95,'./app/controller/admin/backup.php','dbe782cac403353ebdb7a799c39d8475'),(96,'./app/controller/admin/denoms.php','125fa69ba7510a46cf880362596215cf'),(97,'./app/controller/admin/currency_add.php','f4805658d2f2f875981ad189d1311218'),(98,'./app/controller/admin/valuable_add.php','8548643a397748f395f7b414aa329169'),(99,'./app/controller/admin/user_add.php','43b43c41fee6c9c049e0b8b6e3a4c858'),(100,'./app/controller/admin/scens.php','954bde231f20bbcd15aabb08b09203d9'),(101,'./app/controller/admin/scen_add.php','25f1ddd0f04a76a8eaeadb70be463b4b'),(102,'./app/controller/admin/indexes.php','9b27a777a0c716109409333b85539df5'),(103,'./app/controller/admin/sorter_index_edit.php','9e96f8210c19eff89abeee4514d37484'),(104,'./app/controller/admin/scen_reports.php','75d296427f1526da65e90a4de5338629'),(105,'./app/controller/admin/scen_edit.php','716a44e67279b795042582d13fc40d33'),(106,'./app/controller/admin/sorter_edit.php','6fa572872398ed946a03bfbbd60492d5'),(107,'./app/controller/admin/system.php','2d50411da4eb19b5b11ec601bf12db4e'),(108,'./app/controller/admin/currency_edit.php','6cfa062dab849a9b6e702d1da1bcf9ba'),(109,'./app/controller/admin/valuable_edit.php','f8fb9c84f60bd0708cc3904fe4781779'),(110,'./app/controller/admin/sorter_type_add.php','81440d1ac4cf7ee4326e3b28842deed5'),(111,'./app/controller/admin/denom_edit.php','93d6cec1e10e7b97a710025e68150750'),(112,'./app/controller/admin/grade_edit.php','14dfa5429ed983dcec553a7b46090200'),(113,'./app/controller/admin/deposit_index_add.php','02270126f6e0617a86607d16afe8e703'),(114,'./app/controller/admin/profile.php','a8f68eef386621c186d2228846927a0a'),(115,'./app/controller/admin/index.php','a13ac9031a8be4805462f4e265ff8666'),(116,'./app/controller/admin/deposit_index_edit.php','3d14d583a17be4f4bae73eb042c4cbe5'),(117,'./app/controller/admin/denom_add.php','14d665ebc6aff7da8258b63c2be1781b'),(118,'./app/controller/admin/valuables.php','62d177aa969c4c30a322b2423a274c84'),(119,'./app/controller/admin/sorter_index_add.php','609faea57e9c539c54c530de5a4a637d'),(120,'./app/controller/admin/users.php','2782b83bc8348304f964217abc39a28b'),(121,'./app/controller/admin/sorter_add.php','fa7380ccd1ee2f5f6c7b9a210f5136c9'),(122,'./app/controller/admin/user_ip_edit.php','eb1a68c73b89eeb85c5428948d89c7ce'),(123,'./app/controller/admin/valuable_type_edit.php','a121462087acc5e5747b58fd800bf3ad'),(124,'./app/controller/admin/client_edit.php','caf16c0f72f51dd53e17eb720efd07e3'),(125,'./app/controller/admin/scen_wizard.php','c871378a58baa9aeb0e6af7f28a3a594'),(126,'./app/controller/admin/valuable_type_add.php','d9f567708d8977afc41b68c119440de9'),(127,'./app/controller/admin/client_add.php','fc0bb69c3fa76e37dd5128e2906127b2'),(128,'./app/controller/admin/customers.php','c92fb0440c6ecdc871413a30478677c3'),(129,'./app/controller/admin/restore_scripts.php','8bc700eed6166f84daa2364a3fd4dfa4'),(130,'./app/controller/admin/grade_add.php','cb230bc00f7658dff4ed1c889324c8aa'),(131,'./app/controller/admin/user_ips.php','c7588870df98429639209796667aea36'),(132,'./app/controller/admin/change_password.php','95cc947087d36f3031142367c0e27e13'),(133,'./app/controller/admin/update.php','4712c2e4dd10eb92a4425ebd289a5d1e'),(134,'./app/controller/inspector/user_edit.php','3d214e99805cdb51c539b06eeb455cd9'),(135,'./app/controller/inspector/user_add.php','b03120f2aff242f5b495c9cb7a3506f7'),(136,'./app/controller/inspector/profile.php','a8f68eef386621c186d2228846927a0a'),(137,'./app/controller/inspector/index.php','a0a0070183f62631970b1594190a16ff'),(138,'./app/controller/inspector/users.php','af5227d928ae3cb546603d50a66143e8'),(139,'./app/controller/inspector/client_edit.php','6f658b3fa7e5525dfcaab0457566a575'),(140,'./app/controller/inspector/restore_scripts.php','33e64e1cec9cb511791cd10117a54251'),(141,'./app/controller/inspector/change_password.php','95cc947087d36f3031142367c0e27e13'),(142,'./app/controller/collector/simulator_collector.php','bfcd0dbdac8ae3b0bdd141f2bf4e1e88'),(143,'./app/controller/collector/cobra_collector.php','85f24ac3c4ea804eae3781d0277da9ac'),(144,'./app/controller/collector/collector.php','454f4832236c8005588ee36e2bf3112d'),(145,'./app/controller/collector/glory_collector.php','e8a8d3e1a865f50f3bd2868f459f5d72'),(146,'./app/controller/collector/toshiba_collector.php','2acc44e9fa78cfbe70d4ef56298b7f73'),(147,'./app/controller/select_sorter_type.php','21cd3d9cd10dbc1ac54545389d65bbc3'),(148,'./app/controller/operator/recon_total_update.php','3d8218704e4486c4ff72d9acbb9d72bc'),(149,'./app/controller/operator/act_by_recon.php','f166d072b91055382695d1c8da0fd6d2'),(150,'./app/controller/operator/profile.php','a8f68eef386621c186d2228846927a0a'),(151,'./app/controller/operator/reconciliation.php','2402bd9483e5d71184d227a2b1083f9b'),(152,'./app/controller/operator/index.php','919bdbecd72bdf336c522ec6cfa958e9'),(153,'./app/controller/operator/recon_reconcile.php','28cb7371a420cbfa8c25897d6398ba69'),(154,'./app/controller/operator/recon_discr_update.php','f508b5ae7a47e0f2ca5461b4c99aba88'),(155,'./app/controller/operator/recon_act_update.php','af0e09f4b643fe5f6cd32bab2f4ad7d0'),(156,'./app/controller/operator/recon_expected_update.php','b21411ab377aecd4eef20768f837ee45'),(157,'./app/controller/operator/users.php','802ffc5d3f23f93b72a0782eb397e4d6'),(158,'./app/controller/operator/recon_to_control.php','82642990e80844ab41457fbff9e967b3'),(159,'./app/controller/operator/recon_update.php','e35ad912c73e35e3d3233f005a5fcd98'),(160,'./app/controller/operator/restore_scripts.php','33e64e1cec9cb511791cd10117a54251'),(161,'./app/controller/operator/recon_stat_update.php','4e8640d78482920758c46a0a705c2812'),(162,'./app/controller/operator/reconciliation_report.php','130813c000dfccb54f273912fcf1051e'),(163,'./app/controller/operator/reconciled.php','b9ba0760a9693db7740111679f880bd7'),(164,'./app/controller/operator/change_password.php','95cc947087d36f3031142367c0e27e13'),(165,'./app/controller/operator/suspect_enter.php','b228141d3aa11a294350231ea0d7ce78'),(166,'./app/controller/set_default_scenario.php','8a62d6d0f67d60a4e6f18f26e2c3e175'),(167,'./app/controller/developer/get_file.php','6d83cb7aa56dd420eacb7b24de131fc2'),(168,'./app/controller/developer/get_app_archive.php','fa282138d676ccb6b6a963b94d03467e'),(169,'./app/controller/developer/edit_raw_table_add.php','96ec670a5eecd8ae8faf8efabd67b934'),(170,'./app/controller/developer/scenario_props_update.php','00557b24a50c9cbeab803f51a63eb012'),(171,'./app/controller/developer/edit_raw_table.php','d40c1df99298dc0e62ed8ae2bc26b625'),(172,'./app/controller/developer/files.php','f1885c35b54096f7f3cd00cbcecab6ce'),(173,'./app/controller/developer/scenario_options_update.php','bbfba4a9929a46562474597f13d2ab9b'),(174,'./app/controller/developer/envelope.php','56da079f641668e65215913f9c925463'),(175,'./app/controller/developer/upload_report.php','45b731e3cc63a3ef1eb091da8eb4ad53'),(176,'./app/controller/developer/scenario_config.php','2c0bd71a1c2f43c2361aba2b5eafca45'),(177,'./app/controller/developer/insert_data2.php','23209ac4f3683fb025c03c5b772bac87'),(178,'./app/controller/developer/insert_data3.php','8fb9cf12f2730bf3f6a69e495628bde7'),(179,'./app/controller/developer/get_archive.php','393c412b72b9cd844bf28540768aad31'),(180,'./app/controller/developer/profile.php','a8f68eef386621c186d2228846927a0a'),(181,'./app/controller/developer/index.php','5e0ed90f1d2778e0de98390e31879ca7'),(182,'./app/controller/developer/category_import.php','016f28323280f1a06d9abc5b55803107'),(183,'./app/controller/developer/obfuscator.php','d4d03808f3e111055618698b2973e77e'),(184,'./app/controller/developer/language.php','7656f92e3368bc3dab15ced806bd6242'),(185,'./app/controller/developer/sql.php','2c3166b1dbcb96b04efe0e58d1316ed3'),(186,'./app/controller/developer/edit_table_add.php','b459529d7427c8e669350a89674e475b'),(187,'./app/controller/developer/edit_table.php','e751237c7b77146e3fcda233ac7ffcaf'),(188,'./app/controller/developer/edit_raw_table_update.php','fed4faf67795012cdfc0c18fbc903435'),(189,'./app/controller/developer/refill_integrity.php','25e42238e25d211b56ae8593a81001fd'),(190,'./app/controller/developer/insert_data1.php','2af51075f6149d822130ece4570694ac'),(191,'./app/controller/developer/insert_data4.php','af2b20d01e07e255da4063189ae996e2'),(192,'./app/controller/developer/jobfuscator.php','08f94249a64305aeafd4dd618dd4adcf'),(193,'./app/controller/developer/edit_table_update.php','1d6179f5e58497d34b514fd5f3590e60'),(194,'./app/controller/developer/set_unset_od.php','1b0263f91bf0911ef8343bee6cd63a84'),(195,'./app/controller/developer/restore.php','37bce857e5f85ab23d18097e0e979b26'),(196,'./app/controller/developer/simulator.php','8b2e9065bf14112c95905f2229e7969e'),(197,'./app/controller/developer/reset_db.php','360c23bd26ffec4170a9a8c470a109b1'),(198,'./app/controller/developer/change_password.php','95cc947087d36f3031142367c0e27e13'),(199,'./app/controller/developer/update.php','eff4c0d50d1e910b303e6bee6dd5d193'),(200,'./app/view/set_remove_wait.php','85e420eee036f954a1ff3eca3bb2785b'),(201,'./app/view/html_header.php','2c7717aed36f97f8bcc8c8cd5f764c76'),(202,'./app/view/reload_after_1_min.php','ea7c524096132118cd5c2a74d1f4044a'),(203,'./app/view/record/delete.php','370c6947c5290964c40db8c636f58d6d'),(204,'./app/view/record/field_router.php','b4dd42860d1d702b3600278c21a2a8eb'),(205,'./app/view/record/readme.php','006920b4aa3b5acea2a04218f5e59f08'),(206,'./app/view/record/required_field_message.php','e865812fdbfb99b2cea68064bc3ab1a7'),(207,'./app/view/record/active_fields/select.php','4f4f84760a4c4e1de211feb170a6f855'),(208,'./app/view/record/active_fields/checker.php','5a626a385c146cd8e288494858fa5091'),(209,'./app/view/record/active_fields/text.php','6ae6f97850c27b2ee59ad11200f0ad8d'),(210,'./app/view/record/field_router_readonly.php','e9d6f2d0ea33c914428b4101ec32db9c'),(211,'./app/view/record/check_unique.php','7fbc2a274a2863a6161fbf34488dd68c'),(212,'./app/view/record/record_add.php','6a91e9e02c190765b2f6e408cbf9a108'),(213,'./app/view/record/clone.php','8a219b8724484906596c9528085cc249'),(214,'./app/view/record/start.php','f28081675e5fe2f903266ac5cc7d78c2'),(215,'./app/view/record/readonly_fields/select.php','cb2e0a3375323a6669762c2456ad7374'),(216,'./app/view/record/readonly_fields/readonly.php','58b5abb9f6d1acc0f45d5c6bb94fe56e'),(217,'./app/view/record/readonly_fields/checker.php','a5e27a2238e36bf1e860ef09330def76'),(218,'./app/view/record/readonly_fields/pointer.php','039884900ae2434a0332ea33e77083ba'),(219,'./app/view/record/readonly_fields/text.php','b886b6c90a9f1b2188b3aed705b0ba53'),(220,'./app/view/record/readonly_fields/logical.php','66742bf7b057f3810e0901f95e67fb70'),(221,'./app/view/record/record_edit.php','4688fde4f6c88b2f4e8c2acbefee8cf4'),(222,'./app/view/record/update.php','4435d79a54a25ac4af4068e337fbd879'),(223,'./app/view/draw_record_add.php','8b2d52eaf7d65451ee8ef8c1ecee847c'),(224,'./app/view/reports/akt_0402198.php','0b1c3aa0d18f6101a8dcd50f076dd97f'),(225,'./app/view/reports/confirm.php','d41985bec3e5b69c172ae1d92658aef9'),(226,'./app/view/reports/printed_0402145.php','1611bbce0b2a0aea182598d3d90fb8a3'),(227,'./app/view/reports/recresult_ext.php','3d8a9d1b4bb567070aa947f9a6da580f'),(228,'./app/view/reports/printed_0402145_complex.php','c08374b3632cf0e88bd43ec112f8b8b4'),(229,'./app/view/reports/rotated_page_css.php','ebd95c04ccd86fe9ee18620c41c6cdb9'),(230,'./app/view/reports/akt_0402145.php','850978afc2a2b7d861b4db94fd390b50'),(231,'./app/view/reports/printed_0402013.php','1005c4b028ebd051a741ef5efb8c064e'),(232,'./app/view/reports/c.php','471667659ca457c2d7f3751c175da546'),(233,'./app/view/reports/customer_rollup_printed.php','39918648ce5dfb993eb9119c462cf45f'),(234,'./app/view/reports/general_apk_printed_old.php','45f28aadd13fdf3c21385d2a20808ac4'),(235,'./app/view/reports/recresult.php','95fbd6aa070561025be63426c52b8239'),(236,'./app/view/reports/general_apk_printed.php','9009455238fe2bcf6a422ff9c3a2a51e'),(237,'./app/view/reports/printed_0402145_complex_fordeposit.php','1c4e312e0d136341d39c9299082990c7'),(238,'./app/view/reports/general_rollup_printed.php','61274abf47ec2c39f9be3ed981477897'),(239,'./app/view/reports/page_divider.php','1e911d0d9a120ba2456ca7a872f190c1'),(240,'./app/view/base_64_javascript.php','ac2ad28b67904898b2eca71aed4b2e88'),(241,'./app/view/page_header_with_logout.php','4b683dd854a1bf947a3cebaa99d4aae5'),(242,'./app/view/get_to_string.php','120ece367dc4423836036815978ab715'),(243,'./app/view/forms/act_by_reconciliation.php','b7bbcaf86f0d2b5787b0df0d13e42a80'),(244,'./app/view/forms/finished_reconciliation.php','34665d3e4c0d0aaccec90a4b7cffdc46'),(245,'./app/view/forms/new_reconciliation.php','5966804a662801de03c2ccddcb3e5993'),(246,'./app/view/forms/deferred_reconciliation.php','68a8c1ea55313b2db78ab8d250b8208d'),(247,'./app/view/forms/details_css.php','70453a04fb166fdc7641691827a0831a'),(248,'./app/view/forms/reconciliation_view.php','ff4ed99a1df31606f77f34ddbb6e0d76'),(249,'./app/view/danger_message.php','9d6de9e656a2c54de819699338eb57ae'),(250,'./app/view/bootstrap.php','ab5e6eb685289ff601275dbe99783185'),(251,'./app/view/remove_special_symbols.php','907fa03abc505b99e56041100a477ac6'),(252,'./app/view/password_was_not_changed.php','612d790fd2f3d72653278b1f3034b389'),(253,'./app/view/draw_select_table.php','27d367b8ff69246b2ed9106e45e33bd5'),(254,'./app/view/report_table_style.php','d5534703553a2d46b924071250e7e695'),(255,'./app/view/set_rs_to_stat.php','26532288ee56572a6230c63931c5fb37'),(256,'./app/view/print_array_as_html_table.php','3167a531e71fb5f937cb7a6cf157cfc2'),(257,'./app/view/draw_table.php','b472473d7d3c086418533508541842c7'),(258,'./app/view/error_message.php','edeca0065aa5125f271de6ec5cfcbc73'),(259,'./app/view/logout_link.php','5885932aef8355eea2d96ba8c1c1be47'),(260,'./app/view/under_development.php','d1c64d162966ddb8417030e2f234da7b'),(261,'./app/view/htmlfix.php','f1ca75409177bcd4b16f3988bb1f3093'),(262,'./app/view/info_message.php','3ccc79f86bdc1dff1796892d7547d156'),(263,'./app/view/reconciliation/against_value_new.php','85e539bbccaa9d62a099c285dc99db9d'),(264,'./app/view/reconciliation/against_value.php','f0b12e496b4677750bea58e04992a5e8'),(265,'./app/view/reconciliation/messages/wrong_recon_grades.php','57540641bcc2a804d1077fef7d8b6f56'),(266,'./app/view/reconciliation/messages/wrong_sorter_grades.php','ad9974695681f616d16ce42f197ccfc1'),(267,'./app/view/reconciliation/messages/non_single_denom.php','2220f0b3dd4db6904cdc3b8d627b006f'),(268,'./app/view/reconciliation/against_amount.php','f088a86717b034d1bb6b09a4232e730f'),(269,'./app/view/reconciliation/keyboard_driver.php','a9733c6104247fc8d09650ee7bdc54a5'),(270,'./app/view/reconciliation/amount/recon_data_total.php','2b31dc629aa63825f79c156f889dc5a7'),(271,'./app/view/reconciliation/amount/sorter_data_form.php','4f3a9ae98ff8fdb795cd9b51817b321c'),(272,'./app/view/reconciliation/amount/discrepancies.php','e04f5069ee39a452dc4cbc5817e32b39'),(273,'./app/view/reconciliation/amount/recon_data_input_form.php','dca52cf96c9f66857a683c2e365b79fc'),(274,'./app/view/reconciliation/buttons.php','b381a3c7c6089b30cc21b1851c6c0091'),(275,'./app/view/reconciliation/value/recon_data_total.php','4969974b873c86dae7f5ba8ad106e97a'),(276,'./app/view/reconciliation/value/sorter_data_form.php','4f3a9ae98ff8fdb795cd9b51817b321c'),(277,'./app/view/reconciliation/value/discrepancies.php','6c135e372febe4b3898074665d3f09f0'),(278,'./app/view/reconciliation/value/recon_data_input_form.php','76d9d029499fa6702f125efb9fb681b2'),(279,'./app/view/reconciliation/value/result_and_estimated.php','63ffb777c95e86263076d2442e3ff647'),(280,'./app/view/reconciliation/against_amount_new.php','533cf12bd3fbaf747bdce02f553dccc6'),(281,'./app/view/reconciliation/total.php','0fe061a78d5a748c0971db3fd34841cb'),(282,'./app/view/reconciliation/suspect_enter.php','60890c2170041fb596261348f61c2140'),(283,'./app/view/success_message.php','f013b0fab004b6a7d7c4eff3ffab41f7'),(284,'./app/view/html_head_bootstrap.php','d38ed2f87ee29d50d877aa8e7b617285'),(285,'./app/view/select_language.php','f14d94946ef321d6a4b8f48c4772e95a'),(286,'./app/view/repost_post.php','3a873887e920348a4c08c5559c051d9d'),(287,'./app/view/show_globals.php','34c0775b7dfe8ebfdbbbc154464ab537'),(288,'./app/view/password_was_changed.php','e34a1cf6149af2b25c08b32027ba7d64'),(289,'./app/view/login.php','d27df41b660c85e23ce8746ca003bc61'),(290,'./app/view/draw_record_edit.php','3dab1f96e0ebf624fbf2bacc005535d8'),(291,'./app/view/draw_editable_table.php','b3cdb802be8dcd53258a411b356aa802'),(292,'./app/view/update_record.php','8147f6da6b45560a4a8c6f11d281d1a6'),(293,'./app/view/draw_simple_table.php','4526fff56e37243d73602271382a8e5f'),(294,'./app/view/html_head_for_report.php','a9cfa6d13afd2df26b19f2aa1e8624ef'),(295,'./app/model/check_table_exist.php','bb504821fcb2586a913f5027e4b0ed36'),(296,'./app/model/record/admin_currency_record.php','83d14af3d53d909de2a3416cd8d97bc3'),(297,'./app/model/record/admin_sorter_index_record.php','dc8e45898a8b42460b0bea880edf176a'),(298,'./app/model/record/admin_scenario_record.php','727a00358b7d6cb0b0fcf3aa00e6874e'),(299,'./app/model/record/supervisor_signer_record.php','be1636aebc626119ef8a0d33747193b2'),(300,'./app/model/record/admin_deposit_index_record.php','6d6c68c83ffb2e8d857d94aa453c67b1'),(301,'./app/model/record/admin_grade_record.php','ac5157ef2d1b66a1c2989948a3bcace4'),(302,'./app/model/record/admin_denom_record.php','b09fb12aa49d0643d873a98af73621b4'),(303,'./app/model/record/admin_valuable_record.php','377b84e7c8edc9cb5c65691efd425bfc'),(304,'./app/model/record/admin_sorter_type_record.php','f102206bbddcda53766856e56fab2707'),(305,'./app/model/record/admin_sorter_record.php','d7f3e9353a4292785030bf4763b6cd37'),(306,'./app/model/record/admin_system_globals_record.php','af97c6eaaaa3c0468d92944c6573dcda'),(307,'./app/model/record/admin_valuable_type_record.php','57a135e28e5ed72032fcf2ff468b8667'),(308,'./app/model/lang/russian.php','ebfecef52435563004df36dd2e99b9d8'),(309,'./app/model/lang/english.php','066d8be2225b02352b56de40a2f42b6f'),(310,'./app/model/english_events.php','cd04be391b0881a3461a7830d00ab330'),(311,'./app/model/directories.php','70e12623f75b94e4432db60860689931'),(312,'./app/model/nmr2str_by_currency.php','4ab086ebbc708ebd45fdc49f99d58b31'),(313,'./app/model/int2str.php','8c310c8714176d13af2cea06e9b3d8a5'),(314,'./app/model/check_access_to_roles.php','2da0c9ef58afde52635bff479c0291a0'),(315,'./app/model/get_short_genetive_iof_by_user_id.php','e12865a0797a1967b6de56edafa9dc31'),(316,'./app/model/d.php','b149069e3a13680a6d8b9bbe2ed2780e'),(317,'./app/model/remove_special_symbols.php','28f4a7b3a29d47098967e6869e0d492d'),(318,'./app/model/dj.php','d71a59db4fcc69ce26ca252d71049a7b'),(319,'./app/model/db/fetch_row_from_sql.php','4f04123747545f34d7809e625de2a4cb'),(320,'./app/model/db/draw_table_from_sql.php','1b4cdc12b4e39cd81415cc211e9b79d0'),(321,'./app/model/db/fetch_fields_info_from_sql.php','3dcb46414acc5634bc78a38c92dbfff6'),(322,'./app/model/db/fetch_assoc_row_from_sql.php','efb3fdfe0ec32d4dc8a8cfe321895732'),(323,'./app/model/db/get_array_from_sql.php','67f8ed52a7b5cfdca8d2f088ef603e93'),(324,'./app/model/db/count_rows_from_sql.php','aff713041081318d462b88dc3c95dc79'),(325,'./app/model/db/get_assoc_array_from_sql.php','efb1397dd0470e7fc4d69ce16359defa'),(326,'./app/model/db/connection.php','ebfb060d234754e90348ec6336a2404b'),(327,'./app/model/db/do_sql.php','1af5e1c8866f747b29799b77fc2f54b2'),(328,'./app/model/system_log.php','c7329f292d88e7bcbf03e9c93c529ec7'),(329,'./app/model/report/get_report_signers.php','01e6b18d3fb62d6359dcf5863ae4cd5f'),(330,'./app/model/report/get_value_from_report_saves.php','5da7d586991cd2c721fae5b73e5abc26'),(331,'./app/model/report/add_xml_file_to_reportset.php','4e870ad4949c2b2d432d8a7b2bbc81fd'),(332,'./app/model/table/deffered_reconciliations.php','cd44ce7037c585a3fdbb05280caf646d'),(333,'./app/model/table/denoms.php','bd0ddcda3535d137441c2d7a85cf8dbe'),(334,'./app/model/table/grades.php','429df03d5e2f1c2b2ca862c0fca75919'),(335,'./app/model/table/sorter_types.php','289399332f5a2b22e72f68586dd74c4d'),(336,'./app/model/table/valuable_types.php','f7ecca5fe4ddfb3267a1b7443ffac018'),(337,'./app/model/table/sorter_accounting_data_by_card.php','3d20cc453dfa391a1e9d5dce8c0043b8'),(338,'./app/model/table/sorters.php','e9a7f43fa9f76c71604bb84d20d96d64'),(339,'./app/model/table/users_admin.php','02d2ee5b4a4555fcb605f7240779c5b6'),(340,'./app/model/table/new_valuables.php','ff1966b5e23a0a7fd468cbb3b787851d'),(341,'./app/model/table/backups_for_restore.php','dbe0746a9f67ff25068ba393f8d2eeb8'),(342,'./app/model/table/valuables.php','7e40af8962e2e45092b2d86f247e1a93'),(343,'./app/model/table/unreconciled_deposits_passive.php','06981aa62bdb3f7ad066457a21beca71'),(344,'./app/model/table/users.php','de8a8a24aaf7c2379b152f18cbe29040'),(345,'./app/model/table/backups.php','1eadf89794ceee75eade8dff33bd0533'),(346,'./app/model/table/for_check_reconciliations.php','df712cffd2dc646fef08e5541952179a'),(347,'./app/model/table/currencies.php','03dfbf3bcce3d52195f4b600ef7a7c67'),(348,'./app/model/table/unreconciled_deposits_by_separator_id.php','50155e50407f50c0df84af5b9783a418'),(349,'./app/model/table/unreconciled_deposits.php','98964c628f39d248974b880e6d27be5e'),(350,'./app/model/table/reports.php','44ee9cff4d558c4ee06573fee8925b79'),(351,'./app/model/table/reconciled_deposits.php','2badac4f0c7f86193ef92b40fec0047c'),(352,'./app/model/table/sorter_accounting_data_by_id.php','ccced8273fa455633add125295229c74'),(353,'./app/model/table/deffered_reconciliations_selectable.php','3582c178a101293a40e43b94650e64fb'),(354,'./app/model/table/sorter_indexes.php','b9914868a181736ed7846a8e54c34014'),(355,'./app/model/table/users_inspector.php','3b980cbf03d47fd1bc38449a9bd06283'),(356,'./app/model/table/reconciled_deposits_by_user.php','c2f08d62c575f81381c944cd81a8b9bd'),(357,'./app/model/table/customers.php','7e9c86bb6fdae34f781d12915db21e59'),(358,'./app/model/table/signers.php','2c77598498599f3b45d3d6433dc75fda'),(359,'./app/model/table/deposit_indexes.php','7a9bbf553d79c2767aa4d8052cff3f1b'),(360,'./app/model/table/deffered_reconciliations_by_user.php','22ba1c5621ec2c59fc02749700bb9fd5'),(361,'./app/model/table/scenario_reports.php','dfa79316f7112c0c57f441223fa93497'),(362,'./app/model/table/user_ips.php','61d7e7139cc983cc5c4c8f8dd2029c6a'),(363,'./app/model/table/updates.php','2419f52daa2c96adad3ef7220ae9911a'),(364,'./app/model/table/unreconciled_deposits_selectable.php','c152ce6897be986e77a6e4836b465120'),(365,'./app/model/table/new_category_names.php','f2d55ffa9c44b08a5613aa01329b2dc2'),(366,'./app/model/table/scenarios.php','7cb39904eb7b7b56ce304fb9c5a9ad42'),(367,'./app/model/get_short_iof_by_user_id.php','35bb3cc8c86d68440d7703c6b25b3393'),(368,'./app/model/menu.php','626bcae1e4cdb21435927b645bfd9345'),(369,'./app/model/get_browser_version.php','b058241203300997b632a3c00395f3d5'),(370,'./app/model/reconciliation/get_scenario_sorter_grades.php','170afc3d8dcbf8c2aff39645a50260e8'),(371,'./app/model/reconciliation/get_sorter_accounting_data_denoms_by_rec_id.php','3ce309210eeabe35408329ab2673ac2b'),(372,'./app/model/reconciliation/get_post_and_short_fio_by_user_id.php','7d895d0e0be001336db2ce03e0668a87'),(373,'./app/model/reconciliation/get_recon_accounting_data_grades.php','ef5b8063b3a392b54f1d2b29cb79b0ea'),(374,'./app/model/reconciliation/get_sort_operators_by_rec_id.php','998541f4526435bc20660b0e6e1c7e0d'),(375,'./app/model/reconciliation/get_sorter_accounting_data_currencies_by_rec_id.php','d25c731c0fc6971be5067b82154f3fa4'),(376,'./app/model/reconciliation/get_total_by_rec_denom.php','2d8676cc7e72063cf80f81520812198f'),(377,'./app/model/reconciliation/get_sorter_accounting_data_grades_by_cardnumber.php','f31ad3dba3fcf01ce8a65767624c77d6'),(378,'./app/model/reconciliation/get_sorter_accounting_data_currencies.php','91ae93527b44047a20c13d7c83f21e1e'),(379,'./app/model/reconciliation/get_recon_data_map_by_rec_id.php','47a98d272ba75d41c82ec77d1605d3bc'),(380,'./app/model/reconciliation/get_total_by_rec_denom_grade.php','a7ffcb3f75f4819e9c256df0e8479b82'),(381,'./app/model/reconciliation/get_recon_denom_total_by_recon_id.php','7f7a25d763dad4733d77e5f3a8608119'),(382,'./app/model/reconciliation/get_recon_acts_comments_by_id.php','0d2572cadd0b418f76a2d57f914ac85d'),(383,'./app/model/reconciliation/get_sorter_accounting_data_by_run_id.php','51c9f802a9a2f409ba50f470d61cd379'),(384,'./app/model/reconciliation/recon_function_load.php','6a3227c62a74645f83ae8a6c763a5103'),(385,'./app/model/reconciliation/get_indexes_by_rec_id.php','b4f7dcf2f1d9d7e057c63b76eac219e0'),(386,'./app/model/reconciliation/get_sorter_accounting_data_denoms_by_rec_id_and_currency.php','01c3f36fe43e0deec3452c48325e1b0a'),(387,'./app/model/reconciliation/get_reconciliation_by_id.php','d0294938e08459f5966e756ad16deaf3'),(388,'./app/model/reconciliation/get_reconciliation_by_sort_card_number.php','7072b39fca9e6692fd606c388c868d54'),(389,'./app/model/reconciliation/rebind_deposits_to_recon.php','e7bf41d7bb4f5fe90fd839611bb7f1fd'),(390,'./app/model/reconciliation/get_reconciled_deposit_by_rec_id.php','b3cd8ed1bff7ab5457a709578bb9d5f2'),(391,'./app/model/reconciliation/get_sorter_currency_by_rec_id.php','0898dcc7c9537b4a4d0e3598f2c2aa17'),(392,'./app/model/reconciliation/get_all_grade_ids_by_scenario_id.php','283e025ae6887507b18c12dbf05e863f'),(393,'./app/model/reconciliation/get_client_name_and_code_by_id.php','984b2f7e91208a270066db604017c67a'),(394,'./app/model/reconciliation/get_scenario_currency.php','618fafd3bc5976cdde0177d7065ec8d3'),(395,'./app/model/reconciliation/get_reconciled_deposit_by_sort_card_number.php','a1b10dbbce9a4471bf2c950bbebfb1a8'),(396,'./app/model/reconciliation/get_scenario_by_id.php','f61756fde748676a55f5d79cccdc5072'),(397,'./app/model/reconciliation/get_scenario_recon_grades.php','80a986c5c497d4ad26035cc366a3d13b'),(398,'./app/model/reconciliation/get_depositruns_by_rec_id.php','a91f63251978644c29619c4ed14f9caa'),(399,'./app/model/reconciliation/get_scenario_denoms_by_id.php','ba20e31eb98a0830d69367db6b77089c'),(400,'./app/model/reconciliation/get_recon_details_by_id.php','ed26a45162736dc85a2e0240fbb46921'),(401,'./app/model/reconciliation/get_machines_by_rec_id.php','ea713a0a86e977fbd15de0a3f595cb59'),(402,'./app/model/reconciliation/get_short_fio_by_user_id.php','a29d17c13cb6c255b0123be4d5fa068d'),(403,'./app/model/reconciliation/get_recon_accounting_data_by_rec_id.php','bde22920cb5b2679c4bf7edfd60c476d'),(404,'./app/model/reconciliation/get_sorter_start_and_stop_time_by_rec_id.php','36a01d235d9138efceaf9ea61befa152'),(405,'./app/model/reconciliation/get_sorter_accounting_data_by_rec_id.php','c4ff6c831100969dfc1926d19dd2b9c0'),(406,'./app/model/reconciliation/create_new_recon_value.php','786ed4ca99601ba7c4eec802a834cb2b'),(407,'./app/model/reconciliation/get_expected_by_denom_and_rec_id.php','6062629abbe5c36b0d6322f379aa9fe8'),(408,'./app/model/reconciliation/get_denoms_by_currency.php','7f5f1fc0c7052605595a6879e68148f6'),(409,'./app/model/reconciliation/get_scenario_denoms_by_id_and_currency.php','1cd34b04624a8f77033eceeae30a9338'),(410,'./app/model/reconciliation/get_recon_data_map_by_cardnumber.php','72f9c087146df651c26f1764056a1a9f'),(411,'./app/model/reconciliation/get_all_grades_by_scenario_id.php','862295f31e831bf8e84219917ab44a89'),(412,'./app/model/reconciliation/create_new_recon.php','f1fdbad211fa6acefbff2e3e35a2bc84'),(413,'./app/model/is_mobile.php','af1538d62107120cc6cda34a7528222e'),(414,'./app/model/auth/get_password_expired_date.php','12122f9f59d8bd3cdead4acf1bb44537'),(415,'./app/model/auth/check_auth.php','c93991e0cc2ac17c27416010192d19a1'),(416,'./app/model/auth/get_user_config.php','348cd72fe11a182858e791f94f720212'),(417,'./app/model/auth/users.php','6323a7c79412dc9212d9c9cd091bbe74'),(418,'./app/model/auth/less_then_three_days.php','8f720ce39085e1974c070ba428aea4e4'),(419,'./app/model/auth/set_log_attempts.php','ff44269e0eb80d0f80e6b8c65d12ee68'),(420,'./app/model/auth/block_user_id.php','f75fb541dce0ef699c093e7a3f2230ee'),(421,'./app/model/error_files.php','0655196c4cd2e1254a89475ee2b8fa7a'),(422,'./test.php','bffa82165f44ef11f4aec5de704e18ea'),(423,'./service/backup.php','d08c132554461911b51ead456a33ce43'),(424,'./service/module/collect_from_cobra.php','5015ad201b3497d39350d087dc87361a'),(425,'./service/module/make_files.php','b916984bafde6e16785e02cba75bd76d'),(426,'./service/module/tables_purge.php','aad75b3791eb3e19bb9a6ada3898eb04'),(427,'./service/collector.php','8b3f55ce5e3149d4d2e462800b369b79'),(428,'./service/restore.php','29c4295b102310d99a94a329941294bb'),(429,'./index.php','9c4b627501bf7288183d96ba44e0a357'),(430,'./test_2.php','dc88c1db0822611595a71d67e37e91d7'),(431,'./Bootstrap_files/bootstrap-tooltip.js','1a1189a48d6b964f0bc4ee5e0f0ca989'),(432,'./Bootstrap_files/bootstrap-transition.js','a05a07909ed90b9fd5ff5839046b33ee'),(433,'./Bootstrap_files/bootstrap-scrollspy.js','4177378655810b0741ed215df91dc8d4'),(434,'./Bootstrap_files/bootstrap-collapse.js','00f3b07c6f55b836e7ee6e587a024264'),(435,'./Bootstrap_files/bootstrap-popover.js','47c4e4a8a48200a2edfe5328f3388dae'),(436,'./Bootstrap_files/bootstrap-typeahead.js','6d2fe3aeb0b7133ad2dc4b5fbc562a4c'),(437,'./Bootstrap_files/bootstrap-alert.js','05c40571b0448661481aea6587f05664'),(438,'./Bootstrap_files/bootstrap-modal.js','f431c5a5af4004eba45e4b45c2a44332'),(439,'./Bootstrap_files/bootstrap-tab.js','a0b0c35980fd3689f57c73f5ff319a68'),(440,'./Bootstrap_files/bootstrap-dropdown.js','9e1498df28442f539b0a43fb5ea0b8cd'),(441,'./Bootstrap_files/bootstrap-button.js','b31d72ca96af7179356032e3b433304a'),(442,'./Bootstrap_files/bootstrap-carousel.js','a9a52d360096c21dce382a75ddb097c5'),(443,'./bootstrap/js/bootstrap.min.js','d700a93337122b390b90bbfe21e64f71'),(444,'./bootstrap/js/bootstrap.js','772ea2441e5fe335b0fa79df73be7c81'),(445,'./bootstrap/js/bootstrap-datepicker.ru.js','74d309adf7af3a880f6edbe1a2175c21'),(446,'./bootstrap/js/bootstrap-datepicker.js','fb71d038ccca1833eb5643f1f71f1137'),(447,'./js/jquery-2.0.2.min.js','6e18b5a96b1a354c922a5bba3d80cd13'),(448,'./js/jquery-1.10.1.min.js','33d85132f0154466fc017dd05111873d'),(449,'./js/base64_encode.js','bb5032b27faa89f176bad8030e397a80'),(450,'./js/md5.js','fdaf09669b40cca634686923e11e96cf'),(451,'./js/base64_decode.js','63fa2650ff6b527515d73de55f445b35'),(452,'./js/translit.js','60b9d8babbaf68f74ac1bdec56ee56da');
/*!40000 ALTER TABLE `IntegrityCheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Machines`
--

DROP TABLE IF EXISTS `Machines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Machines` (
  `MachineDBId` bigint(20) NOT NULL AUTO_INCREMENT,
  `SorterName` varchar(22) NOT NULL,
  `SerialNumber` varchar(24) DEFAULT NULL,
  `SorterTypeId` bigint(20) NOT NULL DEFAULT '1',
  `SorterVariant` varchar(24) DEFAULT NULL,
  `Softwarerelease` varchar(45) DEFAULT NULL,
  `CashRoomId` bigint(20) NOT NULL DEFAULT '1',
  `MachineLogicallyDeleted` tinyint(4) DEFAULT '0',
  `NetworkAddress` varchar(15) DEFAULT '192.168.0.10',
  `NetworkMask` varchar(15) DEFAULT '255.255.255.0',
  `NetworkPort` int(11) DEFAULT '3306',
  `MachineLogin` varchar(50) DEFAULT 'login',
  `MachinePass` varchar(50) DEFAULT 'password',
  `MachineDatabaseName` varchar(50) DEFAULT 'database',
  `MachineConnectionDirectory` varchar(255) DEFAULT '/',
  `MachineConnectionOn` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`MachineDBId`),
  UNIQUE KEY `MachineName_UNIQUE` (`SorterName`),
  KEY `Machines_MachineType_SorterTypes_idx` (`SorterTypeId`),
  KEY `Machines_CashRoomId_CashRooms_idx` (`CashRoomId`),
  CONSTRAINT `Machines_MachineType_SorterTypes` FOREIGN KEY (`SorterTypeId`) REFERENCES `SorterTypes` (`SorterTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Machines_CashRoomId_CashRooms` FOREIGN KEY (`CashRoomId`) REFERENCES `CashRooms` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Machines`
--

LOCK TABLES `Machines` WRITE;
/*!40000 ALTER TABLE `Machines` DISABLE KEYS */;
INSERT INTO `Machines` VALUES (1,'0007',NULL,1,'FS-2000','1',1,0,'192.168.0.10','255.255.255.0',3306,'login','password','database','/',0),(2,'151','400840',2,'Cobra-4004','17.005',1,0,'11.0.0.2','255.255.255.0',1433,'sa','','TransDBSQL','/',0),(3,'152','400679',2,'Cobra-4004','17.003',1,0,'192.168.0.10','255.255.255.0',3306,'login','password','database','/',0),(4,'251','400680',2,'Cobra-4004','17.003',1,0,'192.168.0.10','255.255.255.0',3306,'login','password','database','/',0),(5,'Simulator','1',2,'Simulator','0.1',1,0,'127.0.0.1','255.255.255.0',3306,'simulator','123456','simulator','/var/www/html/cashmaster/simulator',0);
/*!40000 ALTER TABLE `Machines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReconAccountingData`
--

DROP TABLE IF EXISTS `ReconAccountingData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReconAccountingData` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `DepositRecId` bigint(20) NOT NULL,
  `DenomId` bigint(20) NOT NULL,
  `GradeId` bigint(20) NOT NULL,
  `CullCount` int(11) NOT NULL DEFAULT '0',
  `ValuableTypeId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ReconAccountingData_DepositRecs_idx` (`DepositRecId`),
  KEY `ReconAccountingData_DenomId_Denoms_idx` (`DenomId`),
  KEY `ReconAccountingData_GradeId_Grades_idx` (`GradeId`),
  KEY `ReconAccountingData_ValuableTypeId_ValuableTypes_idx` (`ValuableTypeId`),
  CONSTRAINT `ReconAccountingData_DepositRecs` FOREIGN KEY (`DepositRecId`) REFERENCES `DepositRecs` (`DepositRecId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ReconAccountingData_DenomId_Denoms` FOREIGN KEY (`DenomId`) REFERENCES `Denoms` (`DenomId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ReconAccountingData_GradeId_Grades` FOREIGN KEY (`GradeId`) REFERENCES `Grades` (`GradeId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ReconAccountingData_ValuableTypeId_ValuableTypes` FOREIGN KEY (`ValuableTypeId`) REFERENCES `ValuableTypes` (`ValuableTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReconAccountingData`
--

LOCK TABLES `ReconAccountingData` WRITE;
/*!40000 ALTER TABLE `ReconAccountingData` DISABLE KEYS */;
/*!40000 ALTER TABLE `ReconAccountingData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Rejects`
--

DROP TABLE IF EXISTS `Rejects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rejects` (
  `RejectId` bigint(20) NOT NULL AUTO_INCREMENT,
  `RejectName` varchar(50) NOT NULL,
  `SorterTypeId` bigint(20) NOT NULL,
  `RejectMappingId` bigint(20) DEFAULT '0',
  `RejectDescription` varchar(100) NOT NULL,
  PRIMARY KEY (`RejectId`),
  KEY `Rejects_SorterTypeId_SorterTypes_idx` (`SorterTypeId`),
  CONSTRAINT `Rejects_SorterTypeId_SorterTypes` FOREIGN KEY (`SorterTypeId`) REFERENCES `SorterTypes` (`SorterTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rejects`
--

LOCK TABLES `Rejects` WRITE;
/*!40000 ALTER TABLE `Rejects` DISABLE KEYS */;
INSERT INTO `Rejects` VALUES (1,'10 Roubles (97) SFS-M',2,11,'Goznak-M'),(2,'10 Roubles (04) SFS-M',2,11,'Goznak-M'),(3,'10 Roubles Composite',2,13,'Composite'),(4,'10 Roubles (Mix) Xtape',2,14,'Cross Tape'),(5,'10 Roubles (Mix) Length',2,15,'Length'),(6,'10 Roubles (Mix) UV',2,16,'UV'),(7,'10 Roubles (Mix) IR',2,17,'IR'),(8,'10 Roubles (Mix) Mag',2,18,'Magnet'),(9,'10 Roubles (Mix) Mfd',2,19,'MFD'),(10,'10 Roubles (Mix) Double',2,110,'Double'),(11,'10 Roubles (Mix) Shiny Tape',2,111,'ShinyTape'),(12,'10 Roubles (97) SFS-F',2,12,'Goznak-F'),(13,'10 Roubles (04) SFS-F',2,12,'Goznak-F'),(14,'10 Roubles OCR Fail',2,113,'OCR BadRead'),(15,'10 Roubles Hotlist',2,114,'OCR Hotlist'),(16,'50 Roubles (Mix) Double',2,210,'Double'),(17,'50 Roubles (Mix) Xtape',2,24,'Cross Tape'),(18,'50 Roubles (Mix) UV',2,26,'UV'),(19,'50 Roubles (Mix) Mag',2,28,'Magnet'),(20,'50 Roubles OCR Pass',2,215,'OCR Pass'),(21,'50 Roubles OCF Fail',2,213,'OCR BadRead'),(22,'50 Roubles Hotlist',2,214,'OCR Hotlist'),(23,'50 Roubles (Mix) Shiny Tape',2,211,'ShynyTape'),(24,'50 Roubles (Mix) Length',2,25,'Length'),(25,'50 Roubles (Mix) IR',2,27,'IR'),(26,'50 Roubles (Mix) Mfd',2,29,'MFD'),(27,'50 Roubles (97) SFS-M',2,21,'Goznak-M'),(28,'50 Roubles (97) SFS-F',2,22,'Goznak-F'),(29,'50 Roubles (04) SFS-M',2,21,'Goznak-M'),(30,'50 Roubles (04) SFS-F',2,22,'Goznak-F'),(31,'50 Roubles Composite',2,23,'Composite'),(32,'100 Roubles (Mix) Double',2,310,'Double'),(33,'100 Roubles (Mix) Xtape',2,34,'CrossTape'),(34,'100 Roubles (Mix) UV',2,36,'UV'),(35,'100 Roubles (Mix) Mag',2,38,'Magnet'),(36,'100 Roubles OCR Fail',2,313,'OCR BadRead'),(37,'100 Roubles Hotlist',2,314,'OCR Hotlist'),(38,'100 Roubles (Mix) Shiny Tape',2,311,'ShinyTape'),(39,'100 Roubles (Mix) Length',2,35,'Length'),(40,'100 Roubles (Mix) IR',2,37,'IR'),(41,'100 Roubles (Mix) Mfd',2,39,'MFD'),(42,'100 Roubles (97) SFS-M',2,31,'Goznak-M'),(43,'100 Roubles (97) SFS-F',2,32,'Goznak-F'),(44,'100 Roubles (04) SFS-M',2,31,'Goznak-M'),(45,'100 Roubles (04) SFS-F',2,32,'Goznak-F'),(46,'100 Roubles OCR Pass',2,315,'OCR Pass'),(47,'100 Roubles Composite',2,33,'Composite'),(48,'500 Roubles (Mix) Double',2,410,'Double'),(49,'500 Roubles (Mix) Xtape',2,44,'CrossTape'),(50,'500 Roubles (Mix) UV',2,46,'UV'),(51,'500 Roubles (Mix) Mag',2,48,'Magnet'),(52,'500 Roubles (10) SFS-M',2,41,'Goznak-M'),(53,'500 Roubles OCR Pass',2,415,'OCR Pass'),(54,'500 Roubles Composite',2,43,'Composite'),(55,'500 Roubles (Mix) Shiny Tape',2,411,'ShinyTape'),(56,'500 Roubles (Mix) Length',2,45,'Length'),(57,'500 Roubles (Mix) IR',2,47,'IR'),(58,'500 Roubles (Mix) Mfd',2,49,'MFD'),(59,'500 Roubles (97) SFS-M',2,41,'Goznak-M'),(60,'500 Roubles (97) SFS-F',2,42,'Goznak-F'),(61,'500 Roubles (04) SFS-M',2,41,'Goznak-M'),(62,'500 Roubles (04) SFS-F',2,42,'Goznak-F'),(63,'500 Roubles (10) SFS-F',2,42,'Goznak-F'),(64,'500 Roubles OCR Fail',2,413,'OCR BadRead'),(65,'500 Roubles Hotlist',2,414,'OCR Hotlist'),(66,'1000 Roubles (Mix) Double',2,510,'Double'),(67,'1000 Roubles (Mix) Xtape',2,54,'CrossTape'),(68,'1000 Roubles (Mix) UV',2,56,'UV'),(69,'1000 Roubles (Mix) Mag',2,58,'Magnet'),(70,'1000 Roubles OCR Fail',2,513,'OCR BadRead'),(71,'1000 Roubles Hotlist',2,514,'OCR Hotlist'),(72,'1000 Roubles (Mix) Shiny Tape',2,511,'ShinyTape'),(73,'1000 Roubles (Mix) Length',2,55,'Length'),(74,'1000 Roubles (Mix) IR',2,57,'IR'),(75,'1000 Roubles (Mix) Mfd',2,59,'MFD'),(76,'1000 Roubles (97) SFS-M',2,51,'Goznak-M'),(77,'1000 Roubles (97) SFS-F',2,52,'Goznak-F'),(78,'1000 Roubles (04) SFS-M',2,51,'Goznak-M'),(79,'1000 Roubles (04) SFS-F',2,52,'Goznak-F'),(80,'1000 Roubles (10) SFS-M',2,51,'Goznak-M'),(81,'1000 Roubles (10) SFS-F',2,52,'Goznak-F'),(82,'1000 Roubles OCR Pass',2,515,'OCR Pass'),(83,'1000 Roubles Composite',2,53,'Composite'),(84,'5000 Roubles (Mix) Double',2,610,'Double'),(85,'5000 Roubles (10) SFS-M',2,61,'Goznak-M'),(86,'5000 Roubles OCR Pass',2,615,'OCR Pass'),(87,'5000 Roubles Composite',2,63,'Composite'),(88,'5000 Roubles (Mix) Shiny Tape',2,611,'ShinyTape'),(89,'5000 Roubles (Mix) Xtape',2,64,'CrossTape'),(90,'5000 Roubles (Mix) Length',2,65,'Length'),(91,'5000 Roubles (Mix) UV',2,66,'UV'),(92,'5000 Roubles (Mix) IR',2,67,'IR'),(93,'5000 Roubles (Mix) Mag',2,68,'Magnet'),(94,'5000 Roubles (Mix) Mfd',2,69,'MFD'),(95,'5000 Roubles (04) SFS-M',2,61,'Goznak-M'),(96,'5000 Roubles (04) SFS-F',2,62,'Goznak-F'),(97,'5000 Roubles (10) SFS-F',2,62,'Goznak-F'),(98,'5000 Roubles OCR Fail',2,613,'OCR BadRead'),(99,'5000 Roubles Hotlist',2,614,'OCR Hotlist'),(100,'OCR Fail',2,0,'Double'),(101,'Cull note',2,0,'Unrecognized'),(102,'10 Roubles (97) SFS-M',2,0,'Goznak_M'),(103,'10 Roubles (04) SFS-M',2,0,'Goznak_M'),(104,'10 Roubles Composite',2,0,'S/Ncomposite'),(105,'10 Roubles (Mix) Xtape',2,0,'CrossTape'),(106,'10 Roubles (Mix) Length',2,0,'Length'),(107,'10 Roubles (Mix) UV',2,0,'UltraViolet'),(108,'10 Roubles (Mix) IR',2,0,'InfraRed'),(109,'10 Roubles (Mix) Mag',2,0,'Magnetic'),(110,'10 Roubles (Mix) Mfd',2,0,'G&D Special'),(111,'10 Roubles (Mix) Double',2,0,'Double'),(112,'10 Roubles (Mix) Shiny Tape',2,0,'ShinyTape'),(113,'10 Roubles (97) SFS-F',2,0,'Goznak_F'),(114,'10 Roubles (04) SFS-F',2,0,'Goznak_F'),(115,'10 Roubles OCR Fail',2,0,'OCR fail'),(116,'10 Roubles Hotlist',2,0,'OCR hot list'),(117,'50 Roubles (Mix) Double',2,0,'Double'),(118,'50 Roubles (Mix) Xtape',2,0,'CrossTape'),(119,'50 Roubles (Mix) UV',2,0,'UltraViolet'),(120,'50 Roubles (Mix) Mag',2,0,'Magnetic'),(121,'50 Roubles OCF Fail',2,0,'OCR fail');
/*!40000 ALTER TABLE `Rejects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReportSaves`
--

DROP TABLE IF EXISTS `ReportSaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReportSaves` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ReportSetId` bigint(20) NOT NULL DEFAULT '0',
  `ReportTypeId` bigint(20) NOT NULL DEFAULT '0',
  `Key` varchar(50) DEFAULT NULL,
  `Value` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `ReportSets_ReportSetId_ReportSets_idx` (`ReportSetId`),
  KEY `ReportSets_ReportTypeId_REportTypes_idx` (`ReportTypeId`),
  CONSTRAINT `ReportSets_ReportSetId_ReportSets` FOREIGN KEY (`ReportSetId`) REFERENCES `ReportSets` (`SetId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ReportSets_ReportTypeId_REportTypes` FOREIGN KEY (`ReportTypeId`) REFERENCES `ReportTypes` (`ReportTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReportSaves`
--

LOCK TABLES `ReportSaves` WRITE;
/*!40000 ALTER TABLE `ReportSaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `ReportSaves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReportSets`
--

DROP TABLE IF EXISTS `ReportSets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReportSets` (
  `SetId` bigint(20) NOT NULL AUTO_INCREMENT,
  `SetDateTime` datetime NOT NULL,
  `CreatedBy` bigint(20) NOT NULL,
  `CashRoomId` bigint(20) NOT NULL,
  PRIMARY KEY (`SetId`),
  KEY `ReportPacks_UserId_UserConfiguration_idx` (`CreatedBy`),
  KEY `ReportPacks_CashRoomId_CashRooms_idx` (`CashRoomId`),
  CONSTRAINT `ReportSets_UserId_UserConfiguration` FOREIGN KEY (`CreatedBy`) REFERENCES `UserConfiguration` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ReportSets_CashRoomId_CashRooms` FOREIGN KEY (`CashRoomId`) REFERENCES `CashRooms` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReportSets`
--

LOCK TABLES `ReportSets` WRITE;
/*!40000 ALTER TABLE `ReportSets` DISABLE KEYS */;
INSERT INTO `ReportSets` VALUES (1,'0000-00-00 00:00:00',3,1);
/*!40000 ALTER TABLE `ReportSets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReportSignes`
--

DROP TABLE IF EXISTS `ReportSignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReportSignes` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `RepSeqId` bigint(20) NOT NULL,
  `SignerId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `SignerLog_ReportLog_SeqId_idx` (`RepSeqId`),
  KEY `SignerLog_Signers_SignerId_idx` (`SignerId`),
  CONSTRAINT `SignerLog_ReportLog_SeqId` FOREIGN KEY (`RepSeqId`) REFERENCES `Reports` (`SeqId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SignerLog_Signers_SignerId` FOREIGN KEY (`SignerId`) REFERENCES `ExternalUsers` (`ExternalUserId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReportSignes`
--

LOCK TABLES `ReportSignes` WRITE;
/*!40000 ALTER TABLE `ReportSignes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ReportSignes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReportTypes`
--

DROP TABLE IF EXISTS `ReportTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReportTypes` (
  `ReportTypeId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ReportLabel` varchar(80) NOT NULL,
  `DefaultReport` tinyint(4) NOT NULL DEFAULT '0',
  `NeedSigner` tinyint(4) NOT NULL DEFAULT '0',
  `GenerateXmlFile` tinyint(4) NOT NULL DEFAULT '0',
  `Description` varchar(300) DEFAULT NULL,
  `FileName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ReportTypeId`),
  UNIQUE KEY `ReportLabel_UNIQUE` (`ReportLabel`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReportTypes`
--

LOCK TABLES `ReportTypes` WRITE;
/*!40000 ALTER TABLE `ReportTypes` DISABLE KEYS */;
INSERT INTO `ReportTypes` VALUES (1,'Акт формы 0402145',0,0,0,'Акт о расхождении (отдельный акт для каждого расхождения)','printed_0402145.php'),(2,'Акт формы 0402145 обобщённый',0,0,0,'Акт о расхождении (все типы расхождений депозита в одном акте)','printed_0402145_complex.php'),(3,'Справка об обработанных банкнотах, форма 0402013',0,1,0,NULL,'printed_0402013.php'),(4,'Отчётная информация аппаратно-программного комплекса',0,1,0,'Выводит данные \nпо классам ГОДНЫЕ, ВЕТХИЕ, УНИЧТОЖЕННЫЕ в с группировкой по машинам, индексам, номиналам для одной валюты,\nа также суммарные данные и данные о кассовых просчётах','general_apk_printed.php'),(5,'Подробная сводная информация об обработке ценностей',0,1,0,'Выводит данные пересчёта в\nразрезе машин, операторов сверки, а также обобщённые данные и данные о кассовых\nпросчётах. Осуществляет разбивку по всем использованным классам.','general_rollup_printed.php'),(6,'Отчёт по клиентам',0,0,0,'Данные пересчётов в разрезе клиентов с разбивкой по\nвсем использованным классам, с указанием недостач и излишков.','customer_rollup_printed.php'),(7,'RECRESULT',0,0,1,'XML-файл','recresult.php'),(8,'RECRESULT (expanded mode)',0,0,1,'XML-файл','recresult_ext.php'),(9,'AKT0402198',0,0,1,'XML-файл','akt_0402198.php'),(10,'AKT0402145',0,0,1,'XML-файл. Отдельный для каждого вида расхождения в депозите','akt_0402145.php'),(11,'C',0,1,1,'XML-файл для АС ДНДО','c.php');
/*!40000 ALTER TABLE `ReportTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Reports`
--

DROP TABLE IF EXISTS `Reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Reports` (
  `SeqId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ReportTypeId` bigint(20) NOT NULL,
  `ReportSetId` bigint(20) NOT NULL,
  PRIMARY KEY (`SeqId`),
  KEY `ReportLastNumber_ReportId_Reports_idx` (`ReportTypeId`),
  KEY `Reports_ReportPackId_ReportPacks_idx` (`ReportSetId`),
  CONSTRAINT `Reports_ReportTypeId_ReportTypes` FOREIGN KEY (`ReportTypeId`) REFERENCES `ReportTypes` (`ReportTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Reports_ReportSetId_ReportPacks` FOREIGN KEY (`ReportSetId`) REFERENCES `ReportSets` (`SetId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reports`
--

LOCK TABLES `Reports` WRITE;
/*!40000 ALTER TABLE `Reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `Reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Roles`
--

DROP TABLE IF EXISTS `Roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Roles` (
  `RoleId` bigint(20) NOT NULL AUTO_INCREMENT,
  `RoleName` varchar(24) NOT NULL,
  `RoleLabel` varchar(45) DEFAULT NULL,
  `PasswordMinLength` int(11) NOT NULL DEFAULT '6',
  PRIMARY KEY (`RoleId`),
  UNIQUE KEY `RoleName_UNIQUE` (`RoleName`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Roles`
--

LOCK TABLES `Roles` WRITE;
/*!40000 ALTER TABLE `Roles` DISABLE KEYS */;
INSERT INTO `Roles` VALUES (1,'admin','администратор',12),(2,'supervisor','контролёр',6),(3,'operator','оператор',6),(4,'security','инспектор по безопасности',12),(5,'developer','разработчик',3);
/*!40000 ALTER TABLE `Roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ScenDenoms`
--

DROP TABLE IF EXISTS `ScenDenoms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ScenDenoms` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ScenarioId` bigint(20) NOT NULL,
  `DenomId` bigint(20) NOT NULL,
  `ValuableTypeId` bigint(20) NOT NULL,
  `IsUsed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `ScenDenoms_ScenarioId_Scenarios_idx` (`ScenarioId`),
  KEY `ScenDenoms_DenomId_Denoms_idx` (`DenomId`),
  KEY `ScenDenoms_ValuableTypeId_ValuableTypes_idx` (`ValuableTypeId`),
  CONSTRAINT `ScenDenoms_ScenarioId_Scenarios` FOREIGN KEY (`ScenarioId`) REFERENCES `Scenario` (`ScenarioId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ScenDenoms_DenomId_Denoms` FOREIGN KEY (`DenomId`) REFERENCES `Denoms` (`DenomId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ScenDenoms_ValuableTypeId_ValuableTypes` FOREIGN KEY (`ValuableTypeId`) REFERENCES `ValuableTypes` (`ValuableTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ScenDenoms`
--

LOCK TABLES `ScenDenoms` WRITE;
/*!40000 ALTER TABLE `ScenDenoms` DISABLE KEYS */;
INSERT INTO `ScenDenoms` VALUES (1,1,7,2,1),(2,1,8,2,1),(3,1,9,2,1),(4,1,10,2,1),(5,1,11,2,1),(6,1,12,2,1),(7,1,13,2,1),(8,2,7,2,1),(9,2,8,2,1),(10,2,9,2,1),(11,2,10,2,1),(12,2,11,2,1),(13,2,12,2,1),(14,2,13,2,1),(15,3,7,2,1),(16,3,8,2,1),(17,3,9,2,1),(18,3,10,2,1),(19,3,11,2,1),(20,3,12,2,1),(21,3,13,2,1),(22,4,14,2,1),(23,4,15,2,1),(24,4,16,2,1),(25,4,17,2,1),(26,4,18,2,1),(27,4,19,2,1),(28,4,20,2,1),(29,4,7,2,1),(30,4,8,2,1),(31,4,9,2,1),(32,4,10,2,1),(33,4,11,2,1),(34,4,12,2,1),(35,4,13,2,1),(36,1,1,2,0),(37,1,2,2,0),(38,1,3,2,0),(39,1,4,2,0),(40,1,5,2,0),(41,1,6,2,0),(42,1,14,2,0),(43,1,15,2,0),(44,1,16,2,0),(45,1,17,2,0),(46,1,18,2,0),(47,1,19,2,0),(48,1,20,2,0),(49,2,1,2,0),(50,2,2,2,0),(51,2,3,2,0),(52,2,4,2,0),(53,2,5,2,0),(54,2,6,2,0),(55,2,14,2,0),(56,2,15,2,0),(57,2,16,2,0),(58,2,17,2,0),(59,2,18,2,0),(60,2,19,2,0),(61,2,20,2,0),(62,4,1,2,0),(63,4,2,2,0),(64,4,3,2,0),(65,4,4,2,0),(66,4,5,2,0),(67,4,6,2,0),(68,3,1,2,0),(69,3,2,2,0),(70,3,3,2,0),(71,3,4,2,0),(72,3,5,2,0),(73,3,6,2,0),(74,3,14,2,0),(75,3,15,2,0),(76,3,16,2,0),(77,3,17,2,0),(78,3,18,2,0),(79,3,19,2,0),(80,3,20,2,0);
/*!40000 ALTER TABLE `ScenDenoms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ScenReconGrades`
--

DROP TABLE IF EXISTS `ScenReconGrades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ScenReconGrades` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ScenarioId` bigint(20) NOT NULL,
  `GradeId` bigint(20) NOT NULL,
  `ValuableTypeId` bigint(20) NOT NULL,
  `IsUsed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `ScenReconGrades_ScenarioId_Scenarios_idx` (`ScenarioId`),
  KEY `ScenReconGrades_Grades_GradeId_idx` (`GradeId`),
  KEY `ScenReconGrades_ValuableTypeId_ValuableTypes_idx` (`ValuableTypeId`),
  CONSTRAINT `ScenReconGrades_ScenarioId_Scenarios` FOREIGN KEY (`ScenarioId`) REFERENCES `Scenario` (`ScenarioId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ScenReconGrades_Grades_GradeId` FOREIGN KEY (`GradeId`) REFERENCES `Grades` (`GradeId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ScenReconGrades_ValuableTypeId_ValuableTypes` FOREIGN KEY (`ValuableTypeId`) REFERENCES `ValuableTypes` (`ValuableTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ScenReconGrades`
--

LOCK TABLES `ScenReconGrades` WRITE;
/*!40000 ALTER TABLE `ScenReconGrades` DISABLE KEYS */;
INSERT INTO `ScenReconGrades` VALUES (1,1,1,2,1),(2,1,2,2,1),(3,1,3,2,1),(4,2,1,2,1),(5,2,2,2,1),(6,2,3,2,1),(7,3,1,2,1),(8,3,6,2,1),(9,3,7,2,1),(10,3,8,2,1),(11,4,1,2,1),(12,4,4,2,1),(13,1,7,2,0),(14,1,8,2,0),(15,1,6,2,0),(16,1,4,2,0),(17,1,5,2,0),(18,2,7,2,0),(19,2,8,2,0),(20,2,6,2,0),(21,2,4,2,0),(22,2,5,2,0),(23,4,3,2,0),(24,4,2,2,0),(25,4,7,2,0),(26,4,8,2,0),(27,4,6,2,0),(28,4,5,2,0),(29,3,3,2,0),(30,3,2,2,0),(31,3,4,2,0),(32,3,5,2,0);
/*!40000 ALTER TABLE `ScenReconGrades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ScenReportTypes`
--

DROP TABLE IF EXISTS `ScenReportTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ScenReportTypes` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ScenarioId` bigint(20) NOT NULL,
  `ReportTypeId` bigint(20) NOT NULL,
  `IsUsed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `ScenReports_ScenarioId_Scenario_idx` (`ScenarioId`),
  KEY `ScenReports_ReportId_Reports_idx` (`ReportTypeId`),
  CONSTRAINT `ScenReports_ScenarioId_Scenario` FOREIGN KEY (`ScenarioId`) REFERENCES `Scenario` (`ScenarioId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ScenReportTypes_ReportTypeId_ReportTypes` FOREIGN KEY (`ReportTypeId`) REFERENCES `ReportTypes` (`ReportTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ScenReportTypes`
--

LOCK TABLES `ScenReportTypes` WRITE;
/*!40000 ALTER TABLE `ScenReportTypes` DISABLE KEYS */;
INSERT INTO `ScenReportTypes` VALUES (1,1,1,1),(2,1,2,0),(3,1,3,1),(4,1,4,0),(5,1,5,1),(6,1,6,0),(7,1,7,0),(8,1,8,1),(9,1,9,0),(10,1,10,0),(11,2,1,1),(12,2,2,0),(13,2,3,1),(14,2,4,0),(15,2,5,1),(16,2,6,0),(17,2,7,0),(18,2,8,8),(19,2,9,0),(20,2,10,0);
/*!40000 ALTER TABLE `ScenReportTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ScenSorterGrades`
--

DROP TABLE IF EXISTS `ScenSorterGrades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ScenSorterGrades` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ScenarioId` bigint(20) NOT NULL,
  `GradeId` bigint(20) NOT NULL,
  `ValuableTypeId` bigint(20) NOT NULL,
  `IsUsed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `ScenSorterGrades_scenarioId_Scenario_idx` (`ScenarioId`),
  KEY `ScenSorterGrades_GradeId_Grades_idx` (`GradeId`),
  KEY `ScenSorterGrades_ValuableTypeId_ValuableTypes_idx` (`ValuableTypeId`),
  CONSTRAINT `ScenSorterGrades_scenarioId_Scenario` FOREIGN KEY (`ScenarioId`) REFERENCES `Scenario` (`ScenarioId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ScenSorterGrades_GradeId_Grades` FOREIGN KEY (`GradeId`) REFERENCES `Grades` (`GradeId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ScenSorterGrades_ValuableTypeId_ValuableTypes` FOREIGN KEY (`ValuableTypeId`) REFERENCES `ValuableTypes` (`ValuableTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ScenSorterGrades`
--

LOCK TABLES `ScenSorterGrades` WRITE;
/*!40000 ALTER TABLE `ScenSorterGrades` DISABLE KEYS */;
INSERT INTO `ScenSorterGrades` VALUES (1,1,2,2,1),(2,1,3,2,1),(3,2,2,2,1),(4,2,5,2,1),(5,3,6,2,1),(6,3,7,2,1),(7,3,8,2,1),(8,4,4,2,1),(9,1,7,2,0),(10,1,8,2,0),(11,1,6,2,0),(12,1,1,2,0),(13,1,4,2,0),(14,1,5,2,0),(15,2,3,2,0),(16,2,7,2,0),(17,2,8,2,0),(18,2,6,2,0),(19,2,1,2,0),(20,2,4,2,0),(21,4,3,2,0),(22,4,2,2,0),(23,4,7,2,0),(24,4,8,2,0),(25,4,6,2,0),(26,4,1,2,0),(27,4,5,2,0),(28,3,3,2,0),(29,3,2,2,0),(30,3,1,2,0),(31,3,4,2,0),(32,3,5,2,0);
/*!40000 ALTER TABLE `ScenSorterGrades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ScenValuableTypes`
--

DROP TABLE IF EXISTS `ScenValuableTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ScenValuableTypes` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ScenarioId` bigint(20) NOT NULL,
  `ValuableTypeId` bigint(20) NOT NULL,
  `IsUsed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `ScenarioValuableTypes_ScenarioId_Scenarios_idx` (`ScenarioId`),
  KEY `ScenarioValuableTypes_ValuableTypeId_ValuableTypes_idx` (`ValuableTypeId`),
  CONSTRAINT `ScenValuableTypes_ScenarioId_Scenarios` FOREIGN KEY (`ScenarioId`) REFERENCES `Scenario` (`ScenarioId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ScenValuableTypes_ValuableTypeId_ValuableTypes` FOREIGN KEY (`ValuableTypeId`) REFERENCES `ValuableTypes` (`ValuableTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ScenValuableTypes`
--

LOCK TABLES `ScenValuableTypes` WRITE;
/*!40000 ALTER TABLE `ScenValuableTypes` DISABLE KEYS */;
INSERT INTO `ScenValuableTypes` VALUES (1,1,2,1),(2,2,2,1),(3,3,2,1),(4,4,2,1),(5,1,1,0),(6,2,1,0),(7,4,1,0),(8,3,1,0);
/*!40000 ALTER TABLE `ScenValuableTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Scenario`
--

DROP TABLE IF EXISTS `Scenario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Scenario` (
  `ScenarioId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ScenarioName` varchar(120) NOT NULL,
  `BlindReconciliation` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Deprecated',
  `DefExpectedNumber` int(11) NOT NULL DEFAULT '1000',
  `UsePackIntegrity` tinyint(4) NOT NULL DEFAULT '1',
  `UseStrapsIntegrity` tinyint(4) NOT NULL DEFAULT '1',
  `UseSealNumber` tinyint(4) NOT NULL DEFAULT '1',
  `UseSealType` tinyint(4) NOT NULL DEFAULT '1',
  `SingleDenomDeposits` tinyint(4) NOT NULL DEFAULT '1',
  `ReconcileAgainstValue` tinyint(4) NOT NULL DEFAULT '0',
  `DefaultScenario` tinyint(4) NOT NULL DEFAULT '0',
  `LogicallyDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `ForceDepositDetails` tinyint(4) NOT NULL DEFAULT '0',
  `UseStrapType` tinyint(4) NOT NULL DEFAULT '1',
  `UseSealIntegrity` tinyint(4) NOT NULL DEFAULT '1',
  `UsePackType` tinyint(4) NOT NULL DEFAULT '1',
  `UsePackId` tinyint(4) NOT NULL DEFAULT '1',
  `UseDepositPackingDate` tinyint(4) NOT NULL DEFAULT '1',
  `UsePackingOperatorName` tinyint(4) NOT NULL DEFAULT '1',
  `UseSuspectSerialNumbers` tinyint(4) NOT NULL DEFAULT '1',
  `CheckIndexes` tinyint(4) NOT NULL DEFAULT '1',
  `UsePreparationStep` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ScenarioId`),
  UNIQUE KEY `ScenarioName_UNIQUE` (`ScenarioName`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Scenario`
--

LOCK TABLES `Scenario` WRITE;
/*!40000 ALTER TABLE `Scenario` DISABLE KEYS */;
INSERT INTO `Scenario` VALUES (1,'Однономинальная сортировка банкнот на ГОДНЫЕ и ВЕТХИЕ',0,1000,1,1,1,1,1,0,1,0,0,1,1,1,1,1,1,1,1,0),(2,'Однономинальная сортировка банкнот с уничтожением ветхих банкнот',0,1000,0,0,1,1,1,0,0,0,0,1,0,1,1,1,1,1,1,0),(3,'Сортировка банкнот по модификациям выпуска',1,1000,1,0,1,1,1,0,0,0,1,0,0,1,0,0,0,1,1,0),(4,'Мультивалютный мультиноминальный пересчёт RUB и USD',0,1000,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0);
/*!40000 ALTER TABLE `Scenario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SorterAccountingData`
--

DROP TABLE IF EXISTS `SorterAccountingData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SorterAccountingData` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `DepositRunId` bigint(20) NOT NULL,
  `ValuableId` bigint(20) NOT NULL,
  `ActualCount` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `SorterAccountingData_DepositRuns_idx` (`DepositRunId`),
  KEY `SorterAccountingData_Valuables_idx` (`ValuableId`),
  CONSTRAINT `SorterAccountingData_DepositRuns` FOREIGN KEY (`DepositRunId`) REFERENCES `DepositRuns` (`DepositRunId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SorterAccountingData_Valuables` FOREIGN KEY (`ValuableId`) REFERENCES `Valuables` (`ValuableId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=694 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SorterAccountingData`
--

LOCK TABLES `SorterAccountingData` WRITE;
/*!40000 ALTER TABLE `SorterAccountingData` DISABLE KEYS */;
INSERT INTO `SorterAccountingData` VALUES (1,1,6,900),(2,1,7,10),(3,2,6,700),(4,2,7,200),(5,3,6,20),(6,3,7,1),(7,4,6,10),(8,5,19,294),(9,5,18,11),(10,5,14,537),(11,5,13,7),(12,6,19,810),(13,6,18,43),(14,6,14,29),(15,6,13,112),(16,7,21,50),(17,7,22,492),(18,7,23,5),(19,7,24,70),(20,7,25,81),(21,7,30,276),(22,8,21,7),(23,8,22,718),(24,8,23,13),(25,8,24,9),(26,8,25,100),(27,8,30,101),(28,9,21,130),(29,9,22,820),(30,9,23,3),(31,9,30,40),(32,10,21,8),(33,10,22,4),(34,10,23,207),(35,10,24,306),(36,10,25,3),(37,10,30,461),(38,11,23,9),(39,11,24,1),(40,12,23,3),(41,12,24,30),(42,13,1,10),(43,13,9,20),(44,13,12,10),(45,13,19,30),(46,13,24,10),(47,13,29,40),(48,13,36,10),(49,13,39,50),(50,13,49,10),(51,13,58,60),(52,13,67,10),(53,13,70,70),(54,13,71,1),(55,13,72,2),(56,13,73,4),(57,13,74,5),(58,13,75,6),(59,13,76,7),(60,13,77,8),(61,14,11,2),(62,14,12,3),(63,14,13,15),(64,14,14,969),(65,15,12,1),(66,15,13,8),(67,15,14,989),(68,16,11,1),(69,16,12,1),(70,16,13,3),(71,16,14,991),(72,17,11,10),(73,17,12,80),(74,17,13,181),(75,17,14,715),(76,18,13,9),(77,18,14,990),(78,19,13,3),(79,19,14,997),(80,20,11,9),(81,20,12,17),(82,20,13,10),(83,20,14,950),(84,21,21,13),(85,21,22,51),(86,21,23,7),(87,21,24,928),(88,22,21,1),(89,22,22,6),(90,22,23,19),(91,22,24,973),(92,23,21,1),(93,23,22,2),(94,23,23,3),(95,23,24,992),(96,24,23,17),(97,24,24,983),(98,25,21,4),(99,25,22,5),(100,25,23,10),(101,25,24,980),(102,26,32,1),(103,26,34,567),(104,26,36,430),(105,27,32,3),(106,27,34,900),(107,27,36,95),(108,28,32,2),(109,28,34,13),(110,28,36,980),(111,29,34,14),(112,29,36,986),(113,30,47,3),(114,30,49,900),(115,30,51,98),(116,31,47,3),(117,31,49,800),(118,31,51,196),(119,32,49,513),(120,32,51,478),(121,33,47,8),(122,33,49,423),(123,33,51,557),(124,34,49,750),(125,34,51,242),(126,35,49,690),(127,35,51,306),(128,36,21,8),(129,36,22,17),(130,36,23,6),(131,36,24,961),(132,37,21,1),(133,37,22,3),(134,37,23,5),(135,37,24,989),(136,38,23,4),(137,38,24,995),(138,39,23,2),(139,39,24,999),(140,40,23,10),(141,40,24,988),(142,41,32,6),(143,41,34,4),(144,41,36,990),(145,42,32,1),(146,42,34,15),(147,42,36,980),(148,43,32,7),(149,43,34,18),(150,43,36,974),(151,44,34,50),(152,44,36,947),(153,45,34,32),(154,45,36,965),(155,46,31,2),(156,46,32,4),(157,46,33,6),(158,46,34,8),(159,46,35,12),(160,46,36,966),(161,47,47,23),(162,47,49,89),(163,47,51,885),(164,48,47,70),(165,48,49,71),(166,48,51,857),(167,49,46,8),(168,49,47,17),(169,49,48,43),(170,49,49,132),(171,49,50,227),(172,49,51,571),(173,50,49,833),(174,50,51,167),(175,51,49,277),(176,51,51,722),(177,52,61,201),(178,52,62,13),(179,52,65,499),(180,52,67,286),(181,53,62,809),(182,53,67,190),(183,54,62,989),(184,54,67,12),(185,55,62,556),(186,55,67,443),(187,56,62,309),(188,56,67,687),(189,57,62,412),(190,57,67,583),(191,58,23,309),(192,58,24,17),(193,58,28,89),(194,58,29,580),(195,59,23,43),(196,59,24,16),(197,59,28,786),(198,59,29,150),(199,60,23,30),(200,60,24,40),(201,60,28,50),(202,60,29,878),(203,61,23,18),(204,61,24,450),(205,61,28,5),(206,61,29,524),(207,62,23,1),(208,62,24,89),(209,62,28,318),(210,62,29,591),(211,63,23,67),(212,63,24,66),(213,63,28,380),(214,63,29,483),(215,64,23,412),(216,64,24,9),(217,64,28,141),(218,64,29,437),(219,65,24,115),(220,65,28,229),(221,65,29,653),(222,66,33,8),(223,66,34,24),(224,66,35,658),(225,66,36,15),(226,66,41,70),(227,66,42,107),(228,66,43,22),(229,66,44,94),(230,67,33,15),(231,67,34,48),(232,67,35,535),(233,67,36,1),(234,67,41,31),(235,67,42,185),(236,67,43,13),(237,67,44,170),(238,68,33,81),(239,68,34,19),(240,68,35,310),(241,68,36,215),(242,68,41,18),(243,68,42,3),(244,68,43,249),(245,68,44,103),(246,69,33,5),(247,69,34,14),(248,69,35,451),(249,69,36,178),(250,69,41,3),(251,69,42,220),(252,69,43,101),(253,69,44,26),(254,70,33,105),(255,70,34,13),(256,70,35,334),(257,70,36,219),(258,70,41,78),(259,70,42,40),(260,70,43,31),(261,70,44,175),(262,71,33,30),(263,71,34,3),(264,71,35,390),(265,71,36,34),(266,71,41,81),(267,71,42,290),(268,71,43,17),(269,71,44,153),(270,72,33,193),(271,72,34,14),(272,72,35,35),(273,72,36,299),(274,72,41,307),(275,72,42,15),(276,72,43,68),(277,72,44,67),(278,73,48,430),(279,73,49,80),(280,73,50,16),(281,73,51,300),(282,73,56,6),(283,73,57,12),(284,73,58,17),(285,73,59,135),(286,74,48,291),(287,74,49,32),(288,74,50,315),(289,74,51,101),(290,74,56,40),(291,74,57,23),(292,74,58,32),(293,74,59,166),(294,75,48,87),(295,75,49,190),(296,75,50,165),(297,75,51,113),(298,75,56,159),(299,75,57,165),(300,75,58,117),(301,75,59,1),(302,76,48,102),(303,76,49,112),(304,76,50,103),(305,76,51,111),(306,76,56,104),(307,76,57,110),(308,76,58,105),(309,76,59,250),(310,77,48,98),(311,77,49,129),(312,77,50,97),(313,77,51,153),(314,77,56,99),(315,77,57,120),(316,77,58,87),(317,77,59,214),(318,78,13,250),(319,78,14,250),(320,78,18,250),(321,78,19,248),(322,79,13,132),(323,79,14,289),(324,79,18,115),(325,79,19,460),(326,80,13,401),(327,80,14,15),(328,80,18,402),(329,80,19,180),(330,81,13,698),(331,81,14,130),(332,81,18,34),(333,81,19,136),(334,82,13,17),(335,82,14,150),(336,82,18,40),(337,82,19,790),(338,83,13,356),(339,83,14,444),(340,83,18,198),(341,83,19,1),(342,84,23,566),(343,84,24,12),(344,84,28,421),(345,84,29,1),(346,85,23,560),(347,85,24,11),(348,85,28,413),(349,85,29,8),(350,86,23,370),(351,86,24,32),(352,86,28,55),(353,86,29,540),(354,87,23,218),(355,87,24,44),(356,87,28,529),(357,87,29,207),(358,88,23,1),(359,88,24,509),(360,88,28,13),(361,88,29,471),(362,89,33,18),(363,89,34,113),(364,89,35,201),(365,89,36,55),(366,89,41,40),(367,89,42,87),(368,89,43,7),(369,89,44,472),(370,90,33,243),(371,90,34,215),(372,90,35,6),(373,90,36,43),(374,90,41,118),(375,90,42,38),(376,90,43,68),(377,90,44,267),(378,91,33,187),(379,91,34,95),(380,91,35,99),(381,91,36,116),(382,91,41,7),(383,91,42,129),(384,91,43,200),(385,91,44,165),(386,92,33,190),(387,92,34,152),(388,92,35,103),(389,92,36,102),(390,92,41,5),(391,92,42,166),(392,92,43,107),(393,92,44,173),(394,93,33,92),(395,93,34,189),(396,93,35,99),(397,93,36,187),(398,93,41,177),(399,93,42,216),(400,93,43,1),(401,93,44,38),(402,94,33,12),(403,94,34,316),(404,94,35,5),(405,94,36,390),(406,94,41,8),(407,94,42,100),(408,94,43,3),(409,94,44,162),(410,95,61,13),(411,95,62,88),(412,95,65,366),(413,95,66,101),(414,95,67,90),(415,95,68,1),(416,95,69,2),(417,95,70,338),(418,96,61,90),(419,96,62,13),(420,96,65,171),(421,96,66,505),(422,96,67,3),(423,96,68,78),(424,96,69,79),(425,96,70,60),(426,97,61,276),(427,97,62,211),(428,97,65,215),(429,97,66,3),(430,97,67,3),(431,97,68,6),(432,97,69,29),(433,97,70,253),(434,98,13,23),(435,98,14,709),(436,98,15,229),(437,98,20,39),(438,99,13,40),(439,99,14,769),(440,99,15,177),(441,99,20,13),(442,100,13,49),(443,100,14,866),(444,100,15,15),(445,100,20,70),(446,101,13,44),(447,101,14,795),(448,101,15,39),(449,101,20,120),(450,102,13,115),(451,102,14,800),(452,102,15,5),(453,102,20,76),(454,103,13,2),(455,103,14,923),(456,103,15,8),(457,103,20,66),(458,104,13,7),(459,104,14,913),(460,104,15,14),(461,104,20,66),(462,105,23,815),(463,105,24,33),(464,105,25,9),(465,105,30,140),(466,106,23,77),(467,106,24,451),(468,106,25,10),(469,106,30,462),(470,107,23,480),(471,107,24,51),(472,107,25,336),(473,107,30,130),(474,108,23,47),(475,108,24,602),(476,108,25,303),(477,108,30,44),(478,109,23,71),(479,109,24,515),(480,109,25,70),(481,109,30,341),(482,110,23,334),(483,110,24,58),(484,110,25,416),(485,110,30,190),(486,111,23,7),(487,111,24,744),(488,111,25,133),(489,111,30,113),(490,112,23,76),(491,112,24,809),(492,112,25,57),(493,112,30,56),(494,113,23,344),(495,113,24,500),(496,113,25,3),(497,113,30,151),(498,114,23,30),(499,114,24,702),(500,114,25,44),(501,114,30,220),(502,115,23,190),(503,115,24,679),(504,115,25,17),(505,115,30,112),(506,116,23,150),(507,116,24,549),(508,116,25,49),(509,116,30,252),(510,117,23,314),(511,117,24,409),(512,117,25,17),(513,117,30,259),(514,118,48,45),(515,118,49,128),(516,118,50,400),(517,118,51,15),(518,118,52,2),(519,118,53,201),(520,118,60,207),(521,119,48,131),(522,119,49,10),(523,119,50,516),(524,119,51,27),(525,119,52,22),(526,119,53,30),(527,119,60,263),(528,120,48,76),(529,120,49,77),(530,120,50,544),(531,120,51,13),(532,120,52,120),(533,120,53,3),(534,120,60,160),(535,121,48,80),(536,121,49,15),(537,121,50,4),(538,121,51,609),(539,121,52,31),(540,121,53,5),(541,121,60,251),(542,122,48,477),(543,122,49,3),(544,122,50,120),(545,122,51,30),(546,122,52,1),(547,122,53,10),(548,122,60,359),(549,123,48,1),(550,123,49,1),(551,123,50,1),(552,123,51,17),(553,123,52,899),(554,123,53,23),(555,123,60,57),(556,124,50,899),(557,124,51,100),(558,125,4,2),(559,125,10,989),(560,126,4,1),(561,126,10,995),(562,127,4,3),(563,127,10,990),(564,128,15,4),(565,128,20,980),(566,129,15,6),(567,129,20,991),(568,130,15,8),(569,130,20,979),(570,131,25,12),(571,131,30,987),(572,132,25,7),(573,132,30,991),(574,133,25,20),(575,133,30,976),(576,134,37,40),(577,134,38,951),(578,134,45,2),(579,135,37,15),(580,135,38,970),(581,135,45,10),(582,136,37,1),(583,136,38,939),(584,136,45,54),(585,137,52,18),(586,137,53,962),(587,137,60,12),(588,138,52,22),(589,138,53,940),(590,138,60,38),(591,139,52,101),(592,139,53,846),(593,139,60,52),(594,140,63,997),(595,140,64,2),(596,141,63,980),(597,141,64,17),(598,142,63,950),(599,142,64,41),(600,143,63,401),(601,143,64,18),(602,144,4,8),(603,144,10,990),(604,145,4,3),(605,145,10,991),(606,146,4,7),(607,146,10,980),(608,147,15,14),(609,147,20,975),(610,148,15,18),(611,148,20,977),(612,149,15,4),(613,149,20,981),(614,150,30,994),(615,151,25,1),(616,151,30,992),(617,152,25,90),(618,152,30,911),(619,153,38,802),(620,153,45,190),(621,154,38,998),(622,154,45,1),(623,155,38,790),(624,155,45,206),(625,156,52,10),(626,156,53,977),(627,156,60,10),(628,157,52,1),(629,157,53,982),(630,157,60,10),(631,158,52,508),(632,158,53,409),(633,158,60,81),(634,159,63,971),(635,159,64,24),(636,160,63,966),(637,160,64,29),(638,161,63,980),(639,161,64,17),(640,162,63,516),(641,162,64,61),(642,163,48,15),(643,163,49,430),(644,163,50,88),(645,163,51,155),(646,163,52,172),(647,163,53,40),(648,164,48,2),(649,164,49,36),(650,164,50,18),(651,164,51,23),(652,164,52,3),(653,164,53,13),(654,165,49,217),(655,165,50,451),(656,165,51,88),(657,165,52,1),(658,165,53,227),(659,166,49,335),(660,166,50,506),(661,166,51,30),(662,166,52,5),(663,166,53,117),(664,167,49,334),(665,167,50,505),(666,167,51,28),(667,167,52,3),(668,167,53,111),(669,168,49,1),(670,168,50,2),(671,168,51,3),(672,168,52,1),(673,168,53,1),(674,169,49,324),(675,169,50,495),(676,169,51,18),(677,169,52,1),(678,169,53,101),(679,170,49,10),(680,170,50,9),(681,170,51,8),(682,170,52,7),(683,170,53,5),(684,171,49,321),(685,171,50,231),(686,171,51,355),(687,171,52,40),(688,171,53,31),(689,172,49,3),(690,172,50,19),(691,172,51,1),(692,172,52,2),(693,172,53,5);
/*!40000 ALTER TABLE `SorterAccountingData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SorterIndexes`
--

DROP TABLE IF EXISTS `SorterIndexes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SorterIndexes` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `IndexName` varchar(22) NOT NULL,
  `DepositIndexId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IndexName_UNIQUE` (`IndexName`),
  KEY `SorterIndexes_DepositIndexId_DepositIndex_idx` (`DepositIndexId`),
  CONSTRAINT `SorterIndexes_DepositIndexId_DepositIndex` FOREIGN KEY (`DepositIndexId`) REFERENCES `DepositIndex` (`DepositIndexId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SorterIndexes`
--

LOCK TABLES `SorterIndexes` WRITE;
/*!40000 ALTER TABLE `SorterIndexes` DISABLE KEYS */;
INSERT INTO `SorterIndexes` VALUES (1,'Index_3',1),(2,'Index_4',2),(3,'Index_5',3),(4,'инд. 3',1),(5,'инд. 4',2),(6,'инд. 5',3);
/*!40000 ALTER TABLE `SorterIndexes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SorterRejectData`
--

DROP TABLE IF EXISTS `SorterRejectData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SorterRejectData` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `DepositRunId` bigint(20) NOT NULL,
  `RejectId` bigint(20) NOT NULL,
  `CullCount` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `SorterRejectData_DepositRunId_DepositRuns_idx` (`DepositRunId`),
  KEY `SorterRejectData_RejectId_Rejects_idx` (`RejectId`),
  CONSTRAINT `SorterRejectData_DepositRunId_DepositRuns` FOREIGN KEY (`DepositRunId`) REFERENCES `DepositRuns` (`DepositRunId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SorterRejectData_RejectId_Rejects` FOREIGN KEY (`RejectId`) REFERENCES `Rejects` (`RejectId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SorterRejectData`
--

LOCK TABLES `SorterRejectData` WRITE;
/*!40000 ALTER TABLE `SorterRejectData` DISABLE KEYS */;
INSERT INTO `SorterRejectData` VALUES (1,1,9,3),(2,1,7,1),(3,1,9,3);
/*!40000 ALTER TABLE `SorterRejectData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SorterTypes`
--

DROP TABLE IF EXISTS `SorterTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SorterTypes` (
  `SorterTypeId` bigint(20) NOT NULL AUTO_INCREMENT,
  `SorterType` varchar(24) NOT NULL,
  PRIMARY KEY (`SorterTypeId`),
  UNIQUE KEY `SorterType_UNIQUE` (`SorterType`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SorterTypes`
--

LOCK TABLES `SorterTypes` WRITE;
/*!40000 ALTER TABLE `SorterTypes` DISABLE KEYS */;
INSERT INTO `SorterTypes` VALUES (2,'Cobra'),(1,'FS-2000'),(3,'Glory');
/*!40000 ALTER TABLE `SorterTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SuspectSerialNumbs`
--

DROP TABLE IF EXISTS `SuspectSerialNumbs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SuspectSerialNumbs` (
  `SequenceId` bigint(20) NOT NULL AUTO_INCREMENT,
  `DepositRecId` bigint(20) NOT NULL,
  `DenomId` bigint(20) NOT NULL,
  `LeftSeria` varchar(5) DEFAULT NULL,
  `LeftNumber` varchar(10) DEFAULT NULL,
  `RightSeria` varchar(5) DEFAULT NULL,
  `RightNumber` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`SequenceId`),
  KEY `NoteSerialNumber_DepositRecId_DepositRecs_idx` (`DepositRecId`),
  KEY `SuspectSerialNumbs_DenomId_Denoms_idx` (`DenomId`),
  CONSTRAINT `SuspectSerialNumber_DepositRecId_DepositRecs` FOREIGN KEY (`DepositRecId`) REFERENCES `DepositRecs` (`DepositRecId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SuspectSerialNumbs_DenomId_Denoms` FOREIGN KEY (`DenomId`) REFERENCES `Denoms` (`DenomId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SuspectSerialNumbs`
--

LOCK TABLES `SuspectSerialNumbs` WRITE;
/*!40000 ALTER TABLE `SuspectSerialNumbs` DISABLE KEYS */;
/*!40000 ALTER TABLE `SuspectSerialNumbs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SystemGlobals`
--

DROP TABLE IF EXISTS `SystemGlobals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SystemGlobals` (
  `SystemGlobalsId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CashCenterName` varchar(80) NOT NULL,
  `CashCenterCity` varchar(45) NOT NULL,
  `CashCenterCode` varchar(30) NOT NULL,
  `KPCode` varchar(30) DEFAULT NULL,
  `OKATOCode` varchar(30) DEFAULT NULL,
  `ComplexName` varchar(80) DEFAULT NULL,
  `DefaultLanguage` varchar(45) NOT NULL DEFAULT 'English',
  `AllowRecBySupervisor` tinyint(4) NOT NULL DEFAULT '0',
  `FilesCorrupted` tinyint(4) NOT NULL DEFAULT '0',
  `CheckOperDay` tinyint(4) NOT NULL DEFAULT '0',
  `OperDayStatus` tinyint(4) NOT NULL DEFAULT '0',
  `AutoArchivePeriod` int(11) NOT NULL DEFAULT '14',
  `LeaveDataFor` int(11) NOT NULL DEFAULT '14',
  `ServiceMode` tinyint(4) NOT NULL DEFAULT '0',
  `LastArchiveDate` datetime NOT NULL DEFAULT '1972-11-29 00:00:00',
  `FastenUserToIp` tinyint(4) NOT NULL DEFAULT '0',
  `UseGenitiveName` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`SystemGlobalsId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SystemGlobals`
--

LOCK TABLES `SystemGlobals` WRITE;
/*!40000 ALTER TABLE `SystemGlobals` DISABLE KEYS */;
INSERT INTO `SystemGlobals` VALUES (1,'МРХ г. С.-Петербург ЦХ Банка России','Санкт-Петербург','44083002','43','43','АПК на базе ССМ Кобра-4004','Russian',0,0,0,0,14,14,1,'1972-11-29 00:00:00',1,1);
/*!40000 ALTER TABLE `SystemGlobals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SystemLog`
--

DROP TABLE IF EXISTS `SystemLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SystemLog` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Event number (refer to the file)',
  `DateAndTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Comment` varchar(254) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=532 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SystemLog`
--

LOCK TABLES `SystemLog` WRITE;
/*!40000 ALTER TABLE `SystemLog` DISABLE KEYS */;
INSERT INTO `SystemLog` VALUES (1,'2014-03-26 11:14:48','Hash  for file ./app/controller/common/refill_integrity_check.php was added!'),(2,'2014-03-26 11:14:48','Hash  for file ./app/controller/common/check_finished_recon_by_scenario.php was added!'),(3,'2014-03-26 11:14:48','Hash  for file ./app/controller/common/envelope.php was added!'),(4,'2014-03-26 11:14:48','Hash  for file ./app/controller/common/profile_old.php was added!'),(5,'2014-03-26 11:14:49','Hash  for file ./app/controller/common/profile.php was added!'),(6,'2014-03-26 11:14:49','Hash  for file ./app/controller/common/check_scenario_valuable_grades.php was added!'),(7,'2014-03-26 11:14:49','Hash  for file ./app/controller/common/set_systemconfiguration.php was added!'),(8,'2014-03-26 11:14:49','Hash  for file ./app/controller/common/report/add_reports_seq.php was added!'),(9,'2014-03-26 11:14:49','Hash  for file ./app/controller/common/report/fill_report_signers.php was added!'),(10,'2014-03-26 11:14:49','Hash  for file ./app/controller/common/report/fill_report_saves.php was added!'),(11,'2014-03-26 11:14:49','Hash  for file ./app/controller/common/report/set_active_record_set_id.php was added!'),(12,'2014-03-26 11:14:49','Hash  for file ./app/controller/common/report/check_operation_day_status.php was added!'),(13,'2014-03-26 11:14:49','Hash  for file ./app/controller/common/report/get_scens_by_reportset_period.php was added!'),(14,'2014-03-26 11:14:50','Hash  for file ./app/controller/common/report/preview_report.php was added!'),(15,'2014-03-26 11:14:50','Hash  for file ./app/controller/common/report/generate_report.php was added!'),(16,'2014-03-26 11:14:50','Hash  for file ./app/controller/common/report/select_signers.php was added!'),(17,'2014-03-26 11:14:50','Hash  for file ./app/controller/common/report/get_reports_by_used_scen_ids.php was added!'),(18,'2014-03-26 11:14:50','Hash  for file ./app/controller/common/report/check_needed_reports_files.php was added!'),(19,'2014-03-26 11:14:50','Hash  for file ./app/controller/common/restore_application.php was added!'),(20,'2014-03-26 11:14:50','Hash  for file ./app/controller/common/scen_wizard/sorter_grades.php was added!'),(21,'2014-03-26 11:14:50','Hash  for file ./app/controller/common/scen_wizard/denoms.php was added!'),(22,'2014-03-26 11:14:51','Hash  for file ./app/controller/common/scen_wizard/valuable_types.php was added!'),(23,'2014-03-26 11:14:51','Hash  for file ./app/controller/common/scen_wizard/valuable_grades.php was added!'),(24,'2014-03-26 11:14:51','Hash  for file ./app/controller/common/scen_wizard/recon_grades.php was added!'),(25,'2014-03-26 11:14:51','Hash  for file ./app/controller/common/scen_wizard/finish.php was added!'),(26,'2014-03-26 11:14:51','Hash  for file ./app/controller/common/users.php was added!'),(27,'2014-03-26 11:14:51','Hash  for file ./app/controller/common/refill_integrity_check_restore.php was added!'),(28,'2014-03-26 11:14:51','Hash  for file ./app/controller/common/reconciliation/check_recon_indexes.php was added!'),(29,'2014-03-26 11:14:52','Hash  for file ./app/controller/common/reconciliation/auto_change_scenario.php was added!'),(30,'2014-03-26 11:14:52','Hash  for file ./app/controller/common/reconciliation/check_grades.php was added!'),(31,'2014-03-26 11:14:52','Hash  for file ./app/controller/common/reconciliation/check_currencies.php was added!'),(32,'2014-03-26 11:14:52','Hash  for file ./app/controller/common/reconciliation/check_single_denom.php was added!'),(33,'2014-03-26 11:14:52','Hash  for file ./app/controller/common/reconciliation/check_suspect.php was added!'),(34,'2014-03-26 11:14:52','Hash  for file ./app/controller/common/reconciliation/check_recon_accounting_data_finish.php was added!'),(35,'2014-03-26 11:14:52','Hash  for file ./app/controller/common/reconciliation/check_indexes.php was added!'),(36,'2014-03-26 11:14:52','Hash  for file ./app/controller/common/reconciliation/check_sorter_accounting_data.php was added!'),(37,'2014-03-26 11:14:52','Hash  for file ./app/controller/common/reconciliation/check_recon_status.php was added!'),(38,'2014-03-26 11:14:53','Hash  for file ./app/controller/common/reconciliation/check_recon_accounting_data.php was added!'),(39,'2014-03-26 11:14:53','Hash  for file ./app/controller/common/reconciliation/check_discr_form_fill.php was added!'),(40,'2014-03-26 11:14:53','Hash  for file ./app/controller/common/reconciliation/check_denoms.php was added!'),(41,'2014-03-26 11:14:53','Hash  for file ./app/controller/common/reconciliation/check_new_valuables.php was added!'),(42,'2014-03-26 11:14:53','Hash  for file ./app/controller/common/reconciliation/set_count_if_no_scenario.php was added!'),(43,'2014-03-26 11:14:53','Hash  for file ./app/controller/common/reconciliation/new_recon_checker.php was added!'),(44,'2014-03-26 11:14:54','Hash  for file ./app/controller/common/integrity_check.php was added!'),(45,'2014-03-26 11:14:54','Hash  for file ./app/controller/common/restore_scripts.php was added!'),(46,'2014-03-26 11:14:54','Hash  for file ./app/controller/common/change_password.php was added!'),(47,'2014-03-26 11:14:54','Hash  for file ./app/controller/auth.php was added!'),(48,'2014-03-26 11:14:54','Hash  for file ./app/controller/logout.php was added!'),(49,'2014-03-26 11:14:55','Hash  for file ./app/controller/supervisor/user_edit.php was added!'),(50,'2014-03-26 11:14:55','Hash  for file ./app/controller/supervisor/deposit_manager_actions.php was added!'),(51,'2014-03-26 11:14:55','Hash  for file ./app/controller/supervisor/signer_add.php was added!'),(52,'2014-03-26 11:14:55','Hash  for file ./app/controller/supervisor/recon_reconcile_with_discrep.php was added!'),(53,'2014-03-26 11:14:55','Hash  for file ./app/controller/supervisor/recon_total_update.php was added!'),(54,'2014-03-26 11:14:55','Hash  for file ./app/controller/supervisor/recon_view.php was added!'),(55,'2014-03-26 11:14:56','Hash  for file ./app/controller/supervisor/sorter_data.php was added!'),(56,'2014-03-26 11:14:56','Hash  for file ./app/controller/supervisor/act_by_recon.php was added!'),(57,'2014-03-26 11:14:56','Hash  for file ./app/controller/supervisor/profile.php was added!'),(58,'2014-03-26 11:14:56','Hash  for file ./app/controller/supervisor/preview_reports.php was added!'),(59,'2014-03-26 11:14:56','Hash  for file ./app/controller/supervisor/reportset_view.php was added!'),(60,'2014-03-26 11:14:56','Hash  for file ./app/controller/supervisor/index_conflict.php was added!'),(61,'2014-03-26 11:14:56','Hash  for file ./app/controller/supervisor/reconciliation.php was added!'),(62,'2014-03-26 11:14:56','Hash  for file ./app/controller/supervisor/index.php was added!'),(63,'2014-03-26 11:14:56','Hash  for file ./app/controller/supervisor/recon_reconcile.php was added!'),(64,'2014-03-26 11:14:57','Hash  for file ./app/controller/supervisor/recon_discr_update.php was added!'),(65,'2014-03-26 11:14:57','Hash  for file ./app/controller/supervisor/reports_archive.php was added!'),(66,'2014-03-26 11:14:57','Hash  for file ./app/controller/supervisor/recon_act_update.php was added!'),(67,'2014-03-26 11:14:57','Hash  for file ./app/controller/supervisor/recon_expected_update.php was added!'),(68,'2014-03-26 11:14:57','Hash  for file ./app/controller/supervisor/users.php was added!'),(69,'2014-03-26 11:14:57','Hash  for file ./app/controller/supervisor/recon_to_control.php was added!'),(70,'2014-03-26 11:14:57','Hash  for file ./app/controller/supervisor/client_edit.php was added!'),(71,'2014-03-26 11:14:57','Hash  for file ./app/controller/supervisor/recon_update.php was added!'),(72,'2014-03-26 11:14:57','Hash  for file ./app/controller/supervisor/reports.php was added!'),(73,'2014-03-26 11:14:58','Hash  for file ./app/controller/supervisor/create_reports.php was added!'),(74,'2014-03-26 11:14:58','Hash  for file ./app/controller/supervisor/client_add.php was added!'),(75,'2014-03-26 11:14:58','Hash  for file ./app/controller/supervisor/customers.php was added!'),(76,'2014-03-26 11:14:58','Hash  for file ./app/controller/supervisor/signers.php was added!'),(77,'2014-03-26 11:14:58','Hash  for file ./app/controller/supervisor/restore_scripts.php was added!'),(78,'2014-03-26 11:14:58','Hash  for file ./app/controller/supervisor/recon_stat_update.php was added!'),(79,'2014-03-26 11:14:58','Hash  for file ./app/controller/supervisor/reconciliation_report.php was added!'),(80,'2014-03-26 11:14:58','Hash  for file ./app/controller/supervisor/deposit_manager.php was added!'),(81,'2014-03-26 11:14:58','Hash  for file ./app/controller/supervisor/reconciled.php was added!'),(82,'2014-03-26 11:14:59','Hash  for file ./app/controller/supervisor/change_password.php was added!'),(83,'2014-03-26 11:14:59','Hash  for file ./app/controller/supervisor/suspect_enter.php was added!'),(84,'2014-03-26 11:14:59','Hash  for file ./app/controller/supervisor/deposit_manager_actions/rec_to_service.php was added!'),(85,'2014-03-26 11:14:59','Hash  for file ./app/controller/supervisor/deposit_manager_actions/runs_to_service.php was added!'),(86,'2014-03-26 11:14:59','Hash  for file ./app/controller/supervisor/deposit_manager_actions/release_runs.php was added!'),(87,'2014-03-26 11:14:59','Hash  for file ./app/controller/supervisor/deposit_manager_actions/change_card_number_in_runs.php was added!'),(88,'2014-03-26 11:14:59','Hash  for file ./app/controller/supervisor/deposit_manager_actions/change_card_number_in_rec.php was added!'),(89,'2014-03-26 11:15:00','Hash  for file ./app/controller/supervisor/deposit_manager_actions/join_recs.php was added!'),(90,'2014-03-26 11:15:00','Hash  for file ./app/controller/supervisor/signer_edit.php was added!'),(91,'2014-03-26 11:15:00','Hash  for file ./app/controller/select_scenario.php was added!'),(92,'2014-03-26 11:15:00','Hash  for file ./app/controller/echo_current_scenario.php was added!'),(93,'2014-03-26 11:15:00','Hash  for file ./app/controller/bootstrap.php was added!'),(94,'2014-03-26 11:15:01','Hash  for file ./app/controller/admin/user_edit.php was added!'),(95,'2014-03-26 11:15:01','Hash  for file ./app/controller/admin/backup.php was added!'),(96,'2014-03-26 11:15:01','Hash  for file ./app/controller/admin/denoms.php was added!'),(97,'2014-03-26 11:15:01','Hash  for file ./app/controller/admin/currency_add.php was added!'),(98,'2014-03-26 11:15:01','Hash  for file ./app/controller/admin/valuable_add.php was added!'),(99,'2014-03-26 11:15:01','Hash  for file ./app/controller/admin/user_add.php was added!'),(100,'2014-03-26 11:15:01','Hash  for file ./app/controller/admin/scens.php was added!'),(101,'2014-03-26 11:15:01','Hash  for file ./app/controller/admin/scen_add.php was added!'),(102,'2014-03-26 11:15:02','Hash  for file ./app/controller/admin/indexes.php was added!'),(103,'2014-03-26 11:15:02','Hash  for file ./app/controller/admin/sorter_index_edit.php was added!'),(104,'2014-03-26 11:15:02','Hash  for file ./app/controller/admin/scen_reports.php was added!'),(105,'2014-03-26 11:15:02','Hash  for file ./app/controller/admin/scen_edit.php was added!'),(106,'2014-03-26 11:15:02','Hash  for file ./app/controller/admin/sorter_edit.php was added!'),(107,'2014-03-26 11:15:02','Hash  for file ./app/controller/admin/system.php was added!'),(108,'2014-03-26 11:15:02','Hash  for file ./app/controller/admin/currency_edit.php was added!'),(109,'2014-03-26 11:15:03','Hash  for file ./app/controller/admin/valuable_edit.php was added!'),(110,'2014-03-26 11:15:03','Hash  for file ./app/controller/admin/sorter_type_add.php was added!'),(111,'2014-03-26 11:15:03','Hash  for file ./app/controller/admin/denom_edit.php was added!'),(112,'2014-03-26 11:15:03','Hash  for file ./app/controller/admin/grade_edit.php was added!'),(113,'2014-03-26 11:15:03','Hash  for file ./app/controller/admin/deposit_index_add.php was added!'),(114,'2014-03-26 11:15:03','Hash  for file ./app/controller/admin/profile.php was added!'),(115,'2014-03-26 11:15:04','Hash  for file ./app/controller/admin/index.php was added!'),(116,'2014-03-26 11:15:04','Hash  for file ./app/controller/admin/deposit_index_edit.php was added!'),(117,'2014-03-26 11:15:04','Hash  for file ./app/controller/admin/denom_add.php was added!'),(118,'2014-03-26 11:15:04','Hash  for file ./app/controller/admin/valuables.php was added!'),(119,'2014-03-26 11:15:05','Hash  for file ./app/controller/admin/sorter_index_add.php was added!'),(120,'2014-03-26 11:15:05','Hash  for file ./app/controller/admin/users.php was added!'),(121,'2014-03-26 11:15:05','Hash  for file ./app/controller/admin/sorter_add.php was added!'),(122,'2014-03-26 11:15:05','Hash  for file ./app/controller/admin/user_ip_edit.php was added!'),(123,'2014-03-26 11:15:05','Hash  for file ./app/controller/admin/valuable_type_edit.php was added!'),(124,'2014-03-26 11:15:05','Hash  for file ./app/controller/admin/client_edit.php was added!'),(125,'2014-03-26 11:15:05','Hash  for file ./app/controller/admin/scen_wizard.php was added!'),(126,'2014-03-26 11:15:05','Hash  for file ./app/controller/admin/valuable_type_add.php was added!'),(127,'2014-03-26 11:15:05','Hash  for file ./app/controller/admin/client_add.php was added!'),(128,'2014-03-26 11:15:06','Hash  for file ./app/controller/admin/customers.php was added!'),(129,'2014-03-26 11:15:06','Hash  for file ./app/controller/admin/restore_scripts.php was added!'),(130,'2014-03-26 11:15:06','Hash  for file ./app/controller/admin/grade_add.php was added!'),(131,'2014-03-26 11:15:06','Hash  for file ./app/controller/admin/user_ips.php was added!'),(132,'2014-03-26 11:15:06','Hash  for file ./app/controller/admin/change_password.php was added!'),(133,'2014-03-26 11:15:06','Hash  for file ./app/controller/admin/update.php was added!'),(134,'2014-03-26 11:15:06','Hash  for file ./app/controller/inspector/user_edit.php was added!'),(135,'2014-03-26 11:15:06','Hash  for file ./app/controller/inspector/user_add.php was added!'),(136,'2014-03-26 11:15:06','Hash  for file ./app/controller/inspector/profile.php was added!'),(137,'2014-03-26 11:15:07','Hash  for file ./app/controller/inspector/index.php was added!'),(138,'2014-03-26 11:15:07','Hash  for file ./app/controller/inspector/users.php was added!'),(139,'2014-03-26 11:15:07','Hash  for file ./app/controller/inspector/client_edit.php was added!'),(140,'2014-03-26 11:15:07','Hash  for file ./app/controller/inspector/restore_scripts.php was added!'),(141,'2014-03-26 11:15:07','Hash  for file ./app/controller/inspector/change_password.php was added!'),(142,'2014-03-26 11:15:07','Hash  for file ./app/controller/collector/simulator_collector.php was added!'),(143,'2014-03-26 11:15:07','Hash  for file ./app/controller/collector/cobra_collector.php was added!'),(144,'2014-03-26 11:15:07','Hash  for file ./app/controller/collector/collector.php was added!'),(145,'2014-03-26 11:15:08','Hash  for file ./app/controller/collector/glory_collector.php was added!'),(146,'2014-03-26 11:15:08','Hash  for file ./app/controller/collector/toshiba_collector.php was added!'),(147,'2014-03-26 11:15:08','Hash  for file ./app/controller/select_sorter_type.php was added!'),(148,'2014-03-26 11:15:08','Hash  for file ./app/controller/operator/recon_total_update.php was added!'),(149,'2014-03-26 11:15:08','Hash  for file ./app/controller/operator/act_by_recon.php was added!'),(150,'2014-03-26 11:15:08','Hash  for file ./app/controller/operator/profile.php was added!'),(151,'2014-03-26 11:15:08','Hash  for file ./app/controller/operator/reconciliation.php was added!'),(152,'2014-03-26 11:15:08','Hash  for file ./app/controller/operator/index.php was added!'),(153,'2014-03-26 11:15:09','Hash  for file ./app/controller/operator/recon_reconcile.php was added!'),(154,'2014-03-26 11:15:09','Hash  for file ./app/controller/operator/recon_discr_update.php was added!'),(155,'2014-03-26 11:15:09','Hash  for file ./app/controller/operator/recon_act_update.php was added!'),(156,'2014-03-26 11:15:09','Hash  for file ./app/controller/operator/recon_expected_update.php was added!'),(157,'2014-03-26 11:15:09','Hash  for file ./app/controller/operator/users.php was added!'),(158,'2014-03-26 11:15:09','Hash  for file ./app/controller/operator/recon_to_control.php was added!'),(159,'2014-03-26 11:15:09','Hash  for file ./app/controller/operator/recon_update.php was added!'),(160,'2014-03-26 11:15:09','Hash  for file ./app/controller/operator/restore_scripts.php was added!'),(161,'2014-03-26 11:15:10','Hash  for file ./app/controller/operator/recon_stat_update.php was added!'),(162,'2014-03-26 11:15:10','Hash  for file ./app/controller/operator/reconciliation_report.php was added!'),(163,'2014-03-26 11:15:10','Hash  for file ./app/controller/operator/reconciled.php was added!'),(164,'2014-03-26 11:15:10','Hash  for file ./app/controller/operator/change_password.php was added!'),(165,'2014-03-26 11:15:10','Hash  for file ./app/controller/operator/suspect_enter.php was added!'),(166,'2014-03-26 11:15:10','Hash  for file ./app/controller/set_default_scenario.php was added!'),(167,'2014-03-26 11:15:10','Hash  for file ./app/controller/developer/get_file.php was added!'),(168,'2014-03-26 11:15:10','Hash  for file ./app/controller/developer/get_app_archive.php was added!'),(169,'2014-03-26 11:15:11','Hash  for file ./app/controller/developer/edit_raw_table_add.php was added!'),(170,'2014-03-26 11:15:11','Hash  for file ./app/controller/developer/scenario_props_update.php was added!'),(171,'2014-03-26 11:15:11','Hash  for file ./app/controller/developer/edit_raw_table.php was added!'),(172,'2014-03-26 11:15:11','Hash  for file ./app/controller/developer/files.php was added!'),(173,'2014-03-26 11:15:11','Hash  for file ./app/controller/developer/scenario_options_update.php was added!'),(174,'2014-03-26 11:15:11','Hash  for file ./app/controller/developer/envelope.php was added!'),(175,'2014-03-26 11:15:11','Hash  for file ./app/controller/developer/upload_report.php was added!'),(176,'2014-03-26 11:15:11','Hash  for file ./app/controller/developer/scenario_config.php was added!'),(177,'2014-03-26 11:15:11','Hash  for file ./app/controller/developer/insert_data2.php was added!'),(178,'2014-03-26 11:15:12','Hash  for file ./app/controller/developer/insert_data3.php was added!'),(179,'2014-03-26 11:15:12','Hash  for file ./app/controller/developer/get_archive.php was added!'),(180,'2014-03-26 11:15:12','Hash  for file ./app/controller/developer/profile.php was added!'),(181,'2014-03-26 11:15:12','Hash  for file ./app/controller/developer/index.php was added!'),(182,'2014-03-26 11:15:12','Hash  for file ./app/controller/developer/category_import.php was added!'),(183,'2014-03-26 11:15:12','Hash  for file ./app/controller/developer/obfuscator.php was added!'),(184,'2014-03-26 11:15:13','Hash  for file ./app/controller/developer/language.php was added!'),(185,'2014-03-26 11:15:13','Hash  for file ./app/controller/developer/sql.php was added!'),(186,'2014-03-26 11:15:13','Hash  for file ./app/controller/developer/edit_table_add.php was added!'),(187,'2014-03-26 11:15:13','Hash  for file ./app/controller/developer/edit_table.php was added!'),(188,'2014-03-26 11:15:13','Hash  for file ./app/controller/developer/edit_raw_table_update.php was added!'),(189,'2014-03-26 11:15:13','Hash  for file ./app/controller/developer/refill_integrity.php was added!'),(190,'2014-03-26 11:15:13','Hash  for file ./app/controller/developer/insert_data1.php was added!'),(191,'2014-03-26 11:15:14','Hash  for file ./app/controller/developer/insert_data4.php was added!'),(192,'2014-03-26 11:15:14','Hash  for file ./app/controller/developer/jobfuscator.php was added!'),(193,'2014-03-26 11:15:14','Hash  for file ./app/controller/developer/edit_table_update.php was added!'),(194,'2014-03-26 11:15:14','Hash  for file ./app/controller/developer/set_unset_od.php was added!'),(195,'2014-03-26 11:15:14','Hash  for file ./app/controller/developer/restore.php was added!'),(196,'2014-03-26 11:15:14','Hash  for file ./app/controller/developer/simulator.php was added!'),(197,'2014-03-26 11:15:14','Hash  for file ./app/controller/developer/reset_db.php was added!'),(198,'2014-03-26 11:15:14','Hash  for file ./app/controller/developer/change_password.php was added!'),(199,'2014-03-26 11:15:14','Hash  for file ./app/controller/developer/update.php was added!'),(200,'2014-03-26 11:15:15','Hash  for file ./app/view/set_remove_wait.php was added!'),(201,'2014-03-26 11:15:15','Hash  for file ./app/view/html_header.php was added!'),(202,'2014-03-26 11:15:15','Hash  for file ./app/view/reload_after_1_min.php was added!'),(203,'2014-03-26 11:15:15','Hash  for file ./app/view/record/delete.php was added!'),(204,'2014-03-26 11:15:15','Hash  for file ./app/view/record/field_router.php was added!'),(205,'2014-03-26 11:15:15','Hash  for file ./app/view/record/readme.php was added!'),(206,'2014-03-26 11:15:16','Hash  for file ./app/view/record/required_field_message.php was added!'),(207,'2014-03-26 11:15:16','Hash  for file ./app/view/record/active_fields/select.php was added!'),(208,'2014-03-26 11:15:16','Hash  for file ./app/view/record/active_fields/checker.php was added!'),(209,'2014-03-26 11:15:16','Hash  for file ./app/view/record/active_fields/text.php was added!'),(210,'2014-03-26 11:15:16','Hash  for file ./app/view/record/field_router_readonly.php was added!'),(211,'2014-03-26 11:15:16','Hash  for file ./app/view/record/check_unique.php was added!'),(212,'2014-03-26 11:15:16','Hash  for file ./app/view/record/record_add.php was added!'),(213,'2014-03-26 11:15:16','Hash  for file ./app/view/record/clone.php was added!'),(214,'2014-03-26 11:15:17','Hash  for file ./app/view/record/start.php was added!'),(215,'2014-03-26 11:15:17','Hash  for file ./app/view/record/readonly_fields/select.php was added!'),(216,'2014-03-26 11:15:17','Hash  for file ./app/view/record/readonly_fields/readonly.php was added!'),(217,'2014-03-26 11:15:17','Hash  for file ./app/view/record/readonly_fields/checker.php was added!'),(218,'2014-03-26 11:15:17','Hash  for file ./app/view/record/readonly_fields/pointer.php was added!'),(219,'2014-03-26 11:15:17','Hash  for file ./app/view/record/readonly_fields/text.php was added!'),(220,'2014-03-26 11:15:17','Hash  for file ./app/view/record/readonly_fields/logical.php was added!'),(221,'2014-03-26 11:15:18','Hash  for file ./app/view/record/record_edit.php was added!'),(222,'2014-03-26 11:15:18','Hash  for file ./app/view/record/update.php was added!'),(223,'2014-03-26 11:15:18','Hash  for file ./app/view/draw_record_add.php was added!'),(224,'2014-03-26 11:15:18','Hash  for file ./app/view/reports/akt_0402198.php was added!'),(225,'2014-03-26 11:15:18','Hash  for file ./app/view/reports/confirm.php was added!'),(226,'2014-03-26 11:15:18','Hash  for file ./app/view/reports/printed_0402145.php was added!'),(227,'2014-03-26 11:15:18','Hash  for file ./app/view/reports/recresult_ext.php was added!'),(228,'2014-03-26 11:15:18','Hash  for file ./app/view/reports/printed_0402145_complex.php was added!'),(229,'2014-03-26 11:15:18','Hash  for file ./app/view/reports/rotated_page_css.php was added!'),(230,'2014-03-26 11:15:19','Hash  for file ./app/view/reports/akt_0402145.php was added!'),(231,'2014-03-26 11:15:19','Hash  for file ./app/view/reports/printed_0402013.php was added!'),(232,'2014-03-26 11:15:19','Hash  for file ./app/view/reports/c.php was added!'),(233,'2014-03-26 11:15:19','Hash  for file ./app/view/reports/customer_rollup_printed.php was added!'),(234,'2014-03-26 11:15:19','Hash  for file ./app/view/reports/general_apk_printed_old.php was added!'),(235,'2014-03-26 11:15:19','Hash  for file ./app/view/reports/recresult.php was added!'),(236,'2014-03-26 11:15:19','Hash  for file ./app/view/reports/general_apk_printed.php was added!'),(237,'2014-03-26 11:15:19','Hash  for file ./app/view/reports/printed_0402145_complex_fordeposit.php was added!'),(238,'2014-03-26 11:15:19','Hash  for file ./app/view/reports/general_rollup_printed.php was added!'),(239,'2014-03-26 11:15:20','Hash  for file ./app/view/reports/page_divider.php was added!'),(240,'2014-03-26 11:15:20','Hash  for file ./app/view/base_64_javascript.php was added!'),(241,'2014-03-26 11:15:20','Hash  for file ./app/view/page_header_with_logout.php was added!'),(242,'2014-03-26 11:15:20','Hash  for file ./app/view/get_to_string.php was added!'),(243,'2014-03-26 11:15:20','Hash  for file ./app/view/forms/act_by_reconciliation.php was added!'),(244,'2014-03-26 11:15:20','Hash  for file ./app/view/forms/finished_reconciliation.php was added!'),(245,'2014-03-26 11:15:20','Hash  for file ./app/view/forms/new_reconciliation.php was added!'),(246,'2014-03-26 11:15:20','Hash  for file ./app/view/forms/deferred_reconciliation.php was added!'),(247,'2014-03-26 11:15:20','Hash  for file ./app/view/forms/details_css.php was added!'),(248,'2014-03-26 11:15:21','Hash  for file ./app/view/forms/reconciliation_view.php was added!'),(249,'2014-03-26 11:15:21','Hash  for file ./app/view/danger_message.php was added!'),(250,'2014-03-26 11:15:21','Hash  for file ./app/view/bootstrap.php was added!'),(251,'2014-03-26 11:15:21','Hash  for file ./app/view/remove_special_symbols.php was added!'),(252,'2014-03-26 11:15:21','Hash  for file ./app/view/password_was_not_changed.php was added!'),(253,'2014-03-26 11:15:21','Hash  for file ./app/view/draw_select_table.php was added!'),(254,'2014-03-26 11:15:21','Hash  for file ./app/view/report_table_style.php was added!'),(255,'2014-03-26 11:15:21','Hash  for file ./app/view/set_rs_to_stat.php was added!'),(256,'2014-03-26 11:15:21','Hash  for file ./app/view/print_array_as_html_table.php was added!'),(257,'2014-03-26 11:15:22','Hash  for file ./app/view/draw_table.php was added!'),(258,'2014-03-26 11:15:22','Hash  for file ./app/view/error_message.php was added!'),(259,'2014-03-26 11:15:22','Hash  for file ./app/view/logout_link.php was added!'),(260,'2014-03-26 11:15:22','Hash  for file ./app/view/under_development.php was added!'),(261,'2014-03-26 11:15:22','Hash  for file ./app/view/htmlfix.php was added!'),(262,'2014-03-26 11:15:22','Hash  for file ./app/view/info_message.php was added!'),(263,'2014-03-26 11:15:22','Hash  for file ./app/view/reconciliation/against_value_new.php was added!'),(264,'2014-03-26 11:15:23','Hash  for file ./app/view/reconciliation/against_value.php was added!'),(265,'2014-03-26 11:15:23','Hash  for file ./app/view/reconciliation/messages/wrong_recon_grades.php was added!'),(266,'2014-03-26 11:15:23','Hash  for file ./app/view/reconciliation/messages/wrong_sorter_grades.php was added!'),(267,'2014-03-26 11:15:23','Hash  for file ./app/view/reconciliation/messages/non_single_denom.php was added!'),(268,'2014-03-26 11:15:23','Hash  for file ./app/view/reconciliation/against_amount.php was added!'),(269,'2014-03-26 11:15:23','Hash  for file ./app/view/reconciliation/keyboard_driver.php was added!'),(270,'2014-03-26 11:15:23','Hash  for file ./app/view/reconciliation/amount/recon_data_total.php was added!'),(271,'2014-03-26 11:15:23','Hash  for file ./app/view/reconciliation/amount/sorter_data_form.php was added!'),(272,'2014-03-26 11:15:24','Hash  for file ./app/view/reconciliation/amount/discrepancies.php was added!'),(273,'2014-03-26 11:15:24','Hash  for file ./app/view/reconciliation/amount/recon_data_input_form.php was added!'),(274,'2014-03-26 11:15:24','Hash  for file ./app/view/reconciliation/buttons.php was added!'),(275,'2014-03-26 11:15:24','Hash  for file ./app/view/reconciliation/value/recon_data_total.php was added!'),(276,'2014-03-26 11:15:24','Hash  for file ./app/view/reconciliation/value/sorter_data_form.php was added!'),(277,'2014-03-26 11:15:24','Hash  for file ./app/view/reconciliation/value/discrepancies.php was added!'),(278,'2014-03-26 11:15:24','Hash  for file ./app/view/reconciliation/value/recon_data_input_form.php was added!'),(279,'2014-03-26 11:15:24','Hash  for file ./app/view/reconciliation/value/result_and_estimated.php was added!'),(280,'2014-03-26 11:15:24','Hash  for file ./app/view/reconciliation/against_amount_new.php was added!'),(281,'2014-03-26 11:15:25','Hash  for file ./app/view/reconciliation/total.php was added!'),(282,'2014-03-26 11:15:25','Hash  for file ./app/view/reconciliation/suspect_enter.php was added!'),(283,'2014-03-26 11:15:25','Hash  for file ./app/view/success_message.php was added!'),(284,'2014-03-26 11:15:25','Hash  for file ./app/view/html_head_bootstrap.php was added!'),(285,'2014-03-26 11:15:25','Hash  for file ./app/view/select_language.php was added!'),(286,'2014-03-26 11:15:25','Hash  for file ./app/view/repost_post.php was added!'),(287,'2014-03-26 11:15:26','Hash  for file ./app/view/show_globals.php was added!'),(288,'2014-03-26 11:15:26','Hash  for file ./app/view/password_was_changed.php was added!'),(289,'2014-03-26 11:15:26','Hash  for file ./app/view/login.php was added!'),(290,'2014-03-26 11:15:26','Hash  for file ./app/view/draw_record_edit.php was added!'),(291,'2014-03-26 11:15:26','Hash  for file ./app/view/draw_editable_table.php was added!'),(292,'2014-03-26 11:15:27','Hash  for file ./app/view/update_record.php was added!'),(293,'2014-03-26 11:15:27','Hash  for file ./app/view/draw_simple_table.php was added!'),(294,'2014-03-26 11:15:27','Hash  for file ./app/view/html_head_for_report.php was added!'),(295,'2014-03-26 11:15:27','Hash  for file ./app/model/check_table_exist.php was added!'),(296,'2014-03-26 11:15:27','Hash  for file ./app/model/record/admin_currency_record.php was added!'),(297,'2014-03-26 11:15:27','Hash  for file ./app/model/record/admin_sorter_index_record.php was added!'),(298,'2014-03-26 11:15:27','Hash  for file ./app/model/record/admin_scenario_record.php was added!'),(299,'2014-03-26 11:15:27','Hash  for file ./app/model/record/supervisor_signer_record.php was added!'),(300,'2014-03-26 11:15:27','Hash  for file ./app/model/record/admin_deposit_index_record.php was added!'),(301,'2014-03-26 11:15:28','Hash  for file ./app/model/record/admin_grade_record.php was added!'),(302,'2014-03-26 11:15:28','Hash  for file ./app/model/record/admin_denom_record.php was added!'),(303,'2014-03-26 11:15:28','Hash  for file ./app/model/record/admin_valuable_record.php was added!'),(304,'2014-03-26 11:15:28','Hash  for file ./app/model/record/admin_sorter_type_record.php was added!'),(305,'2014-03-26 11:15:28','Hash  for file ./app/model/record/admin_sorter_record.php was added!'),(306,'2014-03-26 11:15:28','Hash  for file ./app/model/record/admin_system_globals_record.php was added!'),(307,'2014-03-26 11:15:28','Hash  for file ./app/model/record/admin_valuable_type_record.php was added!'),(308,'2014-03-26 11:15:29','Hash  for file ./app/model/lang/russian.php was added!'),(309,'2014-03-26 11:15:29','Hash  for file ./app/model/lang/english.php was added!'),(310,'2014-03-26 11:15:29','Hash  for file ./app/model/english_events.php was added!'),(311,'2014-03-26 11:15:29','Hash  for file ./app/model/directories.php was added!'),(312,'2014-03-26 11:15:29','Hash  for file ./app/model/nmr2str_by_currency.php was added!'),(313,'2014-03-26 11:15:29','Hash  for file ./app/model/int2str.php was added!'),(314,'2014-03-26 11:15:29','Hash  for file ./app/model/check_access_to_roles.php was added!'),(315,'2014-03-26 11:15:29','Hash  for file ./app/model/get_short_genetive_iof_by_user_id.php was added!'),(316,'2014-03-26 11:15:30','Hash  for file ./app/model/d.php was added!'),(317,'2014-03-26 11:15:30','Hash  for file ./app/model/remove_special_symbols.php was added!'),(318,'2014-03-26 11:15:30','Hash  for file ./app/model/dj.php was added!'),(319,'2014-03-26 11:15:30','Hash  for file ./app/model/db/fetch_row_from_sql.php was added!'),(320,'2014-03-26 11:15:30','Hash  for file ./app/model/db/draw_table_from_sql.php was added!'),(321,'2014-03-26 11:15:30','Hash  for file ./app/model/db/fetch_fields_info_from_sql.php was added!'),(322,'2014-03-26 11:15:30','Hash  for file ./app/model/db/fetch_assoc_row_from_sql.php was added!'),(323,'2014-03-26 11:15:31','Hash  for file ./app/model/db/get_array_from_sql.php was added!'),(324,'2014-03-26 11:15:31','Hash  for file ./app/model/db/count_rows_from_sql.php was added!'),(325,'2014-03-26 11:15:31','Hash  for file ./app/model/db/get_assoc_array_from_sql.php was added!'),(326,'2014-03-26 11:15:31','Hash  for file ./app/model/db/connection.php was added!'),(327,'2014-03-26 11:15:31','Hash  for file ./app/model/db/do_sql.php was added!'),(328,'2014-03-26 11:15:31','Hash  for file ./app/model/system_log.php was added!'),(329,'2014-03-26 11:15:31','Hash  for file ./app/model/report/get_report_signers.php was added!'),(330,'2014-03-26 11:15:31','Hash  for file ./app/model/report/get_value_from_report_saves.php was added!'),(331,'2014-03-26 11:15:31','Hash  for file ./app/model/report/add_xml_file_to_reportset.php was added!'),(332,'2014-03-26 11:15:32','Hash  for file ./app/model/table/deffered_reconciliations.php was added!'),(333,'2014-03-26 11:15:32','Hash  for file ./app/model/table/denoms.php was added!'),(334,'2014-03-26 11:15:32','Hash  for file ./app/model/table/grades.php was added!'),(335,'2014-03-26 11:15:32','Hash  for file ./app/model/table/sorter_types.php was added!'),(336,'2014-03-26 11:15:32','Hash  for file ./app/model/table/valuable_types.php was added!'),(337,'2014-03-26 11:15:32','Hash  for file ./app/model/table/sorter_accounting_data_by_card.php was added!'),(338,'2014-03-26 11:15:32','Hash  for file ./app/model/table/sorters.php was added!'),(339,'2014-03-26 11:15:33','Hash  for file ./app/model/table/users_admin.php was added!'),(340,'2014-03-26 11:15:33','Hash  for file ./app/model/table/new_valuables.php was added!'),(341,'2014-03-26 11:15:33','Hash  for file ./app/model/table/backups_for_restore.php was added!'),(342,'2014-03-26 11:15:33','Hash  for file ./app/model/table/valuables.php was added!'),(343,'2014-03-26 11:15:33','Hash  for file ./app/model/table/unreconciled_deposits_passive.php was added!'),(344,'2014-03-26 11:15:33','Hash  for file ./app/model/table/users.php was added!'),(345,'2014-03-26 11:15:33','Hash  for file ./app/model/table/backups.php was added!'),(346,'2014-03-26 11:15:33','Hash  for file ./app/model/table/for_check_reconciliations.php was added!'),(347,'2014-03-26 11:15:33','Hash  for file ./app/model/table/currencies.php was added!'),(348,'2014-03-26 11:15:34','Hash  for file ./app/model/table/unreconciled_deposits_by_separator_id.php was added!'),(349,'2014-03-26 11:15:34','Hash  for file ./app/model/table/unreconciled_deposits.php was added!'),(350,'2014-03-26 11:15:34','Hash  for file ./app/model/table/reports.php was added!'),(351,'2014-03-26 11:15:34','Hash  for file ./app/model/table/reconciled_deposits.php was added!'),(352,'2014-03-26 11:15:34','Hash  for file ./app/model/table/sorter_accounting_data_by_id.php was added!'),(353,'2014-03-26 11:15:34','Hash  for file ./app/model/table/deffered_reconciliations_selectable.php was added!'),(354,'2014-03-26 11:15:34','Hash  for file ./app/model/table/sorter_indexes.php was added!'),(355,'2014-03-26 11:15:34','Hash  for file ./app/model/table/users_inspector.php was added!'),(356,'2014-03-26 11:15:34','Hash  for file ./app/model/table/reconciled_deposits_by_user.php was added!'),(357,'2014-03-26 11:15:35','Hash  for file ./app/model/table/customers.php was added!'),(358,'2014-03-26 11:15:35','Hash  for file ./app/model/table/signers.php was added!'),(359,'2014-03-26 11:15:35','Hash  for file ./app/model/table/deposit_indexes.php was added!'),(360,'2014-03-26 11:15:35','Hash  for file ./app/model/table/deffered_reconciliations_by_user.php was added!'),(361,'2014-03-26 11:15:35','Hash  for file ./app/model/table/scenario_reports.php was added!'),(362,'2014-03-26 11:15:35','Hash  for file ./app/model/table/user_ips.php was added!'),(363,'2014-03-26 11:15:35','Hash  for file ./app/model/table/updates.php was added!'),(364,'2014-03-26 11:15:35','Hash  for file ./app/model/table/unreconciled_deposits_selectable.php was added!'),(365,'2014-03-26 11:15:35','Hash  for file ./app/model/table/new_category_names.php was added!'),(366,'2014-03-26 11:15:36','Hash  for file ./app/model/table/scenarios.php was added!'),(367,'2014-03-26 11:15:36','Hash  for file ./app/model/get_short_iof_by_user_id.php was added!'),(368,'2014-03-26 11:15:36','Hash  for file ./app/model/menu.php was added!'),(369,'2014-03-26 11:15:36','Hash  for file ./app/model/get_browser_version.php was added!'),(370,'2014-03-26 11:15:36','Hash  for file ./app/model/reconciliation/get_scenario_sorter_grades.php was added!'),(371,'2014-03-26 11:15:36','Hash  for file ./app/model/reconciliation/get_sorter_accounting_data_denoms_by_rec_id.php was added!'),(372,'2014-03-26 11:15:36','Hash  for file ./app/model/reconciliation/get_post_and_short_fio_by_user_id.php was added!'),(373,'2014-03-26 11:15:37','Hash  for file ./app/model/reconciliation/get_recon_accounting_data_grades.php was added!'),(374,'2014-03-26 11:15:37','Hash  for file ./app/model/reconciliation/get_sort_operators_by_rec_id.php was added!'),(375,'2014-03-26 11:15:37','Hash  for file ./app/model/reconciliation/get_sorter_accounting_data_currencies_by_rec_id.php was added!'),(376,'2014-03-26 11:15:37','Hash  for file ./app/model/reconciliation/get_total_by_rec_denom.php was added!'),(377,'2014-03-26 11:15:38','Hash  for file ./app/model/reconciliation/get_sorter_accounting_data_grades_by_cardnumber.php was added!'),(378,'2014-03-26 11:15:38','Hash  for file ./app/model/reconciliation/get_sorter_accounting_data_currencies.php was added!'),(379,'2014-03-26 11:15:38','Hash  for file ./app/model/reconciliation/get_recon_data_map_by_rec_id.php was added!'),(380,'2014-03-26 11:15:38','Hash  for file ./app/model/reconciliation/get_total_by_rec_denom_grade.php was added!'),(381,'2014-03-26 11:15:38','Hash  for file ./app/model/reconciliation/get_recon_denom_total_by_recon_id.php was added!'),(382,'2014-03-26 11:15:38','Hash  for file ./app/model/reconciliation/get_recon_acts_comments_by_id.php was added!'),(383,'2014-03-26 11:15:38','Hash  for file ./app/model/reconciliation/get_sorter_accounting_data_by_run_id.php was added!'),(384,'2014-03-26 11:15:39','Hash  for file ./app/model/reconciliation/recon_function_load.php was added!'),(385,'2014-03-26 11:15:39','Hash  for file ./app/model/reconciliation/get_indexes_by_rec_id.php was added!'),(386,'2014-03-26 11:15:39','Hash  for file ./app/model/reconciliation/get_sorter_accounting_data_denoms_by_rec_id_and_currency.php was added!'),(387,'2014-03-26 11:15:39','Hash  for file ./app/model/reconciliation/get_reconciliation_by_id.php was added!'),(388,'2014-03-26 11:15:39','Hash  for file ./app/model/reconciliation/get_reconciliation_by_sort_card_number.php was added!'),(389,'2014-03-26 11:15:39','Hash  for file ./app/model/reconciliation/rebind_deposits_to_recon.php was added!'),(390,'2014-03-26 11:15:39','Hash  for file ./app/model/reconciliation/get_reconciled_deposit_by_rec_id.php was added!'),(391,'2014-03-26 11:15:39','Hash  for file ./app/model/reconciliation/get_sorter_currency_by_rec_id.php was added!'),(392,'2014-03-26 11:15:39','Hash  for file ./app/model/reconciliation/get_all_grade_ids_by_scenario_id.php was added!'),(393,'2014-03-26 11:15:40','Hash  for file ./app/model/reconciliation/get_client_name_and_code_by_id.php was added!'),(394,'2014-03-26 11:15:40','Hash  for file ./app/model/reconciliation/get_scenario_currency.php was added!'),(395,'2014-03-26 11:15:40','Hash  for file ./app/model/reconciliation/get_reconciled_deposit_by_sort_card_number.php was added!'),(396,'2014-03-26 11:15:40','Hash  for file ./app/model/reconciliation/get_scenario_by_id.php was added!'),(397,'2014-03-26 11:15:40','Hash  for file ./app/model/reconciliation/get_scenario_recon_grades.php was added!'),(398,'2014-03-26 11:15:40','Hash  for file ./app/model/reconciliation/get_depositruns_by_rec_id.php was added!'),(399,'2014-03-26 11:15:40','Hash  for file ./app/model/reconciliation/get_scenario_denoms_by_id.php was added!'),(400,'2014-03-26 11:15:40','Hash  for file ./app/model/reconciliation/get_recon_details_by_id.php was added!'),(401,'2014-03-26 11:15:41','Hash  for file ./app/model/reconciliation/get_machines_by_rec_id.php was added!'),(402,'2014-03-26 11:15:41','Hash  for file ./app/model/reconciliation/get_short_fio_by_user_id.php was added!'),(403,'2014-03-26 11:15:41','Hash  for file ./app/model/reconciliation/get_recon_accounting_data_by_rec_id.php was added!'),(404,'2014-03-26 11:15:41','Hash  for file ./app/model/reconciliation/get_sorter_start_and_stop_time_by_rec_id.php was added!'),(405,'2014-03-26 11:15:41','Hash  for file ./app/model/reconciliation/get_sorter_accounting_data_by_rec_id.php was added!'),(406,'2014-03-26 11:15:41','Hash  for file ./app/model/reconciliation/create_new_recon_value.php was added!'),(407,'2014-03-26 11:15:41','Hash  for file ./app/model/reconciliation/get_expected_by_denom_and_rec_id.php was added!'),(408,'2014-03-26 11:15:41','Hash  for file ./app/model/reconciliation/get_denoms_by_currency.php was added!'),(409,'2014-03-26 11:15:42','Hash  for file ./app/model/reconciliation/get_scenario_denoms_by_id_and_currency.php was added!'),(410,'2014-03-26 11:15:42','Hash  for file ./app/model/reconciliation/get_recon_data_map_by_cardnumber.php was added!'),(411,'2014-03-26 11:15:42','Hash  for file ./app/model/reconciliation/get_all_grades_by_scenario_id.php was added!'),(412,'2014-03-26 11:15:42','Hash  for file ./app/model/reconciliation/create_new_recon.php was added!'),(413,'2014-03-26 11:15:42','Hash  for file ./app/model/is_mobile.php was added!'),(414,'2014-03-26 11:15:42','Hash  for file ./app/model/auth/get_password_expired_date.php was added!'),(415,'2014-03-26 11:15:42','Hash  for file ./app/model/auth/check_auth.php was added!'),(416,'2014-03-26 11:15:42','Hash  for file ./app/model/auth/get_user_config.php was added!'),(417,'2014-03-26 11:15:42','Hash  for file ./app/model/auth/users.php was added!'),(418,'2014-03-26 11:15:43','Hash  for file ./app/model/auth/less_then_three_days.php was added!'),(419,'2014-03-26 11:15:43','Hash  for file ./app/model/auth/set_log_attempts.php was added!'),(420,'2014-03-26 11:15:43','Hash  for file ./app/model/auth/block_user_id.php was added!'),(421,'2014-03-26 11:15:43','Hash  for file ./app/model/error_files.php was added!'),(422,'2014-03-26 11:15:43','Hash  for file ./test.php was added!'),(423,'2014-03-26 11:15:43','Hash  for file ./service/backup.php was added!'),(424,'2014-03-26 11:15:43','Hash  for file ./service/module/collect_from_cobra.php was added!'),(425,'2014-03-26 11:15:44','Hash  for file ./service/module/make_files.php was added!'),(426,'2014-03-26 11:15:44','Hash  for file ./service/module/tables_purge.php was added!'),(427,'2014-03-26 11:15:44','Hash  for file ./service/collector.php was added!'),(428,'2014-03-26 11:15:44','Hash  for file ./service/restore.php was added!'),(429,'2014-03-26 11:15:44','Hash  for file ./index.php was added!'),(430,'2014-03-26 11:15:44','Hash  for file ./test_2.php was added!'),(431,'2014-03-26 11:15:44','Hash  for file ./Bootstrap_files/bootstrap-tooltip.js was added!'),(432,'2014-03-26 11:15:44','Hash  for file ./Bootstrap_files/bootstrap-transition.js was added!'),(433,'2014-03-26 11:15:45','Hash  for file ./Bootstrap_files/bootstrap-scrollspy.js was added!'),(434,'2014-03-26 11:15:45','Hash  for file ./Bootstrap_files/bootstrap-collapse.js was added!'),(435,'2014-03-26 11:15:45','Hash  for file ./Bootstrap_files/bootstrap-popover.js was added!'),(436,'2014-03-26 11:15:45','Hash  for file ./Bootstrap_files/bootstrap-typeahead.js was added!'),(437,'2014-03-26 11:15:45','Hash  for file ./Bootstrap_files/bootstrap-alert.js was added!'),(438,'2014-03-26 11:15:45','Hash  for file ./Bootstrap_files/bootstrap-modal.js was added!'),(439,'2014-03-26 11:15:45','Hash  for file ./Bootstrap_files/bootstrap-tab.js was added!'),(440,'2014-03-26 11:15:45','Hash  for file ./Bootstrap_files/bootstrap-dropdown.js was added!'),(441,'2014-03-26 11:15:46','Hash  for file ./Bootstrap_files/bootstrap-button.js was added!'),(442,'2014-03-26 11:15:46','Hash  for file ./Bootstrap_files/bootstrap-carousel.js was added!'),(443,'2014-03-26 11:15:46','Hash  for file ./bootstrap/js/bootstrap.min.js was added!'),(444,'2014-03-26 11:15:46','Hash  for file ./bootstrap/js/bootstrap.js was added!'),(445,'2014-03-26 11:15:46','Hash  for file ./bootstrap/js/bootstrap-datepicker.ru.js was added!'),(446,'2014-03-26 11:15:46','Hash  for file ./bootstrap/js/bootstrap-datepicker.js was added!'),(447,'2014-03-26 11:15:46','Hash  for file ./js/jquery-2.0.2.min.js was added!'),(448,'2014-03-26 11:15:46','Hash  for file ./js/jquery-1.10.1.min.js was added!'),(449,'2014-03-26 11:15:47','Hash  for file ./js/base64_encode.js was added!'),(450,'2014-03-26 11:15:47','Hash  for file ./js/md5.js was added!'),(451,'2014-03-26 11:15:47','Hash  for file ./js/base64_decode.js was added!'),(452,'2014-03-26 11:15:47','Hash  for file ./js/translit.js was added!'),(453,'2014-03-26 11:15:48','Application integrity was restored by developer from IP: 127.0.0.1'),(454,'2014-03-26 11:16:56','User logout Разработчик Р.Р. IP: 127.0.0.1'),(455,'2014-03-26 11:17:37','Unsuccessful login attempt. Wrong login or password sveta IP: 127.0.0.1'),(456,'2014-03-26 11:17:37','Updated file ./app/controller/developer/index.php was found!'),(457,'2014-03-26 11:17:38','Application files corruption was detected!'),(458,'2014-03-26 11:17:44','User logon Черенкова С.Н. IP: 127.0.0.1'),(459,'2014-03-26 11:17:55','User logout Черенкова С.Н. IP: 127.0.0.1'),(460,'2014-03-26 11:17:56','Updated file ./app/controller/developer/index.php was found!'),(461,'2014-03-26 11:17:56','Application files corruption was detected!'),(462,'2014-03-26 11:17:59','Updated file ./app/controller/developer/index.php was found!'),(463,'2014-03-26 11:17:59','Application files corruption was detected!'),(464,'2014-03-26 11:18:05','User logon Разработчик Р.Р. IP: 127.0.0.1'),(465,'2014-03-26 11:18:07','Hash  for file ./app/controller/developer/index.php was updated.'),(466,'2014-03-26 11:18:08','Application integrity was restored by developer from IP: 127.0.0.1'),(467,'2014-03-26 11:18:19','User logout Разработчик Р.Р. IP: 127.0.0.1'),(468,'2014-03-26 11:18:26','User logon Клименюк А.Ю. IP: 127.0.0.1'),(469,'2014-03-26 11:18:38','User logon Разработчик Р.Р. IP: 127.0.0.1'),(470,'2014-03-26 11:32:18','User login: sveta name: Черенкова Светлана  Николаевна post: старший кассир was editet by: andrew IP: 127.0.0.1'),(471,'2014-03-26 11:33:08','User login: sveta name: Черенкова Светлана  Николаевна post: старший кассир was editet by: andrew IP: 127.0.0.1'),(472,'2014-03-26 11:33:11','User login: sveta name: Черенкова Светлана  Николаевна post: старший кассир was editet by: andrew IP: 127.0.0.1'),(473,'2014-03-26 11:33:13','User login: sveta name: Черенкова Светлана  Николаевна post: старший кассир was editet by: andrew IP: 127.0.0.1'),(474,'2014-03-26 11:46:45','A user was created login: 322223 user: \"Иванов\" \"Иван\"  \"Иванович\" post: \"Иванова\" by: andrew IP: 127.0.0.1'),(475,'2014-03-26 11:53:23','User logout Клименюк А.Ю. IP: 127.0.0.1'),(476,'2014-03-26 11:53:25','Updated file ./app/controller/admin/user_edit.php was found!'),(477,'2014-03-26 11:53:25','Updated file ./app/controller/admin/user_add.php was found!'),(478,'2014-03-26 11:53:26','Updated file ./app/model/lang/russian.php was found!'),(479,'2014-03-26 11:53:26','Updated file ./app/model/lang/english.php was found!'),(480,'2014-03-26 11:53:26','Application files corruption was detected!'),(481,'2014-03-26 11:53:36','User logon Клименюк А.Ю. IP: 127.0.0.1'),(482,'2014-03-26 11:53:43','Hash  for file ./app/controller/admin/user_edit.php was updated.'),(483,'2014-03-26 11:53:43','Hash  for file ./app/controller/admin/user_add.php was updated.'),(484,'2014-03-26 11:53:44','Hash  for file ./app/model/lang/russian.php was updated.'),(485,'2014-03-26 11:53:44','Hash  for file ./app/model/lang/english.php was updated.'),(486,'2014-03-26 11:53:45','Application integrity was restored by developer from IP: 127.0.0.1'),(487,'2014-03-26 11:53:51','User logout Клименюк А.Ю. IP: 127.0.0.1'),(488,'2014-03-26 11:54:06','User logon Клименюк А.Ю. IP: 127.0.0.1'),(489,'2014-03-26 11:54:24','IP-address % for user: ivivanivanov was added to allowed list  by: andrew IP: 127.0.0.1'),(490,'2014-03-26 11:54:36','User login: ivivanivanov name: Иванов Иван  Иванович post: дворник was editet by: andrew IP: 127.0.0.1'),(491,'2014-03-26 11:54:42','User logout Клименюк А.Ю. IP: 127.0.0.1'),(492,'2014-03-26 11:54:49','User logon Бабаев А.А. IP: 127.0.0.1'),(493,'2014-03-26 11:58:32','User logout Бабаев А.А. IP: 127.0.0.1'),(494,'2014-03-26 11:58:33','Updated file ./app/controller/inspector/user_edit.php was found!'),(495,'2014-03-26 11:58:33','Application files corruption was detected!'),(496,'2014-03-26 11:58:41','Hash  for file ./app/controller/inspector/user_edit.php was updated.'),(497,'2014-03-26 11:58:42','Application integrity was restored by developer from IP: 127.0.0.1'),(498,'2014-03-26 11:58:50','User logon Клименюк А.Ю. IP: 127.0.0.1'),(499,'2014-03-26 11:59:09','User login: ivivanivanov name: Иванов Иван  Иванович post: дворник was editet by: andrew IP: 127.0.0.1'),(500,'2014-03-26 11:59:12','User logout Клименюк А.Ю. IP: 127.0.0.1'),(501,'2014-03-26 11:59:18','Unsuccessful login attempt. Wrong login or password alex IP: 127.0.0.1'),(502,'2014-03-26 11:59:22','User logon Бабаев А.А. IP: 127.0.0.1'),(503,'2014-03-26 11:59:36','ivivanivanov User was unblocked by / on : alex / IP: 127.0.0.1'),(504,'2014-03-26 12:00:52','ivivanivanov User was blocked by / on : alex / IP: 127.0.0.1'),(505,'2014-03-26 12:00:53','ivivanivanov User was unblocked by / on : alex / IP: 127.0.0.1'),(506,'2014-03-26 12:01:05','ivivanivanov User was blocked by / on : alex / IP: 127.0.0.1'),(507,'2014-03-26 12:01:06','ivivanivanov User was unblocked by / on : alex / IP: 127.0.0.1'),(508,'2014-03-26 12:01:14','User logout Бабаев А.А. IP: 127.0.0.1'),(509,'2014-03-26 12:01:15','Updated file ./app/controller/inspector/user_edit.php was found!'),(510,'2014-03-26 12:01:15','Application files corruption was detected!'),(511,'2014-03-26 12:05:43','User logon Бабаев А.А. IP: 127.0.0.1'),(512,'2014-03-26 12:05:52','Hash  for file ./app/controller/inspector/user_edit.php was updated.'),(513,'2014-03-26 12:05:53','Application integrity was restored by developer from IP: 127.0.0.1'),(514,'2014-03-26 12:05:57','User logout Бабаев А.А. IP: 127.0.0.1'),(515,'2014-03-26 12:06:04','User logon Бабаев А.А. IP: 127.0.0.1'),(516,'2014-03-26 12:09:33','User logout Бабаев А.А. IP: 127.0.0.1'),(517,'2014-03-26 12:09:33','Updated file ./app/controller/inspector/user_add.php was found!'),(518,'2014-03-26 12:09:34','Application files corruption was detected!'),(519,'2014-03-26 12:11:38','User logon Разработчик Р.Р. IP: 127.0.0.1'),(520,'2014-03-26 12:11:42','Hash  for file ./app/controller/inspector/user_add.php was updated.'),(521,'2014-03-26 12:11:43','Application integrity was restored by developer from IP: 127.0.0.1'),(522,'2014-03-26 12:25:59','User logon Разработчик Р.Р. IP: 127.0.0.1'),(523,'2014-03-26 12:27:00','Application integrity was restored by developer from IP: 127.0.0.1'),(524,'2014-03-26 12:28:13','User logout Разработчик Р.Р. IP: 127.0.0.1'),(525,'2014-03-26 12:28:20','User logon Клименюк А.Ю. IP: 127.0.0.1'),(526,'2014-03-26 12:28:46','User logout Клименюк А.Ю. IP: 127.0.0.1'),(527,'2014-03-26 12:28:51','User logon Александров Е.В. IP: 127.0.0.1'),(528,'2014-03-26 12:32:02','User logout Александров Е.В. IP: 127.0.0.1'),(529,'2014-03-26 12:32:07','User logon Разработчик Р.Р. IP: 127.0.0.1'),(530,'2014-03-26 12:38:59','User logout Разработчик Р.Р. IP: 127.0.0.1'),(531,'2014-03-26 12:39:06','User logon Клименюк А.Ю. IP: 127.0.0.1');
/*!40000 ALTER TABLE `SystemLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UpdateHistory`
--

DROP TABLE IF EXISTS `UpdateHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UpdateHistory` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UpdateDateTime` datetime NOT NULL,
  `UpdateFile` varchar(256) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UpdateHistory`
--

LOCK TABLES `UpdateHistory` WRITE;
/*!40000 ALTER TABLE `UpdateHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `UpdateHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserConfiguration`
--

DROP TABLE IF EXISTS `UserConfiguration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserConfiguration` (
  `UserId` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserFamilyName` varchar(24) NOT NULL,
  `UserFirstName` varchar(24) NOT NULL,
  `UserPatronymic` varchar(24) DEFAULT NULL,
  `UserPost` varchar(80) NOT NULL,
  `UserRoleId` bigint(20) NOT NULL,
  `UserCreateDate` datetime NOT NULL,
  `UserLogin` varchar(16) NOT NULL,
  `UserPassword` varchar(32) NOT NULL,
  `UserSalt` varchar(32) NOT NULL,
  `LoggingAttemptsLimit` int(11) NOT NULL DEFAULT '5',
  `BadLogAttempts` int(11) NOT NULL DEFAULT '0',
  `UserIsBlocked` tinyint(4) NOT NULL DEFAULT '0',
  `UserLogicallyDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `ChangePassword` tinyint(4) NOT NULL DEFAULT '1',
  `LastChangePasswordDate` datetime NOT NULL,
  `ValidDays` int(11) NOT NULL DEFAULT '180',
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CashRoomId` bigint(20) NOT NULL DEFAULT '0',
  `InterfaceLanguage` varchar(45) NOT NULL DEFAULT 'English',
  `Phone` varchar(45) DEFAULT NULL,
  `OldUserFamilyName` varchar(45) DEFAULT NULL,
  `OldUserFirstName` varchar(45) DEFAULT NULL,
  `OldUserPatronymic` varchar(45) DEFAULT NULL,
  `OldUserPost` varchar(80) DEFAULT NULL,
  `OldPhone` varchar(45) DEFAULT NULL,
  `Blind` tinyint(4) NOT NULL DEFAULT '0',
  `CurrentScenario` bigint(20) DEFAULT NULL,
  `GenetiveName` varchar(24) DEFAULT NULL,
  `OldGenetiveName` varchar(24) DEFAULT NULL,
  `InstrName` varchar(24) DEFAULT NULL,
  `OldInstrName` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`UserId`),
  KEY `UserRoleId_RoleId_idx` (`UserRoleId`),
  KEY `UserConfiguration_CreatedBy_UserId_idx` (`CreatedBy`),
  KEY `UserConfiguration_CashRoomId_CashRooms_idx` (`CashRoomId`),
  KEY `UserConfiguration_CurrentScenario_Scenarios_idx` (`CurrentScenario`),
  CONSTRAINT `UserRoleId_RoleId` FOREIGN KEY (`UserRoleId`) REFERENCES `Roles` (`RoleId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserConfiguration_CreatedBy_UserId` FOREIGN KEY (`CreatedBy`) REFERENCES `UserConfiguration` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserConfiguration_CashRoomId_CashRooms` FOREIGN KEY (`CashRoomId`) REFERENCES `CashRooms` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `UserConfiguration_CurrentScenario_Scenarios` FOREIGN KEY (`CurrentScenario`) REFERENCES `Scenario` (`ScenarioId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserConfiguration`
--

LOCK TABLES `UserConfiguration` WRITE;
/*!40000 ALTER TABLE `UserConfiguration` DISABLE KEYS */;
INSERT INTO `UserConfiguration` VALUES (1,'Гвоздев','Дмитрий','Сергеевич','администратор системы',1,'2013-01-01 00:00:00','dmitry','202cb962ac59075b964b07152d234b70','iuy',5,0,0,0,0,'2014-03-01 13:00:00',180,NULL,0,'Russian',NULL,'Гвоздев','Дмитрий','Сергеевич','администратор системы',NULL,0,NULL,'Гвоздева','Гвоздева','Гвоздевым','Гвоздевым'),(2,'Клименюк','Андрей','Юрьевич','администратор системы',1,'2013-01-01 00:00:00','andrew','202cb962ac59075b964b07152d234b70','iuy',5,0,0,0,0,'2014-03-01 13:00:00',180,NULL,0,'English',NULL,'Клименюк','Андрей','Юрьевич','администратор системы',NULL,0,NULL,'Клименюка','Клименюка','Клименюком','Клименюком'),(3,'Александров','Егор','Викторович','контролёр',2,'2013-01-01 00:00:00','egor','202cb962ac59075b964b07152d234b70','iuy',5,0,0,0,0,'2014-03-01 13:00:00',180,NULL,1,'English','+79213123133','Александров','Егор','Викторович','контролёр','+79213123133',0,1,'Александрова','Александрова','Александровым','Александровым'),(4,'Черенкова','Светлана','Николаевна','старший кассир',3,'2013-01-01 00:00:00','sveta','202cb962ac59075b964b07152d234b70','iuy',5,0,1,0,0,'2014-03-01 13:00:00',180,NULL,1,'Russian','+79144882061','Черенкова','Светлана','Николаевна','старший кассир','+79144882061',0,1,'Черенковой-1','Черенковой','Черенковой -2','Черенковой'),(5,'Андрианова','Юлия','Вячеславовна','кассир',3,'2013-01-01 00:00:00','julia','202cb962ac59075b964b07152d234b70','iuy',5,0,0,0,0,'2014-03-01 13:00:00',180,NULL,1,'Russian','+79032370995','Андрианова','Юлия','Вячеславовна','кассир','+79032370995',0,1,'Андриановой','Андриановой','Андриановой','Андриановой'),(6,'Бабаев','Александр','Александрович','администратор по безопасности',4,'2013-01-01 00:00:00','alex','202cb962ac59075b964b07152d234b70','iuy',5,0,0,0,0,'2014-03-01 13:00:00',180,NULL,0,'Russian',NULL,'Бабаев','Александр','Александрович','администратор по безопасности',NULL,0,NULL,'Бабаева','Бабаева','Бабаевым','Бабаевым'),(7,'Разработчик','Р','Р','разработчик',5,'2013-03-01 00:00:00','developer','202cb962ac59075b964b07152d234b70','iuy',10,0,0,0,0,'2014-01-01 13:00:00',900,NULL,0,'English',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL),(8,'Никифорова','Ирина','Геннадьевна','контролёр',2,'2013-01-01 00:00:00','ira','202cb962ac59075b964b07152d234b70','iuy',5,0,0,0,0,'2014-01-01 13:00:00',180,NULL,1,'Russian','+380679488367','Никифорова','Ирина','Геннадьевна','контролёр','+380679488367',0,1,'Никифоровой','Никифоровой','Никифоровой','Никифоровой'),(9,'Иванов','Иван','Иванович','дворник',3,'2014-03-26 13:46:45','ivivanivanov','71e63ef5b7249cfc60852f0e0f5bf4c8','depricated',5,0,0,0,1,'2014-03-26 14:01:07',180,2,0,'English','322223','Иванов','Иван','Иванович','дворник','322223',0,0,'Иванова -2','Иванова -2','Ивановым --4','Ивановым --4');
/*!40000 ALTER TABLE `UserConfiguration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserHashHistory`
--

DROP TABLE IF EXISTS `UserHashHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserHashHistory` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `OldHash` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `UserHashHistory_UserId_UserConfiguration_idx` (`UserId`),
  CONSTRAINT `UserHashHistory_UserId_UserConfiguration` FOREIGN KEY (`UserId`) REFERENCES `UserConfiguration` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserHashHistory`
--

LOCK TABLES `UserHashHistory` WRITE;
/*!40000 ALTER TABLE `UserHashHistory` DISABLE KEYS */;
INSERT INTO `UserHashHistory` VALUES (1,1,'202cb962ac59075b964b07152d234b70'),(2,2,'202cb962ac59075b964b07152d234b70'),(3,3,'202cb962ac59075b964b07152d234b70'),(4,4,'202cb962ac59075b964b07152d234b70'),(5,5,'202cb962ac59075b964b07152d234b70'),(6,6,'202cb962ac59075b964b07152d234b70'),(7,7,'202cb962ac59075b964b07152d234b70'),(8,8,'202cb962ac59075b964b07152d234b70');
/*!40000 ALTER TABLE `UserHashHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UsersIP`
--

DROP TABLE IF EXISTS `UsersIP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UsersIP` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `IP` varchar(16) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `UsersIP_UserId_UserConfiguration_idx` (`UserId`),
  CONSTRAINT `UsersIP_UserId_UserConfiguration` FOREIGN KEY (`UserId`) REFERENCES `UserConfiguration` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UsersIP`
--

LOCK TABLES `UsersIP` WRITE;
/*!40000 ALTER TABLE `UsersIP` DISABLE KEYS */;
INSERT INTO `UsersIP` VALUES (1,1,'%'),(2,2,'%'),(3,3,'%'),(4,4,'%'),(5,5,'%'),(6,6,'%'),(7,7,'%'),(8,8,'%'),(9,0,'%'),(10,9,'%');
/*!40000 ALTER TABLE `UsersIP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ValuableTypes`
--

DROP TABLE IF EXISTS `ValuableTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ValuableTypes` (
  `ValuableTypeId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ValuableTypeName` varchar(18) NOT NULL,
  `ValuableTypeLabel` varchar(24) NOT NULL,
  `SerialNumberIsUsed` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ValuableTypeId`),
  UNIQUE KEY `ValuableTypeName_UNIQUE` (`ValuableTypeName`),
  UNIQUE KEY `ValuableTypeLabel_UNIQUE` (`ValuableTypeLabel`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ValuableTypes`
--

LOCK TABLES `ValuableTypes` WRITE;
/*!40000 ALTER TABLE `ValuableTypes` DISABLE KEYS */;
INSERT INTO `ValuableTypes` VALUES (1,'coins','монеты',0),(2,'banknotes','банкноты',1);
/*!40000 ALTER TABLE `ValuableTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Valuables`
--

DROP TABLE IF EXISTS `Valuables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Valuables` (
  `ValuableId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(50) NOT NULL,
  `SorterTypeId` bigint(20) NOT NULL,
  `DenomId` bigint(20) NOT NULL,
  `ValuableTypeId` bigint(20) NOT NULL,
  PRIMARY KEY (`ValuableId`),
  UNIQUE KEY `valuable_name_unique` (`CategoryName`,`SorterTypeId`),
  KEY `Valuables_DenomId_Denoms_idx` (`DenomId`),
  KEY `Valuables_SorterType_Machines_idx` (`SorterTypeId`),
  KEY `Valuables_ValuableTypeId_ValuableTypes_idx` (`ValuableTypeId`),
  CONSTRAINT `Valuables_DenomId_Denoms` FOREIGN KEY (`DenomId`) REFERENCES `Denoms` (`DenomId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Valuables_SorterType_Machines` FOREIGN KEY (`SorterTypeId`) REFERENCES `SorterTypes` (`SorterTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Valuables_ValuableTypeId_ValuableTypes` FOREIGN KEY (`ValuableTypeId`) REFERENCES `ValuableTypes` (`ValuableTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Valuables`
--

LOCK TABLES `Valuables` WRITE;
/*!40000 ALTER TABLE `Valuables` DISABLE KEYS */;
INSERT INTO `Valuables` VALUES (1,'10 Roubles (M97) FIT',2,8,2),(2,'10 Roubles (M04) FIT Cfolds',2,8,2),(3,'10 Roubles (M04) FIT',2,8,2),(4,'10 Roubles (M97) Shredded',2,8,2),(5,'10 Roubles (M97) FIT Cfolds',2,8,2),(6,'10 Roubles (M97) UNFIT MD',2,8,2),(7,'10 Roubles (M97) UNFIT',2,8,2),(8,'10 Roubles (M04) UNFIT MD',2,8,2),(9,'10 Roubles (M04) UNFIT',2,8,2),(10,'10 Roubles (M04) Shredded',2,8,2),(11,'50 Roubles (M97) FIT Cfolds',2,9,2),(12,'50 Roubles (M97) FIT',2,9,2),(13,'50 Roubles (M04) FIT Cfolds',2,9,2),(14,'50 Roubles (M04) FIT',2,9,2),(15,'50 Roubles (M97) Shredded',2,9,2),(16,'50 Roubles (M97) UNFIT MD',2,9,2),(17,'50 Roubles (M97) UNFIT',2,9,2),(18,'50 Roubles (M04) UNFIT MD',2,9,2),(19,'50 Roubles (M04) UNFIT',2,9,2),(20,'50 Roubles (M04) Shredded',2,9,2),(21,'100 Roubles (M97) FIT Cfolds',2,10,2),(22,'100 Roubles (M97) FIT',2,10,2),(23,'100 Roubles (M04) FIT Cfolds',2,10,2),(24,'100 Roubles (M04) FIT',2,10,2),(25,'100 Roubles (M97) Shredded',2,10,2),(26,'100 Roubles (M97) UNFIT MD',2,10,2),(27,'100 Roubles (M97) UNFIT',2,10,2),(28,'100 Roubles (M04) UNFIT MD',2,10,2),(29,'100 Roubles (M04) UNFIT',2,10,2),(30,'100 Roubles (M04) Shredded',2,10,2),(31,'500 Roubles (M97) FIT Cfolds',2,11,2),(32,'500 Roubles (M97) FIT',2,11,2),(33,'500 Roubles (M04) FIT Cfolds',2,11,2),(34,'500 Roubles (M04) FIT',2,11,2),(35,'500 Roubles (10) FIT Cfolds',2,11,2),(36,'500 Roubles (10) Fit',2,11,2),(37,'500 Roubles (M97) Shredded',2,11,2),(38,'500 Roubles (M10) Shredded',2,11,2),(39,'500 Roubles (M97) UNFIT MD',2,11,2),(40,'500 Roubles (M97) UNFIT',2,11,2),(41,'500 Roubles (M04) UNFIT MD',2,11,2),(42,'500 Roubles (M04) UNFIT',2,11,2),(43,'500 Roubles (10) Unfit MD',2,11,2),(44,'500 Roubles (10) Unfit',2,11,2),(45,'500 Roubles (M04) Shredded',2,11,2),(46,'1000 Roubles (M97) FIT Cfolds',2,12,2),(47,'1000 Roubles (M97) FIT',2,12,2),(48,'1000 Roubles (M04) FIT Cfolds',2,12,2),(49,'1000 Roubles (M04) FIT',2,12,2),(50,'1000 Roubles (M10) FIT Cfolds',2,12,2),(51,'1000 Roubles (M10) FIT',2,12,2),(52,'1000 Roubles (M04) Shredded',2,12,2),(53,'1000 Roubles (M10) Shredded',2,12,2),(54,'1000 Roubles (M97) UNFIT MD',2,12,2),(55,'1000 Roubles (M97) UNFIT',2,12,2),(56,'1000 Roubles (M04) UNFIT MD',2,12,2),(57,'1000 Roubles (M04) UNFIT',2,12,2),(58,'1000 Roubles (M10) UNFIT MD',2,12,2),(59,'1000 Roubles (M10) UNFIT',2,12,2),(60,'1000 Roubles (M97) Shredded',2,12,2),(61,'5000 Roubles (10) FIT Cfolds',2,13,2),(62,'5000 Roubles (10) FIT',2,13,2),(63,'5000 Roubles (M04) Shredded',2,13,2),(64,'5000 Roubles (M10) Shredded',2,13,2),(65,'5000 Roubles (M04) FIT Cfolds',2,13,2),(66,'5000 Roubles (M04) UNFIT MD',2,13,2),(67,'5000 Roubles (M04) FIT',2,13,2),(68,'5000 Roubles (M04) UNFIT',2,13,2),(69,'5000 Roubles (10) Unfit MD',2,13,2),(70,'5000 Roubles (10) Unfit',2,13,2),(71,'1 Usd Count',2,14,2),(72,'2 Usd Count',2,15,2),(73,'5 Usd Count',2,16,2),(74,'10 Usd Count',2,17,2),(75,'20 Usd Count',2,18,2),(76,'50 Usd Count',2,19,2),(77,'100 Usd Count',2,20,2);
/*!40000 ALTER TABLE `Valuables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ValuablesGrades`
--

DROP TABLE IF EXISTS `ValuablesGrades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ValuablesGrades` (
  `SequenceId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ScenarioId` bigint(20) NOT NULL,
  `ValuableId` bigint(20) NOT NULL,
  `GradeId` bigint(20) NOT NULL,
  PRIMARY KEY (`SequenceId`),
  KEY `ValuableGrades_ScenarioId_Scenarios_idx` (`ScenarioId`),
  KEY `ValuableGrades_GradeId_Grades_idx` (`GradeId`),
  KEY `ValuableGrades_ValuableId_Valuables_idx` (`ValuableId`),
  CONSTRAINT `ValuableGrades_ScenarioId_Scenarios` FOREIGN KEY (`ScenarioId`) REFERENCES `Scenario` (`ScenarioId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ValuableGrades_GradeId_Grades` FOREIGN KEY (`GradeId`) REFERENCES `Grades` (`GradeId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ValuableGrades_ValuableId_Valuables` FOREIGN KEY (`ValuableId`) REFERENCES `Valuables` (`ValuableId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=289 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ValuablesGrades`
--

LOCK TABLES `ValuablesGrades` WRITE;
/*!40000 ALTER TABLE `ValuablesGrades` DISABLE KEYS */;
INSERT INTO `ValuablesGrades` VALUES (1,1,1,2),(2,1,2,2),(3,1,3,2),(4,1,5,2),(5,1,11,2),(6,1,12,2),(7,1,13,2),(8,1,14,2),(9,1,21,2),(10,1,22,2),(11,1,23,2),(12,1,24,2),(13,1,31,2),(14,1,32,2),(15,1,33,2),(16,1,34,2),(17,1,35,2),(18,1,36,2),(19,1,46,2),(20,1,47,2),(21,1,48,2),(22,1,49,2),(23,1,50,2),(24,1,51,2),(25,1,61,2),(26,1,62,2),(27,1,65,2),(28,1,67,2),(29,1,6,3),(30,1,7,3),(31,1,8,3),(32,1,9,3),(33,1,16,3),(34,1,17,3),(35,1,18,3),(36,1,19,3),(37,1,26,3),(38,1,27,3),(39,1,28,3),(40,1,29,3),(41,1,39,3),(42,1,40,3),(43,1,41,3),(44,1,42,3),(45,1,43,3),(46,1,44,3),(47,1,54,3),(48,1,55,3),(49,1,56,3),(50,1,57,3),(51,1,58,3),(52,1,59,3),(53,1,66,3),(54,1,68,3),(55,1,69,3),(56,1,70,3),(57,2,1,2),(58,2,2,2),(59,2,3,2),(60,2,5,2),(61,2,11,2),(62,2,12,2),(63,2,13,2),(64,2,14,2),(65,2,21,2),(66,2,22,2),(67,2,23,2),(68,2,24,2),(69,2,31,2),(70,2,32,2),(71,2,33,2),(72,2,34,2),(73,2,35,2),(74,2,36,2),(75,2,46,2),(76,2,47,2),(77,2,48,2),(78,2,49,2),(79,2,50,2),(80,2,51,2),(81,2,61,2),(82,2,62,2),(83,2,65,2),(84,2,67,2),(85,2,4,5),(86,2,10,5),(87,2,15,5),(88,2,20,5),(89,2,25,5),(90,2,30,5),(91,2,37,5),(92,2,38,5),(93,2,45,5),(94,2,52,5),(95,2,53,5),(96,2,60,5),(97,2,63,5),(98,2,64,5),(99,3,1,6),(100,3,4,6),(101,3,5,6),(102,3,6,6),(103,3,7,6),(104,3,11,6),(105,3,12,6),(106,3,15,6),(107,3,16,6),(108,3,17,6),(109,3,21,6),(110,3,22,6),(111,3,25,6),(112,3,26,6),(113,3,27,6),(114,3,31,6),(115,3,32,6),(116,3,39,6),(117,3,40,6),(118,3,37,6),(119,3,46,6),(120,3,47,6),(121,3,54,6),(122,3,55,6),(123,3,60,6),(124,3,2,7),(125,3,3,7),(126,3,8,7),(127,3,9,7),(128,3,10,7),(129,3,13,7),(130,3,14,7),(131,3,18,7),(132,3,19,7),(133,3,20,7),(134,3,23,7),(135,3,24,7),(136,3,28,7),(137,3,29,7),(138,3,30,7),(139,3,33,7),(140,3,34,7),(141,3,41,7),(142,3,42,7),(143,3,45,7),(144,3,48,7),(145,3,49,7),(146,3,52,7),(147,3,56,7),(148,3,57,7),(149,3,63,7),(150,3,65,7),(151,3,66,7),(152,3,67,7),(153,3,68,7),(154,3,35,8),(155,3,36,8),(156,3,38,8),(157,3,43,8),(158,3,44,8),(159,3,50,8),(160,3,51,8),(161,3,53,8),(162,3,58,8),(163,3,59,8),(164,3,61,8),(165,3,62,8),(166,3,64,8),(167,3,69,8),(168,3,70,8),(169,4,1,4),(170,4,2,4),(171,4,3,4),(172,4,4,4),(173,4,5,4),(174,4,6,4),(175,4,7,4),(176,4,8,4),(177,4,9,4),(178,4,10,4),(179,4,11,4),(180,4,12,4),(181,4,13,4),(182,4,14,4),(183,4,15,4),(184,4,16,4),(185,4,17,4),(186,4,18,4),(187,4,19,4),(188,4,20,4),(189,4,21,4),(190,4,22,4),(191,4,23,4),(192,4,24,4),(193,4,25,4),(194,4,26,4),(195,4,27,4),(196,4,28,4),(197,4,29,4),(198,4,30,4),(199,4,31,4),(200,4,32,4),(201,4,33,4),(202,4,34,4),(203,4,35,4),(204,4,36,4),(205,4,37,4),(206,4,38,4),(207,4,39,4),(208,4,40,4),(209,4,41,4),(210,4,42,4),(211,4,43,4),(212,4,44,4),(213,4,45,4),(214,4,46,4),(215,4,47,4),(216,4,48,4),(217,4,49,4),(218,4,50,4),(219,4,51,4),(220,4,52,4),(221,4,52,4),(222,4,54,4),(223,4,55,4),(224,4,56,4),(225,4,57,4),(226,4,58,4),(227,4,59,4),(228,4,60,4),(229,4,61,4),(230,4,62,4),(231,4,63,4),(232,4,64,4),(233,4,65,4),(234,4,66,4),(235,4,67,4),(236,4,68,4),(237,4,69,4),(238,4,70,4),(239,4,71,4),(240,4,72,4),(241,4,73,4),(242,4,74,4),(243,4,75,4),(244,4,76,4),(245,4,77,4),(246,1,10,0),(247,1,4,0),(248,1,30,0),(249,1,25,0),(250,1,52,0),(251,1,53,0),(252,1,60,0),(253,1,20,0),(254,1,15,0),(255,1,45,0),(256,1,38,0),(257,1,37,0),(258,1,63,0),(259,1,64,0),(260,2,9,0),(261,2,8,0),(262,2,7,0),(263,2,6,0),(264,2,29,0),(265,2,28,0),(266,2,27,0),(267,2,26,0),(268,2,57,0),(269,2,56,0),(270,2,59,0),(271,2,58,0),(272,2,55,0),(273,2,54,0),(274,2,19,0),(275,2,18,0),(276,2,17,0),(277,2,16,0),(278,2,44,0),(279,2,43,0),(280,2,42,0),(281,2,41,0),(282,2,40,0),(283,2,39,0),(284,2,70,0),(285,2,69,0),(286,2,68,0),(287,2,66,0),(288,4,53,4);
/*!40000 ALTER TABLE `ValuablesGrades` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-03-26 14:39:16
