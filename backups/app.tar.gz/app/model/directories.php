<?php

/*
 * Переменные задающие служебные директории 
 */

    // Путь для хранения архивов
    $service_directory = 'service';
    $backup_directory = 'backups';
    $log_backup_directory = 'logs';
    
    // Пути для генерации отчетов
    $xml_archive_directory = 'xml_archive';
    $xml_output_directory = 'xml_output';

    
?>
