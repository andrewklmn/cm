<?php
	$taskreculc_indexes = Array(
		'3' => ['CurrCode' => '643', 'ValuableTypeName' => 'banknotes'],
		'4' => ['CurrCode' => '643', 'ValuableTypeName' => 'banknotes'],
		'5' => ['CurrCode' => '643', 'ValuableTypeName' => 'banknotes']
	);
?>
