<?php

/*
 * Model of error files directory list
 */

    $error_files=array(
        '1.txt',
        '2.txt'
    );
    
?>
