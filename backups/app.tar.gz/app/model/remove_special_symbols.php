<?php

    /*
     * Удаяеит запрещенные символы из текста для сохранения в БД
     */

    function remove_special_symbols($text) {
        
    };

?>
