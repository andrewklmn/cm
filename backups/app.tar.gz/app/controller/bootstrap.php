<?php

/*
 * Bootstrap
 */
    if (!isset($c)) exit;
        
    include 'app/view/bootstrap.php';

?>
