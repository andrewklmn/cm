<?php

/*
 * Toshiba DepositRuns collector
 */

        if (!isset($c)) exit;
        echo 'Data from Toshiba ',$value['SorterVariant'],' was collected
';
?>
