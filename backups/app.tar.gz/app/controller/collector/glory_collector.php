<?php

/*
 * Simulator DepositRuns collector
 */

        if (!isset($c)) exit;
        echo 'Data from Glory ',$value['SorterVariant'],' was collected
';
?>
