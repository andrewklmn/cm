<?php

    header( 'Location: ../' );
    exit;

    echo '<pre>';
    print_r($_SERVER);
    echo '</pre>';
    
?>
