<?php

/*
 * Cobra DepositRuns collector
 */

        if (!isset($c)) exit;
        echo 'Data from Cobra ',$value['SorterVariant'],' was collected
';
?>
