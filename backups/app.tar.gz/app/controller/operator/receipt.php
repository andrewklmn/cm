<?php

    if (!isset($c)) exit;
            
    include 'app/controller/supervisor/receipt.php';
        
?>
