<?php

/*
 * Rec report
 */
    if (!isset($c)) exit;
            
    include 'app/controller/supervisor/reconciliation_report.php';
    
?>
