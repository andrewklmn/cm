<?php

/*
 * Список пользователей
 */

        $roles = array(3); // массив отображаемых ролей 
        $no_add = 1;
        include 'app/controller/common/users.php';

?>
