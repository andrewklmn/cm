<?php

/*
 * Reconciliation Controller
 */

        if (!isset($c)) exit;
        
        include './app/controller/supervisor/reconciliation.php';
?>