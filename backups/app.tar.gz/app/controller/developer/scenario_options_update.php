<?php

/*
 * Updates scenario record
 */


    if (!isset($c)) exit;
    
    
    include './app/view/html_header.php';
    //echo '0';
    //echo $_POST['values'];
    echo '1';
    echo $_POST['oldvalues'];
?>
