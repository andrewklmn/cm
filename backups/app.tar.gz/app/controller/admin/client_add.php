<?php

/*
 * Контроллер для работы со списком клиентов
 */
        if (!isset($c)) exit;
        include 'app/controller/supervisor/client_add.php';
        
?>
