<?php

/*
 * профиль пользователя
 */

    if (!isset($c)) exit;
    include './app/controller/common/profile.php';
    
?>