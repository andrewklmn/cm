<?php

/*
 * Изменение пароля
 */

    include './app/controller/common/change_password.php';

?>
