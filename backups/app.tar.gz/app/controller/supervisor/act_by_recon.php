<?php

/*
 * Index page of operator workflow
 */

        if (!isset($c)) exit;

?>
    <script>

    </script>
    <div class="container">
        <?php 
            include 'app/view/forms/act_by_reconciliation.php';
        ?>
    </div>
</body>
</html>