<?php

/*
 * Index page of operator workflow
 */

        if (!isset($c)) exit;
        
        if (!isset($_GET['id']) OR $_GET['id']=='') {
                header( 'Location: ?c=taskrecalc' );
                exit;
        };

        // проверяем существует ли файл
        if (!file_exists('input/'.$_SESSION[$program]['UserConfiguration']['CashRoomId'].'/'.$_GET['id'])) {
            header( 'Location: ?c=taskrecalc' );
            exit;
        };
        
        $data['title'] = $_SESSION[$program]['lang']['taskrecalc_view'];
        include './app/model/menu.php';
        include './app/view/page_header_with_logout.php';
        include './app/view/set_remove_wait.php';
        
        include 'app/view/reload_after_1_min.php';
        include_once 'app/model/taskrecalc/get_taskrecalc_files_list.php';
        
        $list = get_taskrecalc_files_list();
        
?>
    <div class="container">
        <?php
        
            $root = simplexml_load_file('input/'.$_SESSION[$program]['UserConfiguration']['CashRoomId'].'/'.$_GET['id']);
            
            if (!$root) {
                // Файл не соответствует стандарту XML, перекладываем его в Эррор
                copy(
                    'input/'.$_SESSION[$program]['UserConfiguration']['CashRoomId'].'/'.$_GET['id'],
                    'error/'.$_GET['id']
                );
                chmod('error/'.$_GET['id'], 0777);
                unlink('input/'.$_SESSION[$program]['UserConfiguration']['CashRoomId'].'/'.$_GET['id']);
                
                echo htmlfix($_GET['id']).' - has XML syntax error<br/>';
                echo 'File was moved to error folder';
            } else {;

                // проверяем наличие тегов Pack в корне папки
                $packs = 0;
                foreach ($root as $key=>$value) {
                    if (strtolower($key)=='pack') $packs++;
                };

                if ($packs == 0) {
                    // Файл не содержит информации о подготовках
                    copy(
                        'input/'.$_SESSION[$program]['UserConfiguration']['CashRoomId'].'/'.$_GET['id'],
                        'error/'.$_GET['id']
                    );
                    chmod('error/'.$_GET['id'], 0777);
                    unlink('input/'.$_SESSION[$program]['UserConfiguration']['CashRoomId'].'/'.$_GET['id']);

                    echo htmlfix($_GET['id']).' - has wrong XML structure<br/>';
                    echo 'File was moved to error folder';                

                } else {;
                    echo '<h4>',htmlfix($_GET['id']),'</h4>';
                    include 'app/model/table/taskrecalc_xml.php';
                }
            };
        ?>
    </div>
    <div class="container navbar navbar-fixed-bottom"
         style="background-color: white; padding: 20px;">
        <a class="btn btn-primary btn-large" href="?c=taskrecalc">
            <?php echo htmlfix($_SESSION[$program]['lang']['back_to_list']); ?>
        </a>
        <?php 
            if ($packs > 0) {
                ?>
                    <a class="btn btn-danger btn-large" href="?c=taskrecalc">
                        <?php echo htmlfix($_SESSION[$program]['lang']['create_prepared_recs']); ?>
                    </a>
                <?php
            };
        ?>
    </div>
</body>
</html>