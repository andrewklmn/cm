<?php

/*
 * Shows all global parameters
 */

    if (!isset($c)) exit;
    /*
    echo '<br/>GET =================<br/>';
    print_r($_GET);
    echo '<br/>POST ================<br/>';
    print_r($_POST);
    echo '<br/>SESSION =============<br/>';
    print_r($_SESSION);
    echo '<br/>';
     * 
     */
?>
