<?php

/*
 * Подключение функций кодирования и декодирования base64 для javascript
 */ 
    
?>
<script src="js/base64_encode.js"></script>
<script src="js/base64_decode.js"></script>