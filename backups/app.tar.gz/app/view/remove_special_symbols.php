<?php

/*
 * 
 */
?>
<script>
    function rs( text ){
        return text.replace(/[`\|\\]/g, '' );
    };
</script>