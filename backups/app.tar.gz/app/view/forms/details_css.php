<?php

/*
 * Стиль для форм редактирования
 */

?>
<style>
    table.details th {
        text-align: right;
        vertical-align: middle;
        padding: 2px;
        margin: 2px;
    }
    table.details td {
        text-align: center;
        vertical-align: middle;
        padding: 2px;
        margin: 2px;
    }
    table.details input {
        width: 300px;
        padding: 2px;
        margin: 2px;
    }
</style>