<?php

/*
 * Logout link
 */
?>
<a href="?c=logout"><?php echo $_SESSION[$program]['lang']['logout'];?></a>
