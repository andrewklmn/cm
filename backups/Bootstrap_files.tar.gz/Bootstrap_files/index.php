<?php

    header( 'Location: ../' );
    exit;
    
?>
